"""Cloud-only entry point. Local `python3 app.py` still listens on 127.0.0.1:5001."""
import os
import secrets
from flask import Response, request
from werkzeug.middleware.proxy_fix import ProxyFix
from app import app

if os.environ.get('RENDER'):
    for name in ('PRODUCT_AGENT_SECRET_KEY', 'PRODUCT_AGENT_ACCESS_PASSWORD', 'MODEL_API_KEY'):
        if not os.environ.get(name):
            raise RuntimeError('Required cloud setting is missing: ' + name)

app.config.update(SESSION_COOKIE_SECURE=bool(os.environ.get('RENDER')),
                  MAX_CONTENT_LENGTH=2 * 1024 * 1024)
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

@app.before_request
def cloud_access_gate():
    if request.path == '/healthz':
        return None
    password = os.environ.get('PRODUCT_AGENT_ACCESS_PASSWORD')
    if not password:
        return None
    auth = request.authorization
    if not auth or not secrets.compare_digest(auth.password or '', password):
        return Response('请输入演示访问口令。用户名可填写 demo。', 401,
                        {'WWW-Authenticate': 'Basic realm="Product Agent Demo", charset="UTF-8"',
                         'Cache-Control': 'no-store'})

@app.get('/healthz')
def healthz():
    return {'status':'ok'}

@app.context_processor
def cloud_demo_context():
    return {'cloud_demo': bool(os.environ.get('RENDER'))}

@app.after_request
def cloud_headers(response):
    response.headers['X-Robots-Tag'] = 'noindex, nofollow'
    return response
