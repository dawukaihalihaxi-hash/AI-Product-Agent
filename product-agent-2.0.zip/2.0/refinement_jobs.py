"""Local background refinement: drafts are separate from saved project history."""
import json
import hashlib
import shutil
import os
import re
import threading
from time import sleep, time
from pathlib import Path
from uuid import uuid4
import requests
from agents.requirement_agent import RequirementAgent
from agents.html_agent import HtmlAgent
from agents.workflow_agent import WorkflowAgent
from workflow_document import validate_bundle


class JobCancelled(Exception):
    pass


class RefinementJobs:
    def __init__(self, manager, logger):
        self.manager, self.logger = manager, logger
        self.active = {}
        self.lock = threading.RLock()

    def root(self):
        root = self.manager.projects_dir / '.refinement-drafts'
        root.mkdir(exist_ok=True)
        return root

    def path(self, job_id):
        if not re.fullmatch(r'[a-f0-9]{32}', job_id):
            raise ValueError('无效任务')
        return self.root() / job_id

    def read(self, job_id):
        return json.loads((self.path(job_id) / 'task.json').read_text(encoding='utf-8'))

    def write(self, job):
        folder = self.path(job['id'])
        temporary = folder / 'task.tmp'
        temporary.write_text(json.dumps(job, ensure_ascii=False), encoding='utf-8')
        os.replace(temporary, folder / 'task.json')

    def _elapsed(self, job):
        if job['state'] != 'running': return job.get('elapsed_seconds', 0)
        return job.get('elapsed_before', 0) + max(0, time()-job.get('attempt_started_at',job.get('started_at',time())))

    @staticmethod
    def valid_html(content):
        content=content.lower()
        return all(part in content for part in ('<!doctype','<html','<body','</body>','</html>'))

    def completed(self, job):
        """Only reuse validated checkpoints, in dependency order."""
        directory = self.path(job['id']); checkpoints = job.get('checkpoints', {})
        legacy = not job.get('checkpoint_schema')
        def valid(name, stage):
            file = directory/name
            if not file.is_file() or not file.read_text(encoding='utf-8').strip(): return False
            sha = hashlib.sha256(file.read_bytes()).hexdigest()
            if not legacy and checkpoints.get(stage, {}).get('sha256') != sha: return False
            if stage == 'html' and not self.valid_html(file.read_text(encoding='utf-8')): return False
            return True
        prd = valid('requirement.md','prd') if (not legacy or job.get('stage') in ('html','workflow','checking','ready') or job['state'] in ('ready','saved')) else False
        html = prd and valid('prototype.html','html')
        if html and not legacy and checkpoints.get('html',{}).get('prd_sha') != hashlib.sha256((directory/'requirement.md').read_bytes()).hexdigest(): html=False
        workflow = False
        if html:
            try:
                validate_bundle(directory)
                workflow = legacy or checkpoints.get('workflow',{}).get('sha256') == hashlib.sha256((directory/'bundle_manifest.json').read_bytes()).hexdigest()
            except (ValueError,OSError): pass
        return {'prd':bool(prd),'html':bool(html),'workflow':bool(workflow)}

    def checkpoint(self, job, stage):
        directory=self.path(job['id'])
        name={'prd':'requirement.md','html':'prototype.html','workflow':'bundle_manifest.json'}[stage]
        file=directory/name
        if not file.is_file() or not file.read_text(encoding='utf-8').strip(): raise ValueError('阶段结果缺失：'+stage)
        if stage=='html' and not self.valid_html(file.read_text(encoding='utf-8')): raise ValueError('原型不完整，未保存检查点')
        if stage=='workflow': validate_bundle(directory)
        checkpoints=dict(job.get('checkpoints',{}))
        checkpoints[stage]={'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'completed_at':time()}
        if stage=='html':checkpoints[stage]['prd_sha']=hashlib.sha256((directory/'requirement.md').read_bytes()).hexdigest()
        order=['prd','html','workflow']
        for downstream in order[order.index(stage)+1:]:checkpoints.pop(downstream,None)
        self.update(job, checkpoints=checkpoints)

    def archive_unverified(self, job, stage):
        from workflow_document import WORKFLOW_FILES
        names={'prd':('requirement.md',),'html':('prototype.html',),'workflow':WORKFLOW_FILES}[stage]
        directory=self.path(job['id'])
        for name in names:
            file=directory/name
            if file.exists(): file.rename(directory/('.partial-'+uuid4().hex+'-'+name))

    def context_snapshot(self, job, context=None):
        target=self.path(job['id'])/'context.json'
        if target.is_file(): return json.loads(target.read_text(encoding='utf-8'))
        if context is None:
            if job.get('kind') == 'create':
                context={'project':job['source'],'raw_requirement':job['raw'],'original_prd':None}
            else:
                source=self.manager.get_project(job['source_id'])
                if not source or self.manager.project_fingerprint(job['source_id']) != job.get('fingerprint'):
                    raise ValueError('旧任务缺少原始快照且原版本已变化，无法安全恢复。已生成文件仍保留。')
                context={'project':job['source'],'raw_requirement':self.manager.get_raw_requirement(job['source_id']),
                         'original_prd':self.manager.get_prd(job['source_id'])}
        frozen=dict(context)
        if job.get('kind') in ('refine','workflow'):
            source_html=self.manager.get_html_path(job['source_id'])
            frozen['previous_html']=source_html.read_text(encoding='utf-8') if source_html else None
        else:frozen['previous_html']=None
        target.write_text(json.dumps(frozen,ensure_ascii=False),encoding='utf-8')
        return frozen

    def _launch(self, job, context):
        thread=threading.Thread(target=self.run,args=(job,context),daemon=True)
        self.active[job['id']]=thread
        thread.start()
        return job

    def start(self, context, changes, owner, kind="refine"):
        with self.lock:
            raw=context['raw_requirement'] or context['original_prd']
            # Identical unfinished submissions resume the existing task, not a second generation.
            for current in self.history(owner,'*',limit=None,unfinished=True):
                if current.get('kind','refine')==kind and current.get('source_id')==context['project'].get('id') and current.get('raw')==raw and current.get('changes','')==changes:
                    if current['state'] in ('running','ready'):return current
                    return self.resume(current['id'])
            now=time()
            job=dict(id=uuid4().hex,owner=owner,kind=kind,started_at=now,attempt_started_at=now,
                elapsed_before=0,stage_started_at=now,stage_seconds={},attempts=[],resume_count=0,
                run_id=uuid4().hex,checkpoint_schema=1,checkpoints={},source_id=context['project'].get('id'),
                source=context['project'],changes=changes,state='running',stage='queued',
                message='任务已保存，正在准备生成内容。',raw=raw,
                fingerprint=self.manager.project_fingerprint(context['project']['id']) if kind in ('refine','workflow') else None)
            self.path(job['id']).mkdir();self.write(job)
            frozen=self.context_snapshot(job,context)
            return self._launch(job,frozen)

    def resume(self, job_id):
        with self.lock:
            job=self.status(job_id)
            if job['state'] in ('running','ready','saved'):return job
            if job_id in self.active:
                raise ValueError('上一条模型请求仍在退出中，请稍后点击继续生成；已完成内容已保留。')
            frozen=self.context_snapshot(job)
            done=self.completed(job)
            if not job.get('checkpoint_schema'):
                # Adopt valid results from tasks created before resumable checkpoints existed.
                directory=self.path(job_id);checkpoints={}
                for stage,name in [('prd','requirement.md'),('html','prototype.html'),('workflow','bundle_manifest.json')]:
                    if done[stage]:
                        checkpoints[stage]={'sha256':hashlib.sha256((directory/name).read_bytes()).hexdigest()}
                        if stage=='html':checkpoints[stage]['prd_sha']=hashlib.sha256((directory/'requirement.md').read_bytes()).hexdigest()
                job.update(checkpoint_schema=1,checkpoints=checkpoints)
            now=time();attempts=list(job.get('attempts',[]))
            attempts.append({'state':job['state'],'stage':job.get('stage'),'message':job.get('message'),
                             'elapsed_seconds':job.get('elapsed_seconds',0),'finished_at':job.get('finished_at')})
            next_stage=next((stage for stage in ('prd','html','workflow') if not done[stage]),'checking')
            job.update(state='running',stage=next_stage,stage_started_at=now,attempt_started_at=now,
                elapsed_before=job.get('elapsed_seconds',0),finished_at=None,request_started_at=None,error_http=None,error_provider=None,failure_reason=None,
                resume_count=job.get('resume_count',0)+1,attempts=attempts,run_id=uuid4().hex,
                message='正在继续生成，已完成的步骤将直接复用。')
            self.write(job)
            return self._launch(job,frozen)

    def update(self, job, **values):
        with self.lock:
            existing = self.read(job['id'])
            if existing.get('run_id') != job.get('run_id'): raise JobCancelled()
            if existing['state'] == 'deleted' or (values.get('state') != 'deleted' and (existing['state'] == 'cancelled' or (existing['state'] == 'failed' and job['state'] == 'running'))):
                raise JobCancelled()
            if values.get('state') == 'failed' and 'failure_reason' not in values:
                values.update(failure_reason=values.get('message'), error_http=None, error_provider=None)
            now = time()
            if job['state'] == 'running' and (values.get('stage', job['stage']) != job['stage'] or values.get('state', 'running') != 'running'):
                durations = dict(job.get('stage_seconds', {}))
                durations[job['stage']] = durations.get(job['stage'], 0) + max(0, now - job.get('stage_started_at', now))
                job.update(stage_seconds=durations, stage_started_at=now)
            if values.get('state') in ('ready', 'failed', 'cancelled', 'saved') and not job.get('finished_at'):
                job.update(finished_at=now, elapsed_seconds=self._elapsed(job))
            job.update(values)
            self.write(job)

    def status(self, job_id):
        with self.lock:
            job = self.read(job_id)
            if job['state'] == 'running' and job_id not in self.active:
                self.update(job, state='failed', message='服务重启中断了任务，已完成内容已保留，可从断点继续生成。原版未修改。')
            if job['state'] == 'running' and job.get('request_started_at') and time() - job['request_started_at'] > 240:
                self.update(job, state='failed', message='AI 单次请求已超过 4 分钟，已终止本次任务的后续处理。已生成的文件保留，原版未修改，可稍后继续生成。')
            job['elapsed_seconds'] = self._elapsed(job)
            job['completed'] = self.completed(job)
            job['can_resume'] = job['state'] in ('failed','cancelled') and job_id not in self.active
            return job

    def check_cancelled(self, job):
        current=self.read(job['id'])
        if current['state'] in ('cancelled','failed','deleted') or current.get('run_id') != job.get('run_id'):
            raise JobCancelled()

    def cancel(self, job_id):
        with self.lock:
            job = self.read(job_id)
            if job['state'] == 'running':
                self.update(job, state='cancelled', message='已停止本次生成，需求和已完成内容已保留，可稍后继续生成。已发出的模型请求可能仍在服务端执行。')
            return job

    def delete(self, job_id):
        """Hide immediately; in-flight workers clean their files only after exiting."""
        with self.lock:
            job = self.read(job_id)
            if job['state'] == 'saved':
                raise ValueError('此任务已保存，请在历史项目中管理已完成的版本。')
            self.update(job, state='deleted')
            if job_id not in self.active:
                shutil.rmtree(self.path(job_id))

    def history(self, owner, source_id, *, limit=10, unfinished=False):
        jobs = []
        for folder in self.root().iterdir():
            if not folder.is_dir():
                continue
            try:
                job = self.read(folder.name)
                if job['state'] != 'deleted' and job['owner'] == owner and (source_id == '*' or job.get('source_id') == source_id) and (not unfinished or job['state']!='saved'):
                    jobs.append(self.status(folder.name))
            except (OSError, ValueError):
                continue
        result=sorted(jobs,key=lambda item:item.get('started_at',0),reverse=True)
        return result if limit is None else result[:limit]

    @staticmethod
    def provider_code(error):
        try:
            return str(error.response.json().get('error', {}).get('code', ''))
        except (AttributeError, ValueError, TypeError):
            return ''

    def generate_with_retry(self, operation, job, stage):
        for attempt in range(3):
            self.check_cancelled(job)
            try:
                artifact = {'prd':'PRD','html':'HTML 原型','workflow':'业务流程图'}[stage]
                detail = f'正在请求 AI 生成 {artifact}。' if attempt == 0 else f'正在自动重试生成 {artifact}（第 {attempt}/2 次重试）。'
                self.update(job, request_started_at=time(), request_attempt=attempt + 1, message=detail)
                result = operation()
                self.check_cancelled(job)
                self.update(job, request_started_at=None)
                return result
            except requests.HTTPError as error:
                response = error.response
                code = self.provider_code(error)
                temporary = response is not None and (response.status_code in (502, 503, 504) or
                    (response.status_code == 429 and code in ('1302', '1305')))
                if not temporary or attempt == 2:
                    raise
                delay = (5, 12)[attempt]
                self.update(job, stage=stage,
                    message=f'AI 服务繁忙，{delay} 秒后自动重试（第 {attempt + 1}/2 次）；原版未修改。')
                for _ in range(delay):
                    self.check_cancelled(job)
                    sleep(1)
                self.check_cancelled(job)
                self.update(job, stage=stage, message='正在重新请求 AI 服务，请稍候。')

    def run(self, job, context):
        try:
            directory = self.path(job['id'])
            original_html = context.get('previous_html')
            completed = self.completed(job)
            if job.get('kind') == 'workflow':
                if not completed['prd']:
                    (directory/'requirement.md').write_text(context['original_prd'],encoding='utf-8')
                    self.checkpoint(job,'prd')
                if not completed['html']:
                    (directory/'prototype.html').write_text(original_html,encoding='utf-8')
                    self.checkpoint(job,'html')
            else:
                prompt = f"""请优化现有产品需求，将本次修改合并到完整 PRD；保留未涉及的功能、页面和规则。
当前需求：\n{context['raw_requirement']}
已有 PRD：\n{context['original_prd'] or '暂无'}
本次修改要求：\n{job['changes']}"""
                if job.get('kind') == 'create': prompt = job['raw']
                if not completed['prd']:
                    self.archive_unverified(job,'prd')
                    self.update(job,stage='prd',message='正在生成本版本 PRD。')
                    self.generate_with_retry(lambda: RequirementAgent().run(prompt,output_dir=directory),job,'prd')
                    self.checkpoint(job,'prd')
                if not completed['html']:
                    self.archive_unverified(job,'html')
                    self.update(job,stage='html',message='已保留 PRD，正在继续生成本版本原型。')
                    self.generate_with_retry(lambda: HtmlAgent().run(output_dir=directory,previous_html=original_html,change_request=job['changes']),job,'html')
                    self.checkpoint(job,'html')
            if not completed['workflow']:
                self.archive_unverified(job,'workflow')
                self.update(job,stage='workflow',message='已保留 PRD 和原型，正在继续生成配套 Workflow。')
                self.generate_with_retry(lambda: WorkflowAgent().run(output_dir=directory),job,'workflow')
                self.checkpoint(job,'workflow')
            self.update(job, stage='checking', message='正在校验 PRD、原型与流程图配套内容及引用关系。')
            validate_bundle(directory)
            with self.lock:
                self.check_cancelled(job)
                self.update(job, stage='ready', state='ready', message='PRD、原型和流程图已配套生成，尚未覆盖原版。请查看后选择保存方式。')
                if job.get('kind') == 'workflow':
                    self.manager.attach_workflow(job['source_id'], directory, job['fingerprint'])
                    self.update(job, state='saved', saved_id=job['source_id'], saved_mode='workflow', message='当前版本的配套流程图已生成，PRD 和原型保持不变。')
                elif job.get('kind') == 'create':
                    self.save(job['id'], 'new')
        except JobCancelled:
            pass
        except Exception as error:
            # Never surface provider bodies, API keys, or full generated prompts.
            stage = job.get('stage', 'queued')
            stage_label = {'queued':'准备', 'prd':'优化 PRD', 'html':'优化原型', 'workflow':'生成业务流程图', 'checking':'检查文件'}.get(stage, stage)
            if isinstance(error, requests.Timeout):
                reason = 'AI 服务连接或读取响应超时，已结束本次生成；可以稍后重试'
            elif isinstance(error, requests.ConnectionError):
                reason = '无法连接 AI 服务，请检查网络或服务地址'
            elif isinstance(error, requests.HTTPError):
                code = error.response.status_code if error.response is not None else '未知'
                provider = self.provider_code(error)
                reasons = {'1305': '当前 AI 模型访问量过大，自动重试后仍未恢复，请稍后重试',
                           '1302': 'AI 服务请求频率受限，自动重试后仍未恢复',
                           '1113': 'AI 服务账户余额不足，请检查服务账户',
                           '1308': 'AI 服务使用额度已达到上限',
                           '1310': 'AI 服务周期使用额度已达到上限'}
                http_reasons = {400:'AI 请求参数有误，请检查模型配置或缩短需求', 401:'AI 服务认证失败，请检查 API 密钥', 403:'AI 服务拒绝访问，请检查密钥权限及模型使用权限', 404:'AI 服务地址或模型不存在，请检查配置', 429:'AI 服务限流或额度受限，请稍后重试或检查额度'}
                reason = reasons.get(provider, http_reasons.get(code, f'AI 服务异常（HTTP {code}），请稍后重试'))
                reason += f'（HTTP {code}' + (f'，错误码 {provider}' if provider.isdigit() else '') + '）'
            elif isinstance(error, ValueError):
                reason = 'AI 返回为空、格式不完整，或三份配套内容及流程引用校验未通过'
            elif isinstance(error, OSError):
                reason = '读取或保存文件失败，请检查文件权限和磁盘空间'
            else:
                reason = 'AI 调用或生成过程异常'
            self.logger.error('Refinement task %s failed at %s (%s)', job['id'], stage, type(error).__name__)
            try:
                self.update(job, state='failed', failure_reason=reason, error_provider=self.provider_code(error) if isinstance(error, requests.HTTPError) else None, error_http=error.response.status_code if isinstance(error, requests.HTTPError) and error.response is not None else None,
                    message=f'{reason}。失败阶段：{stage_label}。原版未修改，需求和已完成内容已保存，可继续生成。')
            except JobCancelled:
                pass
        finally:
            with self.lock:
                if self.active.get(job['id']) is threading.current_thread():
                    self.active.pop(job['id'],None)
                    try:
                        if self.read(job['id'])['state'] == 'deleted':
                            shutil.rmtree(self.path(job['id']))
                    except OSError:
                        self.logger.warning('Deleted task cleanup deferred: %s', job['id'])

    def save(self, job_id, mode):
        with self.lock:
            job = self.read(job_id)
            if job.get('saved_id'):
                return job['saved_id']
            if job['state'] != 'ready':
                raise ValueError('优化尚未完成，不能保存。')
            if mode not in ('new', 'replace'):
                raise ValueError('请选择保存为新版本或覆盖原版。')
            if mode == 'replace' and self.manager.project_fingerprint(job['source_id']) != job['fingerprint']:
                raise ValueError('原版已发生变化，不能覆盖；请改为保存新版本。')
            validate_bundle(self.path(job_id))
            raw = job['raw']
            if job.get('kind') == 'create':
                revision = self.manager.create_project(raw_requirement=raw, output_dir=self.path(job_id), require_bundle=True)
                self.update(job, saved_id=revision['id'], saved_mode='new', state='saved', message='生成完成，PRD、原型和流程图已作为同一版本保存。')
                return revision['id']
            revision = self.manager.create_project(raw + '\n\n本次优化要求：\n' + job['changes'],
                project_name=job['source']['name'], output_dir=self.path(job_id),
                source_project=job['source'], change_request=job['changes'], source_fingerprint=job['fingerprint'], require_bundle=True)
            # Record the saved revision before applying; a retry must not duplicate it.
            self.update(job, saved_id=revision['id'], saved_mode='new', state='saved',
                        message='已保存为独立新版本，原版未修改。')
            if mode == 'replace':
                try:
                    self.manager.apply_refinement(revision['id'])
                except Exception:
                    raise ValueError('覆盖未完成，原版已保留或恢复；优化结果已另存新版本，可从下方入口查看。')
                self.update(job, saved_mode='replace', message='PRD、原型和流程图已同步覆盖原版；覆盖前的配套内容已备份。')
            return revision['id']
