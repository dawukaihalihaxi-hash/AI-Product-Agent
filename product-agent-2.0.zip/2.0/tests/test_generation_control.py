import threading
import unittest
from unittest.mock import patch
import requests
import test_features as fixtures
import test_refinement as helpers
from agents.requirement_agent import RequirementAgent
from agents.html_agent import HtmlAgent

module=fixtures.module

class ControlTests(unittest.TestCase):
    setUp=fixtures.FeatureTests.setUp
    tearDown=fixtures.FeatureTests.tearDown
    start=helpers.RefinementTests.start
    wait=helpers.RefinementTests.wait
    generate=helpers.RefinementTests.generate
    generated_prd=staticmethod(helpers.RefinementTests.generated_prd)
    generated_html=staticmethod(helpers.RefinementTests.generated_html)

    def test_cancel_prevents_html_and_save_even_after_model_returns(self):
        entered=threading.Event();release=threading.Event()
        def prd(*args,**kwargs):
            entered.set();release.wait(3);return self.generated_prd(*args,**kwargs)
        with patch.object(RequirementAgent,'run',side_effect=prd),patch.object(HtmlAgent,'run') as html:
            task=self.start();self.assertTrue(entered.wait(1))
            thread=module.refinement_jobs.active[task]
            try:
                response=self.client.post(f'/refinement-tasks/{task}/cancel',headers={'X-CSRF-Token':self.token})
                self.assertEqual(response.json['state'],'cancelled')
                self.assertIn('继续生成',self.client.get(f'/refinement-tasks/{task}').get_data(as_text=True))
            finally:release.set();thread.join(2)
            html.assert_not_called()
        self.assertEqual(module.refinement_jobs.status(task)['state'],'cancelled')
        self.assertEqual(len(self.manager.list_projects()),1)
        self.assertEqual(self.client.post(f'/refinement-tasks/{task}/save',data={'csrf_token':self.token,'mode':'new'}).status_code,409)

    def test_cancel_requires_csrf_and_cannot_cancel_completed_task(self):
        task=self.generate()
        self.assertEqual(self.client.post(f'/refinement-tasks/{task}/cancel').status_code,403)
        response=self.client.post(f'/refinement-tasks/{task}/cancel',headers={'X-CSRF-Token':self.token})
        self.assertEqual(response.json['state'],'ready')

    def test_http403_has_diagnostic_and_retry_no_history(self):
        response=requests.Response();response.status_code=403;response._content=b'{"error":{"code":"1220"}}'
        with patch.object(RequirementAgent,'run',side_effect=requests.HTTPError(response=response)),patch('refinement_jobs.sleep') as sleep:
            task=self.start();job=self.wait(task)
        self.assertIn('HTTP 403',job['message']);self.assertIn('权限',job['message'])
        self.assertEqual(job['error_http'],403);sleep.assert_not_called()
        html=self.client.get(f'/refinement-tasks/{task}').get_data(as_text=True)
        self.assertIn('生成中断',html);self.assertIn('继续生成',html)
        self.assertEqual(len(self.manager.list_projects()),1)

    def test_duration_and_attempt_history_persist(self):
        first=self.generate();second=self.generate()
        job=module.refinement_jobs.read(first)
        self.assertGreaterEqual(job['elapsed_seconds'],0)
        self.assertGreaterEqual(job['finished_at'],job['started_at'])
        self.assertIn('prd',job['stage_seconds']);self.assertIn('html',job['stage_seconds'])
        html=self.client.get(f'/refinement-tasks/{second}').get_data(as_text=True)
        self.assertIn('最近生成记录与用时',html);self.assertIn(first,html)
        before=job['elapsed_seconds'];module.refinement_jobs.status(first)
        self.assertEqual(module.refinement_jobs.read(first)['elapsed_seconds'],before)

    def test_first_generation_failure_visible_without_changing_existing_output(self):
        before=(self.manager.output_dir/'prototype.html').read_bytes()
        with patch.object(RequirementAgent,'run',side_effect=requests.ConnectionError()):
            response=self.client.post('/create',data={'csrf_token':self.token,'requirement':'新需求'},headers={'Accept':'application/json'})
            task=response.json['task_url'].rsplit('/',1)[1];job=self.wait(task)
        self.assertEqual(job['state'],'failed')
        self.assertEqual(self.client.get(response.json['task_url']).status_code,200)
        self.assertIn('无法连接 AI 服务',job['message'])
        self.assertEqual((self.manager.output_dir/'prototype.html').read_bytes(),before)
        self.assertEqual(len(self.manager.list_projects()),1)

    def test_initial_create_has_csrf_and_local_connection_feedback(self):
        self.assertEqual(self.client.post('/create',data={'requirement':'test'}).status_code,403)
        html=self.client.get('/').get_data(as_text=True)
        self.assertIn('generation-start.js',html);self.assertIn('creation-status',html)

    def test_history_shows_only_current_browser_tasks(self):
        task=self.generate()
        self.assertIn(task,self.client.get('/generation-history').get_data(as_text=True))
        other=module.app.test_client()
        self.assertNotIn(task,other.get('/generation-history').get_data(as_text=True))

    def test_cancel_during_busy_retry_stops_next_model_request(self):
        response=requests.Response();response.status_code=429
        response._content=b'{"error":{"code":"1305"}}'
        def stop_during_wait(seconds):
            task_id=next(iter(module.refinement_jobs.active))
            module.refinement_jobs.cancel(task_id)
        with patch.object(RequirementAgent,'run',side_effect=requests.HTTPError(response=response)) as prd,patch('refinement_jobs.sleep',side_effect=stop_during_wait):
            task=self.start();job=self.wait(task)
        self.assertEqual(job['state'],'cancelled')
        self.assertEqual(prd.call_count,1)
