(() => {
  const root=document.getElementById('task');
  const stages=['queued','prd','html','workflow','checking','ready'];
  function paint(stage){document.querySelectorAll('.steps [data-stage]').forEach(node=>{node.classList.toggle('current',node.dataset.stage===stage);node.classList.toggle('done',stages.indexOf(node.dataset.stage)<stages.indexOf(stage));});}
  paint(root.dataset.stage);
  let busy=false,timer;
  let elapsed=Number(root.dataset.elapsed)||0, syncedAt=Date.now();
  function showTime(){const node=document.getElementById('task-elapsed');if(node){const seconds=Math.floor(elapsed+(root.dataset.state==='running'?(Date.now()-syncedAt)/1000:0));node.textContent=`${Math.floor(seconds/60)} 分 ${seconds%60} 秒`;}}
  showTime();if(root.dataset.state==='running'&&typeof setInterval==='function')setInterval(showTime,1000);
  async function poll(){
    if(busy)return;
    busy=true;clearTimeout(timer);
    const note=document.getElementById('poll-message');
    try{
      const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),12000);
      let response;try{response=await fetch(root.dataset.statusUrl,{cache:'no-store',signal:controller.signal});}finally{clearTimeout(timeout);}
      if(!response.ok)throw new Error(response.status===404?'任务页面已过期或登录状态变化，请刷新页面。':'暂时无法读取进度');
      const job=await response.json();
      document.getElementById('task-message').textContent=job.message;paint(job.stage);if(note)note.textContent='';
      if(Number.isFinite(job.elapsed_seconds)){elapsed=job.elapsed_seconds;syncedAt=Date.now();showTime();}
      if(job.state!=='running'){window.location.reload();return;}
    }catch(error){if(note)note.textContent='无法连接本地服务或读取进度，不代表模型生成失败。请确认 VS Code 中服务仍在运行、端口未被占用；将自动重试，也可以点击刷新进度。';}
    finally{busy=false;}
    timer=setTimeout(poll,2000);
  }
  if(root.dataset.state==='running'){poll();document.getElementById('refresh-status').addEventListener('click',poll);}
  const cancel=document.getElementById('cancel-task');
  if(cancel)cancel.addEventListener('click',async()=>{
    if(!window.confirm('停止本次生成？后续步骤和保存将取消，已发出的模型请求可能仍在执行。'))return;
    cancel.disabled=true;
    try{
      const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),12000);
      let response;try{response=await fetch(root.dataset.cancelUrl,{method:'POST',headers:{'X-CSRF-Token':root.dataset.csrf},signal:controller.signal});}finally{clearTimeout(timeout);}
      const data=await response.json();if(!response.ok)throw new Error(data.error||`停止请求失败（HTTP ${response.status}）`);
      window.location.reload();
    }catch(error){document.getElementById('poll-message').textContent='停止请求尚未确认：'+(error.message||'本地服务连接中断')+'。请重试；不能据此认定已经停止。';cancel.disabled=false;}
  });
  document.querySelectorAll('.save-form').forEach(form=>form.addEventListener('submit',event=>{
    if(form.dataset.replace&&!window.confirm('确认覆盖原版？覆盖前会备份，并保留独立新版本。')){event.preventDefault();return;}
    document.querySelectorAll('.save-form button').forEach(button=>button.disabled=true);
    document.getElementById('save-status').textContent='正在保存，请稍候…';
  }));
})();
