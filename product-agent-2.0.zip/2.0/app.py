from pathlib import Path

from flask import Flask, abort, render_template, request, send_file, jsonify, session, redirect, url_for, g
import secrets
import os

from agents.html_agent import HtmlAgent
from agents.requirement_agent import RequirementAgent
from project.project_manager import ProjectManager


app = Flask(__name__)
def session_signing_key():
    configured = os.environ.get("PRODUCT_AGENT_SECRET_KEY")
    if configured:
        return configured
    key_file = Path(__file__).resolve().parent / ".session-secret"
    try:
        descriptor = os.open(key_file, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        return key_file.read_text(encoding="utf-8").strip()
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        value = secrets.token_hex(32)
        stream.write(value)
    return value

app.secret_key = session_signing_key()
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")

@app.before_request
def protect_bundle_reads():
    # Avoid exposing a partially replaced bundle during a concurrent cover operation.
    if request.endpoint in ('edit','project_prd','project_preview','project_workflow',
                            'project_workflow_image','project_workflow_export'):
        from project.project_manager import _apply_lock
        _apply_lock.acquire()
        g.bundle_read_lock = True

@app.teardown_request
def release_bundle_reads(error=None):
    if getattr(g, 'bundle_read_lock', False):
        from project.project_manager import _apply_lock
        g.bundle_read_lock = False
        _apply_lock.release()


@app.context_processor
def csrf_context():
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_urlsafe(32)
    return {"csrf_token": session["csrf_token"]}

@app.route("/projects/<project_id>/delete", methods=["POST"])
def delete_project(project_id):
    token = request.headers.get("X-CSRF-Token", "")
    if not token or not secrets.compare_digest(token, session.get("csrf_token", "")):
        return jsonify(error="页面已过期，请刷新后重试"), 403
    if (request.get_json(silent=True) or {}).get("confirmed") is not True:
        return jsonify(error="请先确认删除"), 400
    try:
        deleted = project_manager.delete_project(project_id)
    except ValueError:
        abort(404)
    except OSError:
        app.logger.exception("删除项目失败")
        return jsonify(error="删除失败，请刷新并重试"), 500
    return jsonify(deleted=deleted, project_id=project_id)

@app.route("/projects/<project_id>/rename", methods=["POST"])
def rename_project(project_id):
    token = request.headers.get("X-CSRF-Token", "")
    if not token or not secrets.compare_digest(token, session.get("csrf_token", "")):
        return jsonify(error="页面已过期，请刷新后重试"), 403
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return jsonify(error="请填写项目名称"), 400
    try:
        # Resolve the ID before validating the name so missing projects remain a 404.
        if project_manager.get_project(project_id) is None:
            return jsonify(error="该项目已不存在，请刷新列表"), 404
        project = project_manager.rename_project(project_id, payload.get("name"))
        if project is None:
            return jsonify(error="该项目已不存在，请刷新列表"), 404
    except ValueError as error:
        try:
            project_manager.project_path(project_id)
        except ValueError:
            return jsonify(error="无效项目编号"), 404
        return jsonify(error=str(error)), 400
    except OSError:
        app.logger.exception("项目重命名失败：%s", project_id)
        return jsonify(error="保存失败，请稍后重试"), 500
    return jsonify(project=project)


@app.after_request
def prevent_stale_history(response):
    if request.path in ("/", "/edit", "/generation-history", "/unfinished-tasks") or request.path.startswith(("/projects/", "/refinement-tasks/")):
        response.headers["Cache-Control"] = "no-store"
    return response


BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "output"

project_manager = ProjectManager()


@app.route("/")
def index():

    from project.project_manager import _apply_lock
    with _apply_lock:
        projects = project_manager.list_projects()
        for project in projects:
            project['workflow_ready'] = project_manager.workflow_status(project['id'])[0] == 'ready'
    refinement_jobs.manager = project_manager
    owner = session.get('refinement_owner')
    pending = refinement_jobs.history(owner, '*', limit=None, unfinished=True) if owner else []
    return render_template("index.html", projects=projects, pending=pending)


@app.route("/create", methods=["POST"])
def create():
    requirement = request.form.get("requirement", "").strip()
    if not requirement or len(requirement) > 20000:
        return jsonify(error="请填写 1–20000 字的需求内容。"), 400
    token = request.form.get('csrf_token', '')
    if not token or not secrets.compare_digest(token, session.get('csrf_token', '')):
        return jsonify(error="页面已过期，请刷新后重试；需求不会丢失。"), 403
    owner = session.setdefault('refinement_owner', secrets.token_urlsafe(32))
    refinement_jobs.manager = project_manager
    context = dict(project={'name':requirement.splitlines()[0][:30]}, raw_requirement=requirement, original_prd=None)
    try:
        job = refinement_jobs.start(context, '', owner, kind='create')
    except ValueError as error:
        return jsonify(error=str(error)), 409
    target = url_for('refinement_task_page', task_id=job['id'])
    if request.accept_mimetypes.best == 'application/json':
        return jsonify(task_url=target), 202
    return redirect(target, code=303)


@app.route('/projects/<project_id>/result')
def generated_project_result(project_id):
    context = refinement_context(project_id)
    return render_template('result.html', project=context['project'])


@app.route("/prd")
def prd():

    path = OUTPUT_DIR / "requirement.md"

    if not path.exists():

        return "暂无 PRD 文件", 404


    content = path.read_text(
        encoding="utf-8"
    )

    return render_template(
        "prd.html",
        content=content,
        project=None
    )


@app.route("/preview")
def preview():

    path = OUTPUT_DIR / "prototype.html"

    if not path.exists():

        return "暂无 HTML 原型", 404


    return send_file(
        path
    )


@app.route("/projects/<project_id>/prd")
def project_prd(project_id):

    project = project_manager.get_project(
        project_id
    )

    if not project:

        abort(404)


    content = project_manager.get_prd(
        project_id
    )

    if content is None:

        return "该项目暂无 PRD 文件", 404


    return render_template(
        "prd.html",
        content=content,
        project=project
    )


@app.route("/projects/<project_id>/preview")
def project_preview(project_id):

    project = project_manager.get_project(
        project_id
    )

    if not project:

        abort(404)


    html_path = project_manager.get_html_path(
        project_id
    )

    if html_path is None:

        return "该项目暂无 HTML 原型", 404


    return send_file(
        html_path
    )


def exportable_project(project_id):
    try:
        project = project_manager.get_project(project_id)
        html_path = project_manager.get_html_path(project_id)
    except ValueError:
        abort(404)
    if not project or html_path is None:
        abort(404)
    return project, html_path


@app.route("/projects/<project_id>/export")
def export_project(project_id):
    project, html_path = exportable_project(project_id)
    export_format = request.args.get("format", "figma")
    if export_format == "html":
        return send_file(html_path, as_attachment=True,
                         download_name=f"prototype-{project_id}.html")
    if export_format != "figma":
        return "不支持的导出格式", 400
    return render_template("figma_export.html", project=project)


@app.route("/projects/<project_id>/figma-source")
def figma_source(project_id):
    from flask import Response
    import re
    _, html_path = exportable_project(project_id)
    html = html_path.read_text(encoding="utf-8")
    collector = (BASE_DIR / "static" / "figma-capture.js").read_text(encoding="utf-8")
    # Insert before the final closing body tag; original prototype files stay untouched.
    interactions = (BASE_DIR / "static" / "figma-interactions.js").read_text(encoding="utf-8")
    injection = "<script>" + interactions + "\n" + collector + "</script>"
    endings = list(re.finditer(r"</body\s*>", html, re.IGNORECASE))
    offset = endings[-1].start() if endings else len(html)
    response = Response(html[:offset] + injection + html[offset:], mimetype="text/html")
    response.headers["Content-Security-Policy"] = (
        "sandbox allow-scripts; default-src 'none'; script-src 'unsafe-inline'; "
        "style-src 'unsafe-inline'; img-src data:; font-src data:; "
        "connect-src 'none'; form-action 'none'; base-uri 'none'; frame-src 'none'"
    )
    response.headers["Referrer-Policy"] = "no-referrer"
    return response


@app.route("/figma-plugin/download")
def figma_plugin_download():
    from io import BytesIO
    from zipfile import ZipFile, ZIP_DEFLATED
    archive = BytesIO()
    with ZipFile(archive, "w", ZIP_DEFLATED) as bundle:
        for name in ("manifest.json", "code.js", "ui.html", "README.md"):
            bundle.write(BASE_DIR / "figma-plugin" / name, name)
    archive.seek(0)
    return send_file(archive, mimetype="application/zip", as_attachment=True,
                     download_name="product-agent-figma-plugin.zip")


def refinement_context(project_id):
    try:
        project = project_manager.get_project(project_id)
        if project is None:
            abort(404)
        raw_requirement = project_manager.get_raw_requirement(project_id)
        content = project_manager.get_prd(project_id)
        html_path = project_manager.get_html_path(project_id)
    except ValueError:
        abort(404)
    return dict(project=project, raw_requirement=raw_requirement,
                original_prd=content, has_html=html_path is not None)


def workflow_response(directory, project, *, task_id=None):
    from workflow_document import validate_bundle
    data = validate_bundle(directory)
    if task_id:
        image_url = url_for('task_workflow_image', task_id=task_id)
        drawio_url = url_for('task_workflow_export', task_id=task_id, format='drawio')
        svg_url = url_for('task_workflow_export', task_id=task_id, format='svg')
    else:
        image_url = url_for('project_workflow_image', project_id=project['id'])
        drawio_url = url_for('project_workflow_export', project_id=project['id'], format='drawio')
        svg_url = url_for('project_workflow_export', project_id=project['id'], format='svg')
    return render_template('workflow.html', project=project, data=data, state='ready',
                           image_url=image_url, drawio_url=drawio_url, svg_url=svg_url, draft=bool(task_id))


@app.route('/projects/<project_id>/workflow')
def project_workflow(project_id):
    context = refinement_context(project_id)
    state, data = project_manager.workflow_status(project_id)
    if state == 'ready':
        return workflow_response(project_manager.project_path(project_id), context['project'])
    return render_template('workflow.html', project=context['project'], data=None,
        state=state, draft=False)


@app.route('/projects/<project_id>/workflow/generate', methods=['POST'])
def generate_project_workflow(project_id):
    refinement_context(project_id)
    return jsonify(error='Workflow 随 PRD、原型一起生成。请回到首页点击继续优化，生成完整配套版本。'), 410


def workflow_image_response(directory):
    from workflow_document import validate_bundle, workflow_svg
    data = validate_bundle(directory)
    try: svg = workflow_svg(data, request.args.get('flow') or None)
    except ValueError: abort(404)
    response = app.response_class(svg, mimetype='image/svg+xml')
    response.headers['Content-Security-Policy'] = "default-src 'none'; style-src 'unsafe-inline'; sandbox"
    response.headers['X-Content-Type-Options'] = 'nosniff'
    return response


@app.route('/projects/<project_id>/workflow/image')
def project_workflow_image(project_id):
    refinement_context(project_id)
    state, _ = project_manager.workflow_status(project_id)
    if state != 'ready': return '流程图缺失或已过期，请重新生成。', 409
    return workflow_image_response(project_manager.project_path(project_id))


def workflow_download_response(directory, name):
    from workflow_document import validate_bundle
    validate_bundle(directory)
    extension = request.args.get('format', 'drawio')
    if extension not in ('drawio', 'svg'): abort(400)
    return send_file(Path(directory)/('workflow.'+extension), as_attachment=True,
        download_name='workflow-'+name+'.'+extension,
        mimetype='application/xml' if extension=='drawio' else 'image/svg+xml')


@app.route('/projects/<project_id>/workflow/export')
def project_workflow_export(project_id):
    refinement_context(project_id)
    state, _ = project_manager.workflow_status(project_id)
    if state != 'ready': return '流程图缺失或已过期，请重新生成。', 409
    return workflow_download_response(project_manager.project_path(project_id), project_id)


@app.route('/refinement-tasks/<task_id>/workflow-image')
def task_workflow_image(task_id):
    job = owned_refinement_task(task_id)
    if not job['completed']['workflow']: abort(409)
    return workflow_image_response(refinement_jobs.path(task_id))


@app.route('/refinement-tasks/<task_id>/workflow-export')
def task_workflow_export(task_id):
    job = owned_refinement_task(task_id)
    if not job['completed']['workflow']: abort(409)
    return workflow_download_response(refinement_jobs.path(task_id), task_id)


@app.route("/edit")
def edit():
    project_id = request.args.get("project_id", "").strip()
    if not project_id:
        return redirect(url_for("index"))
    return render_template("refine.html", **refinement_context(project_id))


from refinement_jobs import RefinementJobs
refinement_jobs = RefinementJobs(project_manager, app.logger)


def owned_refinement_task(task_id):
    try:
        job = refinement_jobs.status(task_id)
    except (ValueError, FileNotFoundError):
        abort(404)
    if job['state'] == 'deleted' or job['owner'] != session.get('refinement_owner'):
        abort(404)
    return job


@app.route("/projects/<project_id>/refine", methods=["POST"])
def refine_project(project_id):
    context = refinement_context(project_id)
    changes = request.form.get("changes", "").strip()
    token = request.form.get("csrf_token", "")
    if not token or not secrets.compare_digest(token, session.get("csrf_token", "")):
        return jsonify(error="页面已过期，请刷新后重试，修改要求不会自动提交。"), 403
    if not changes or len(changes) > 20000:
        return jsonify(error="请填写 1–20000 字的修改要求。"), 400
    if not context["raw_requirement"] and not context["original_prd"]:
        return jsonify(error="原项目缺少需求和 PRD，无法优化。"), 400
    owner = session.setdefault('refinement_owner', secrets.token_urlsafe(32))
    # The service uses the configured manager; tests may replace it with isolated storage.
    refinement_jobs.manager = project_manager
    try:
        job = refinement_jobs.start(context, changes, owner)
    except ValueError as error:
        return jsonify(error=str(error)), 409
    target = url_for('refinement_task_page', task_id=job['id'])
    if request.accept_mimetypes.best == 'application/json':
        return jsonify(task_url=target, status_url=url_for('refinement_task_status', task_id=job['id'])), 202
    return redirect(target, code=303)


@app.route('/unfinished-tasks')
def unfinished_tasks():
    refinement_jobs.manager = project_manager
    owner = session.get('refinement_owner')
    attempts = refinement_jobs.history(owner, '*', limit=None, unfinished=True) if owner else []
    return render_template('unfinished_tasks.html', attempts=attempts)


@app.route('/generation-history')
def generation_history():
    refinement_jobs.manager = project_manager
    owner = session.get('refinement_owner')
    attempts = refinement_jobs.history(owner, '*') if owner else []
    return render_template('generation_history.html', attempts=attempts)


@app.route('/refinement-tasks/<task_id>')
def refinement_task_page(task_id):
    job = owned_refinement_task(task_id)
    if job['state'] == 'saved' and job.get('kind') == 'workflow':
        return redirect(url_for('project_workflow', project_id=job['source_id']), code=303)
    if job['state'] == 'saved' and job.get('kind', 'refine') == 'refine':
        saved = project_manager.get_project(job['saved_id'])
        if saved:
            current_id = saved['source_project_id'] if saved.get('applied_to_source_at') else saved['id']
            return redirect(url_for('index', _anchor='project-' + current_id), code=303)
    return render_template('refinement_task.html', job=job, attempts=refinement_jobs.history(job['owner'], job.get('source_id')))


@app.route('/refinement-tasks/<task_id>/status')
def refinement_task_status(task_id):
    job = owned_refinement_task(task_id)
    return jsonify(state=job['state'], stage=job['stage'], message=job['message'],
                   saved_id=job.get('saved_id'), elapsed_seconds=job.get('elapsed_seconds', 0),
                   stage_seconds=job.get('stage_seconds', {}), error_http=job.get('error_http'))


@app.route('/refinement-tasks/<task_id>/delete', methods=['POST'])
def delete_generation_task(task_id):
    owned_refinement_task(task_id)
    token = request.headers.get('X-CSRF-Token', '')
    if not token or not secrets.compare_digest(token, session.get('csrf_token', '')):
        return jsonify(error='页面已过期，请刷新后重试'), 403
    if (request.get_json(silent=True) or {}).get('confirmed') is not True:
        return jsonify(error='请先确认删除任务'), 400
    try:
        refinement_jobs.delete(task_id)
    except ValueError as error:
        return jsonify(error=str(error)), 409
    except OSError:
        return jsonify(error='删除未完成，请稍后重试'), 500
    return jsonify(deleted=True, task_id=task_id)


@app.route('/refinement-tasks/<task_id>/resume', methods=['POST'])
def resume_generation_task(task_id):
    job = owned_refinement_task(task_id)
    token = request.form.get('csrf_token', '') or request.headers.get('X-CSRF-Token', '')
    if not token or not secrets.compare_digest(token, session.get('csrf_token', '')):
        return jsonify(error='页面已过期，请刷新后重试'), 403
    try:
        refinement_jobs.resume(task_id)
    except ValueError as error:
        return render_template('refinement_task.html', job=job, error=str(error)), 409
    return redirect(url_for('refinement_task_page', task_id=task_id), code=303)


@app.route('/refinement-tasks/<task_id>/cancel', methods=['POST'])
def cancel_generation_task(task_id):
    owned_refinement_task(task_id)
    token = request.headers.get('X-CSRF-Token', '')
    if not token or not secrets.compare_digest(token, session.get('csrf_token', '')):
        return jsonify(error='页面已过期，请刷新后重试'), 403
    job = refinement_jobs.cancel(task_id)
    return jsonify(state=job['state'], message=job['message'])


@app.route('/refinement-tasks/<task_id>/<artifact>')
def refinement_task_artifact(task_id, artifact):
    job = owned_refinement_task(task_id)
    if artifact not in ('prd', 'preview', 'workflow') or not job['completed'].get({'preview':'html'}.get(artifact, artifact)):
        abort(404)
    if artifact == 'workflow':
        project = dict(job['source'], version=job['source'].get('version',1) + (1 if job.get('kind')=='refine' else 0))
        return workflow_response(refinement_jobs.path(task_id), project, task_id=task_id)
    file = refinement_jobs.path(task_id) / ('requirement.md' if artifact == 'prd' else 'prototype.html')
    if request.args.get('download') == '1':
        return send_file(file, as_attachment=True, download_name=file.name)
    if artifact == 'prd':
        return render_template('prd.html', content=file.read_text(encoding='utf-8'))
    return send_file(file, mimetype='text/html')


@app.route('/refinement-tasks/<task_id>/save', methods=['POST'])
def save_refinement_task(task_id):
    job = owned_refinement_task(task_id)
    token = request.form.get('csrf_token', '')
    if not token or not secrets.compare_digest(token, session.get('csrf_token', '')):
        abort(403)
    mode = request.form.get('mode')
    if mode == 'replace' and request.form.get('confirmed') != 'yes':
        return render_template('refinement_task.html', job=job, error='请先勾选确认覆盖。'), 400
    try:
        revision_id = refinement_jobs.save(task_id, mode)
    except (ValueError, FileNotFoundError) as error:
        return render_template('refinement_task.html', job=refinement_jobs.status(task_id), error=str(error)), 409
    except OSError:
        return render_template('refinement_task.html', job=job, error='保存失败，请重试；原版未修改。'), 500
    saved = project_manager.get_project(revision_id)
    current_id = saved['source_project_id'] if saved.get('applied_to_source_at') else revision_id
    return redirect(url_for('index', _anchor='project-' + current_id), code=303)


@app.route("/projects/<project_id>/refinement-result")
def refinement_result(project_id):
    project = refinement_context(project_id)['project']
    current_id = project['source_project_id'] if project.get('applied_to_source_at') else project_id
    return redirect(url_for('index', _anchor='project-' + current_id), code=303)


@app.route("/projects/<project_id>/apply-refinement", methods=["POST"])
def apply_refinement(project_id):
    token = request.form.get("csrf_token", "")
    if not token or not secrets.compare_digest(token, session.get("csrf_token", "")):
        abort(403)
    if request.form.get("confirmed") != "yes":
        return "请确认覆盖原版本后再操作。", 400
    try:
        project_manager.apply_refinement(project_id)
    except (ValueError, FileNotFoundError) as error:
        return jsonify(error=str(error)), 409
    except OSError:
        app.logger.exception("应用优化结果失败：%s", project_id)
        return "覆盖失败，原版本已恢复，优化新版本仍保留。请返回重试。", 500
    project = project_manager.get_project(project_id)
    return redirect(url_for("index", _anchor="project-" + project["source_project_id"]), code=303)


@app.errorhandler(404)
def not_found(error):

    return """
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <title>页面不存在</title>
    </head>
    <body style="
        padding: 40px;
        font-family: Arial, sans-serif;
    ">
        <h1>页面不存在</h1>
        <p>没有找到对应的项目或文件。</p>
        <a href="/">返回首页</a>
    </body>
    </html>
    """, 404


if __name__ == "__main__":

    print(
        """
==============================
 Product Agent 2.0

 Web 服务启动：

 http://127.0.0.1:5001

==============================
"""
    )

    app.run(
        host="127.0.0.1",
        port=5001,
        debug=True
    )