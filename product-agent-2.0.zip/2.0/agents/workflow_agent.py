import json
import re
from pathlib import Path
from llm import LLM
from workflow_document import prototype_text, write_workflow

class WorkflowAgent:
    def run(self, *, output_dir):
        directory=Path(output_dir)
        prd=(directory/'requirement.md').read_text(encoding='utf-8')
        html=(directory/'prototype.html').read_text(encoding='utf-8')
        text=prototype_text(html)
        if len(prd)+len(text)>180000:
            raise ValueError('当前项目过长，无法完整核对业务流程，请拆分需求')
        prompt='''你是业务流程分析师。根据下面同一版本的完整 PRD 和 HTML 可见文字，生成产品自身的业务流程图，不是 AI 助手生成文档的工作过程。
只输出 JSON，不输出 Markdown 或 XML。合并重复步骤，优先 1–4 个主要业务流程，每个流程通常 5–15 个节点。
不要新增 PRD 和原型没有依据的业务能力、权限或通知服务。发现二者冲突、规则不明确时，在 notes 写明；无依据但为表示分支必须展示的步骤必须 pending=true，文字加“待确认”。不得声称这些步骤已经实现。
每个业务处理或判断节点都要提供 evidence，quote 必须是 PRD 原文或原型可见文字中的连续原句，不可改写。没有证据只能 pending=true。
节点按业务执行顺序排列，节点文字尽量在 24 字以内。每条流程都必须有 start 和 end；所有节点都能从 start 到达并能到达 end；decision 必须至少两个标有条件的出线。不要把返回的线连到 start，请连回相应处理节点。
JSON 格式（示例仅表示结构，不能照搬业务内容）：
{"schema":"product-agent/workflow","version":1,"title":"业务流程","actors":["用户","系统"],"notes":[],"flows":[{"id":"main","title":"主业务流程","nodes":[{"id":"start","type":"start","label":"开始","actor":"用户","evidence":[]},{"id":"action","type":"process","label":"来自资料的操作","actor":"用户","evidence":[{"source":"prd","quote":"必须来自实际 PRD 的原句"}]},{"id":"end","type":"end","label":"结束","actor":"系统","evidence":[]}],"edges":[{"source":"start","target":"action","label":""},{"source":"action","target":"end","label":""}]}]}
限制：最多 8 个角色、8 条流程、每条最多 40 个节点和 100 条连线，总节点不超过 120。source 只能是 prd 或 prototype。节点 id 同一流程内唯一。notes 为文字列表。
''' + '\n当前 PRD：\n'+prd+'\n当前 HTML 原型可见文字（包含各页面）：\n'+text
        result=LLM().chat(prompt)
        if not isinstance(result,str):raise ValueError('流程图生成结果为空')
        result=re.sub(r'^```(?:json)?\s*|\s*```$', '', result.strip())
        data=json.loads(result)
        return write_workflow(data,directory)
