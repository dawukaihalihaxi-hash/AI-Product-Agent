import os
from pathlib import Path

from llm import LLM


class RequirementAgent:

    def __init__(self):
        self.llm = LLM()


    def run(self, user_requirement, *, output_dir=None):

        print("========== Requirement Agent ==========")

        # 读取需求分析 Prompt
        with open(
            Path(__file__).resolve().parent.parent / "prompts" / "requirement.txt",
            "r",
            encoding="utf-8"
        ) as f:

            prompt = f.read()


        final_prompt = f"""
{prompt}


========================

用户需求：

{user_requirement}
"""


        # 调用大模型
        result = self.llm.chat(final_prompt)


        # 创建输出目录
        destination = Path(output_dir) if output_dir is not None else Path(__file__).resolve().parent.parent / "output"
        os.makedirs(
            destination,
            exist_ok=True
        )


        # 保存 PRD
        if not result or not result.strip():
            raise ValueError("PRD 生成结果为空")
        output_file = destination / "requirement.md"


        with open(
            output_file,
            "w",
            encoding="utf-8"
        ) as f:

            f.write(result)


        print(f"✅ 已保存到：{output_file}")


        return result