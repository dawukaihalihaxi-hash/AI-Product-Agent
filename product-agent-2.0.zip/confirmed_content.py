"""Keep discussion advice out of confirmed drafts and generation inputs."""
import re

def _advisory_title(title):
    title=re.sub(r'^\s*(?:[一二三四五六七八九十百\d]+[、.．:)）]\s*)','',title)
    title=re.sub(r'[（(](?:仅供参考|供参考|可选)[）)]','',title)
    title=re.sub(r'[\s*：:]+','',title)
    return title in {'优化建议','参考建议','建议','待确认','待确认事项','参考事项','未来方向','后续方向','后续规划','演示假设与待确认事项','假设与待确认事项','优化建议与待确认事项','建议与待确认事项'}

def confirmed_text(text):
    if not isinstance(text,str):return ''
    lines=[];blocked_level=None;fence=False
    for line in text.splitlines():
        heading=re.match(r'^\s*(#{1,6})\s+(.+?)\s*#*\s*$',line) if not fence else None
        if heading:
            level=len(heading[1])
            if blocked_level is not None and level<=blocked_level:blocked_level=None
            if blocked_level is None and _advisory_title(heading[2]):blocked_level=level
        elif not fence and _advisory_title(line.strip()):
            blocked_level=1
        if blocked_level is None:lines.append(line)
        if line.strip().startswith('```'):fence=not fence
    return '\n'.join(lines).strip()
