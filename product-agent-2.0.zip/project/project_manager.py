import json
import shutil
import threading

_apply_lock = threading.RLock()

from datetime import datetime
from pathlib import Path



class ProjectManager:


    def __init__(self):

        # project_manager.py 在：
        # 2.0/project/project_manager.py
        #
        # 所以 parent.parent 才是：
        # 2.0/

        self.base_dir = (
            Path(__file__)
            .resolve()
            .parent
            .parent
        )


        # 当前生成文件目录

        self.output_dir = (
            self.base_dir
            /
            "output"
        )


        # 历史项目目录

        self.projects_dir = (
            self.base_dir
            /
            "project"
            /
            "projects"
        )


        self.projects_dir.mkdir(
            parents=True,
            exist_ok=True
        )


        from durable_store import DurableStore
        self.store=DurableStore.from_env()
        self.store.restore(self.projects_dir)



    def create_project(self, raw_requirement, project_name=None, *, output_dir=None,
                       source_project=None, change_request=None, source_fingerprint=None,
                       require_bundle=False, owner=None, project_id=None):
        import os
        from uuid import uuid4
        from workflow_document import WORKFLOW_FILES, validate_bundle
        if not raw_requirement.strip(): raise ValueError("需求不能为空")
        project_name = project_name or raw_requirement.splitlines()[0].strip()[:30] or "未命名项目"
        artifacts = Path(output_dir) if output_dir is not None else self.output_dir
        has_workflow = (artifacts / 'workflow.json').is_file()
        if require_bundle or has_workflow:
            validate_bundle(artifacts)
            has_workflow = True
        project_id = project_id or datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        target = self.project_path(project_id)
        if target.exists():
            existing=self.get_project(project_id)
            if not existing or existing.get('owner')!=owner or (target/'raw_requirement.txt').read_text(encoding='utf-8')!=raw_requirement:
                raise ValueError('保存编号冲突，原项目未修改。')
            from workflow_document import validate_bundle
            if require_bundle:validate_bundle(target)
            self.store.save('project',project_id,target,owner)
            return existing
        stage = self.projects_dir / ('.create-' + uuid4().hex)
        stage.mkdir()
        try:
            for name in ('requirement.md', 'prototype.html','scope.json') + (WORKFLOW_FILES if has_workflow else ()):
                if (artifacts/name).is_file(): shutil.copy2(artifacts/name, stage/name)
            (stage/'raw_requirement.txt').write_text(raw_requirement, encoding='utf-8')
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            info = dict(id=project_id, name=project_name, created_at=now, updated_at=now,
                        has_prd=(stage/'requirement.md').is_file(),
                        has_html=(stage/'prototype.html').is_file(), has_workflow=has_workflow,
                        bundle_version=1 if has_workflow else 0)
            if owner is not None:info['owner']=owner
            elif source_project and source_project.get('owner'):info['owner']=source_project['owner']
            if source_project is not None:
                info.update(source_project_id=source_project['id'],
                    root_project_id=source_project.get('root_project_id', source_project['id']),
                    version=source_project.get('version',1)+1,
                    change_request=change_request or '', source_fingerprint=source_fingerprint)
            (stage/'info.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf-8')
            os.replace(stage, target)
            self.store.save('project',project_id,target,info.get('owner'))
            return info
        finally:
            if stage.exists(): shutil.rmtree(stage)

    def list_projects(self):


        projects = []



        if not self.projects_dir.exists():

            return projects




        for item in self.projects_dir.iterdir():


            if not item.is_dir() or item.name.startswith("."):

                continue



            info_file = (
                item
                /
                "info.json"
            )



            if not info_file.exists():

                continue




            with open(
                info_file,
                "r",
                encoding="utf-8"
            ) as f:


                info = json.load(f)
                # Applied revisions remain on disk as backups, not duplicate visible projects.
                if info.get("applied_to_source_at") and self.get_project(info["source_project_id"]):
                    continue
                projects.append(info)




        projects.sort(
            key=lambda x:
            x.get(
                "created_at",
                ""
            ),
            reverse=True
        )



        return projects






    def project_path(self, project_id):
        import re
        if not re.fullmatch(r"[0-9]{8}_[0-9]{6}_[0-9]{6}", project_id):
            raise ValueError("无效项目编号")
        path = self.projects_dir / project_id
        if path.is_symlink() or path.resolve().parent != self.projects_dir.resolve():
            raise ValueError("无效项目路径")
        return path

    def delete_project(self, project_id):
        path = self.project_path(project_id)
        if not path.is_dir():
            return False
        info=self.get_project(project_id) or {}
        self.store.save('project',project_id,path,info.get('owner'),deleted=True)
        shutil.rmtree(path)
        return True

    def get_project(
        self,
        project_id
    ):


        info_file = (

            self.project_path(project_id)
            /
            "info.json"

        )


        if not info_file.exists():

            return None



        with open(
            info_file,
            "r",
            encoding="utf-8"
        ) as f:


            return json.load(f)







    def get_raw_requirement(self, project_id):
        path = self.project_path(project_id) / "raw_requirement.txt"
        return path.read_text(encoding="utf-8") if path.is_file() else ""

    def get_prd(
        self,
        project_id
    ):


        file = (

            self.project_path(project_id)
            /
            "requirement.md"

        )


        if not file.exists():

            return None



        return file.read_text(
            encoding="utf-8"
        )







    def get_html_path(
        self,
        project_id
    ):


        file = (

            self.project_path(project_id)
            /
            "prototype.html"

        )


        if not file.exists():

            return None



        return file

    def rename_project(self, project_id, name):
        import os
        import tempfile
        import unicodedata
        if not isinstance(name, str):
            raise ValueError("项目名称必须是文字")
        name = name.strip()
        if not name or len(name) > 80:
            raise ValueError("项目名称请填写 1–80 个字")
        if any(unicodedata.category(char) == "Cc" for char in name):
            raise ValueError("项目名称不能包含换行或控制字符")
        project = self.get_project(project_id)
        if project is None:
            return None
        project["name"] = name
        project["updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        target = self.project_path(project_id) / "info.json"
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=target.parent,
                                             prefix=".info-", suffix=".tmp", delete=False) as stream:
                temporary = Path(stream.name)
                json.dump(project, stream, ensure_ascii=False, indent=2)
            os.replace(temporary, target)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)
        self.store.save('project',project_id,self.project_path(project_id),project.get('owner'))
        return project

    def apply_refinement(self, project_id):
        with _apply_lock:
            return self._apply_refinement(project_id)

    def _apply_refinement(self, project_id):
        """Keep generated revision; back up and replace only its unchanged source."""
        import os
        import tempfile
        from uuid import uuid4
        revision = self.get_project(project_id)
        if not revision or not revision.get("source_project_id"):
            raise ValueError("没有可应用的优化版本。")
        if revision.get("applied_to_source_at"):
            return
        source_id = revision["source_project_id"]
        source = self.get_project(source_id)
        if not source:
            raise ValueError("原版本已删除；优化结果仍作为新版本保留。")
        # Content fingerprint prevents replacing edits made after this revision began.
        expected = revision.get("source_fingerprint")
        if not expected or expected != self.project_fingerprint(source_id):
            raise ValueError("原版本已发生变化，请基于当前版本重新优化；本次新版本仍保留。")
        source_path = self.project_path(source_id)
        revision_path = self.project_path(project_id)
        from workflow_document import WORKFLOW_FILES, validate_bundle
        bundled = bool(revision.get('has_workflow'))
        if not bundled:
            raise ValueError('新版本缺少配套流程图，请重新生成三份内容后再覆盖')
        if bundled: validate_bundle(revision_path)
        replace_names = ("requirement.md", "prototype.html", "raw_requirement.txt") + (("scope.json",) if (revision_path/"scope.json").is_file() else ()) + (WORKFLOW_FILES if bundled else ())
        for name in replace_names:
            if not (revision_path / name).is_file():
                raise ValueError("优化文件不完整，不能覆盖。")
        backup = self.projects_dir / (".backup-" + source_id + "-" + uuid4().hex)
        shutil.copytree(source_path, backup)
        self.store.save('archive',backup.name,backup,source.get('owner'))
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        updated = dict(source, updated_at=now, has_prd=True, has_html=True,
                       has_workflow=bundled, bundle_version=1 if bundled else 0,
                       version=revision.get("version", source.get("version", 1)),
                       applied_revision_id=project_id, change_request=revision.get("change_request", ""))
        try:
            with tempfile.TemporaryDirectory(dir=self.projects_dir, prefix=".apply-") as directory:
                stage = Path(directory)
                for name in replace_names:
                    shutil.copy2(revision_path / name, stage / name)
                (stage / "info.json").write_text(json.dumps(updated, ensure_ascii=False, indent=2), encoding="utf-8")
                for file in stage.iterdir():
                    os.replace(file, source_path / file.name)
                revision["applied_to_source_at"] = now
                (stage / "revision.json").write_text(json.dumps(revision, ensure_ascii=False, indent=2), encoding="utf-8")
                os.replace(stage / "revision.json", revision_path / "info.json")
                self.store.save_many([('project',source_id,source_path,source.get('owner')),('project',project_id,revision_path,revision.get('owner'))])
        except Exception:
            for name in replace_names:
                if not (backup/name).exists(): (source_path/name).unlink(missing_ok=True)
            for file in backup.iterdir():
                shutil.copy2(file, source_path / file.name)
            raise

    def project_fingerprint(self, project_id):
        import hashlib
        digest = hashlib.sha256()
        from workflow_document import WORKFLOW_FILES
        for name in ("info.json", "requirement.md", "prototype.html", "raw_requirement.txt") + WORKFLOW_FILES:
            path = self.project_path(project_id) / name
            digest.update(name.encode())
            digest.update(path.read_bytes() if path.is_file() else b"missing")
        if (self.project_path(project_id)/'scope.json').is_file():digest.update((self.project_path(project_id)/'scope.json').read_bytes())
        return digest.hexdigest()

    def workflow_status(self, project_id):
        from workflow_document import validate_bundle
        directory = self.project_path(project_id)
        if not (directory/'workflow.json').exists(): return 'missing', None
        try: return 'ready', validate_bundle(directory)
        except (ValueError, OSError): return 'stale', None

    def attach_workflow(self, project_id, directory, expected_fingerprint):
        """Upgrade an old project's matching diagram without changing its PRD/HTML or version."""
        import os
        import tempfile
        from workflow_document import WORKFLOW_FILES, validate_bundle
        from uuid import uuid4
        with _apply_lock:
            if self.project_fingerprint(project_id) != expected_fingerprint:
                raise ValueError('原项目已变化，未写入流程图，请基于最新版本重新生成')
            info = self.get_project(project_id)
            if info is None: raise ValueError('原项目已删除')
            validate_bundle(directory)
            source = self.project_path(project_id)
            for name in ('requirement.md','prototype.html'):
                if (source/name).read_bytes() != (Path(directory)/name).read_bytes():
                    raise ValueError('流程图来源与当前版本不一致')
            backup = self.projects_dir / ('.backup-workflow-' + uuid4().hex)
            shutil.copytree(source, backup)
            try:
                with tempfile.TemporaryDirectory(dir=self.projects_dir, prefix='.workflow-') as tmp:
                    stage = Path(tmp)
                    for name in WORKFLOW_FILES: shutil.copy2(Path(directory)/name, stage/name)
                    info.update(has_workflow=True, bundle_version=1, updated_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                    (stage/'info.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf-8')
                    for file in stage.iterdir(): os.replace(file, source/file.name)
                    self.store.save('project',project_id,source,info.get('owner'))
            except Exception:
                for name in WORKFLOW_FILES:
                    if not (backup/name).exists(): (source/name).unlink(missing_ok=True)
                for file in backup.iterdir(): shutil.copy2(file, source/file.name)
                raise
