import os
bind = '0.0.0.0:' + os.environ.get('PORT', '10000')
workers = 1
worker_class = 'gthread'
threads = 8
# Background jobs are local threads. Multiple workers would misreport each other's jobs.
timeout = 300
graceful_timeout = 30
accesslog = '-'
errorlog = '-'
