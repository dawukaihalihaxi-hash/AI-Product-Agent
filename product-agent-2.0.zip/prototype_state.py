"""Describe actual shared data and inspect literal patches without inventing mappings."""
import json,re

def tokens(source):
    pattern=r'''//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`|[A-Za-z_$][\w$]*|\.\.\.|[^\s]'''
    return [m.group() for m in re.finditer(pattern,source) if not m.group().startswith(('//','/*'))]

def patch_keys(source):
    ts=tokens(source);keys=[]
    for i in range(len(ts)-5):
        if ts[i:i+5]!=['PA','.','update','(','{']:continue
        j=i+5;depth=0;expect=True
        while j<len(ts):
            t=ts[j]
            if t=='}' and depth==0:break
            if depth==0 and expect:
                if re.fullmatch(r'[A-Za-z_$][\w$]*',t) or t[:1] in ('"',"'"):
                    if j+1<len(ts) and ts[j+1] in (':',',','}'):
                        keys.append(t.strip('\"\''))
                expect=False
            if t in ('{','[','('):depth+=1
            elif t in ('}',']',')'):depth-=1
            elif t==',' and depth==0:expect=True
            j+=1
    return list(dict.fromkeys(keys))

def state_instructions(scope,completed=None):
    state=scope.get('shared_state',{})
    lines=['实际共享数据读写规范（优先于通用示例及旧版代码）：',
           'PA.update只浅合并顶层；允许的顶层字段：'+json.dumps(list(state),ensure_ascii=False),
           '不得另造顶层容器或把嵌套字段提到顶层。数据路径与业务操作名无关。']
    for key,value in state.items():
        access='PA.state['+json.dumps(key)+']'
        lines.append(access+' 当前值：'+json.dumps(value,ensure_ascii=False))
        if isinstance(value,list):
            lines.append('更新此集合中已选中的记录：const rows = '+access+'; const next = rows.map(row => row === selectedRecord ? {...row, ...changes} : row); PA.update({['+json.dumps(key)+']: next});')
            lines.append('selectedRecord必须沿用已完成页面的选择标识和查找规则，不能默认第一条或猜测。changes仅包含本页已确认操作需要保存的字段；结果页和后续处理读取同一记录的相同字段，保留其他记录与未修改字段。')
        elif isinstance(value,dict):
            lines.append('更新此对象：PA.update({['+json.dumps(key)+']: {...'+access+', ...changes}}); 嵌套对象也需逐层保留已有字段。')
    lines.append('以下已完成模块只作数据衔接依据，不重写其HTML/CSS，不复制旧业务规则；最新明确修改仍优先。')
    for page_id,fragment in (completed or {}).items():
        scripts=re.findall(r'<script\b[^>]*>([\s\S]*?)</script\s*>',fragment,re.I)
        lines.append(page_id+' 已有读写脚本：\n'+'\n'.join(scripts))
    return '\n'.join(lines)

def state_errors(js,scope):
    allowed=set(scope.get('shared_state',{}))
    return [key for key in patch_keys(js) if allowed and key not in allowed]
