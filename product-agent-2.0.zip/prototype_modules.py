"""Resumable page generation, strict fragments and deterministic single-file assembly."""
import hashlib,json,re,os
from pathlib import Path
from html import escape
from html.parser import HTMLParser
from llm import LLM,ModelOutputError
from model_routing import notify,model_call_details
from scope_document import hash_text

CONTRACT_VERSION=4
class PrototypeError(ValueError):pass
VOID={'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}

class FragmentParser(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=False);self.stack=[];self.roots=[];self.ids=[];self.targets=[];self.errors=[];self.buttons=[];self.controls=[]
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if not self.stack:self.roots.append((tag,attrs))
        if tag in ('html','head','body','iframe','object','embed','base','link','meta'):self.errors.append('模块包含不允许的全局或外部标签')
        if tag in ('input','select','textarea') and attrs.get('type') not in ('hidden','radio','checkbox','submit','button'):self.controls.append(attrs)
        if tag=='button':
            attrs['_text']=[];self.buttons.append(attrs)
        if tag=='script':self.errors.append('页面内容不能嵌套script')
        if any(k.lower().startswith('on') for k in attrs):self.errors.append('模块事件必须在注册脚本中绑定')
        if 'id' in attrs:self.ids.append(attrs['id'])
        if attrs.get('data-pa-navigate'):self.targets.append(attrs['data-pa-navigate'])
        if tag not in VOID:self.stack.append(tag)
    def handle_data(self,data):
        if 'button' in self.stack and self.buttons:self.buttons[-1]['_text'].append(data)
    def handle_startendtag(self,tag,attrs):
        self.handle_starttag(tag,attrs)
        if tag not in VOID:self.handle_endtag(tag)
    def handle_endtag(self,tag):
        if tag in VOID:return
        if not self.stack or self.stack[-1]!=tag:self.errors.append('页面标签未正确闭合：'+tag)
        else:self.stack.pop()

def clean_fragment(text):
    if not isinstance(text,str):raise PrototypeError('页面模块未返回文本。')
    return re.sub(r'^\s*```(?:html)?\s*|\s*```\s*$','',text,flags=re.I).strip()

def normalize_actions(text,page):
    """Resolve mechanical action labels without asking the model to rewrite code."""
    actions={a['label']:'a'+str(i+1) for i,a in enumerate(page.get('actions',[]))}
    def replace(match):
        attrs,body=match.groups();label=re.sub('<[^>]+>','',body).strip()
        label=re.sub(r'\s+','',label)
        name=next((key for key in actions if label in (key,'确认'+key)),None)
        if not name and label=='确认' and len(actions)==1 and re.search(r'dialog|confirm',attrs,re.I):
            name=next(iter(actions));body=body.replace('确认','确认'+name,1)
        if name and not re.search(r'\bdata-pa-(?:navigate|close)\b',attrs):
            attrs=re.sub(r'\s+data-pa-action(?![-\w:])(?:\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]+))?','',attrs)
            attrs+=' data-pa-action="'+actions[name]+'"'
        return '<button'+attrs+'>'+body+'</button>'
    return re.sub(r'<button\b([^>]*)>([\s\S]*?)</button>',replace,text,flags=re.I)

def validate_fragment(text,page,scope):
    text=normalize_actions(clean_fragment(text),page)
    # Extract blocks independently; their order, optional marker attributes and
    # a redundant closing wrapper are packaging details, not missing page content.
    scripts=re.findall(r'<script\b([^>]*)>([\s\S]*?)</script\s*>',text,re.I)
    if any(re.search(r'\bsrc\s*=',attrs,re.I) for attrs,_ in scripts):raise PrototypeError('页面不能依赖外部脚本。')
    js='\n'.join(code for _,code in scripts)
    css='\n'.join(re.findall(r'<style\b[^>]*>([\s\S]*?)</style\s*>',text,re.I))
    html=re.sub(r'<(script|style)\b[^>]*>[\s\S]*?</\1\s*>','',text,flags=re.I).strip()
    html=re.sub(r'<!--.*?-->','',html,flags=re.S).strip()
    # Remove only extra trailing root closers; never manufacture missing content.
    while html.endswith('</section>'):
        probe=FragmentParser();probe.feed(html);probe.close()
        if not probe.stack and probe.errors==['页面标签未正确闭合：section']:html=html[:-10].rstrip()
        else:break
    if not scripts or not js.strip() or not html:raise PrototypeError('页面内容或交互脚本尚未完整返回。')
    if 'document.currentScript' in js:
        root_expr='document.getElementById('+json.dumps(page['id'])+')'
        anchor='const __pa_module_script_anchor={parentElement:'+root_expr+',parentNode:'+root_expr+',ownerDocument:document,closest:function(){return '+root_expr+';}};\n'
        js=anchor+js.replace('document.currentScript','__pa_module_script_anchor')
    ids=FragmentParser();ids.feed(html);ids.close()
    # Namespace selectors mechanically instead of spending another model call.
    for old in sorted(set(ids.ids),key=len,reverse=True):
        if old.startswith(page['id']):continue
        new=page['id']+'-'+old
        for quote in ('"',"'"):
            html=html.replace(quote+old+quote,quote+new+quote)
            js=js.replace(quote+old+quote,quote+new+quote)
        css=re.sub(r'#'+re.escape(old)+r'(?![\w-])','#'+new,css)
        js=re.sub(r'#'+re.escape(old)+r'(?![\w-])','#'+new,js)
    p=FragmentParser();p.feed(html);p.close()
    if p.stack or p.errors:raise PrototypeError((p.errors or ['页面标签未闭合'])[0])
    if len(p.roots)!=1 or p.roots[0][0]!='section':raise PrototypeError('模块只能有一个页面根section。')
    attrs=p.roots[0][1]
    if attrs.get('id')!=page['id'] or 'data-pa-page' not in attrs:raise PrototypeError('页面编号与锁定范围不一致。')
    if not attrs.get('data-pa-name'):raise PrototypeError('页面缺少Figma页面名称。')
    if len(set(p.ids))!=len(p.ids) or any(not i.startswith(page['id']) for i in p.ids):raise PrototypeError('页面控件编号须唯一并使用页面前缀。')
    allowed={item['id'] for item in scope['pages']}
    if any(target not in allowed for target in p.targets):raise PrototypeError('页面导航指向了未确认页面。')
    if re.search(r'@import|url\s*\(\s*[\'\"]?https?://',css,re.I):raise PrototypeError('页面不应依赖外部样式。')
    if re.search(r'</?script\b',js,re.I):raise PrototypeError('脚本中包含未转义的script标签。')
    action_ids={'a'+str(i+1):a['label'] for i,a in enumerate(page.get('actions',[]))}
    for button in p.buttons:
        if any(key in button for key in ('data-pa-navigate','data-pa-close')):continue
        label=''.join(button.get('_text',[])).strip()
        if label in ('重置','清空','取消','关闭','返回'):continue
        if button.get('data-pa-action') not in action_ids:
            raise PrototypeError('页面出现未确认操作：'+label+'。允许的操作只有：'+'、'.join(action_ids.values())+'；请移除其他业务按钮。')
        normalize=lambda value:''.join(re.findall(r'[\w\u3400-\u9fff]+',value))
        if normalize(label) not in (normalize(action_ids[button['data-pa-action']]),normalize('确认'+action_ids[button['data-pa-action']])):raise PrototypeError('业务按钮文字与本页面已确认操作不一致。')
    delegated=bool(re.search(r"on(?:input|change)\s*=|addEventListener\s*\(\s*.(?:input|change).|new\s+FormData|\.elements\b",js))
    if page.get('actions') and not delegated and not re.search(r'\.value\b|\.files\b|\.checked\b',js):
        for control in p.controls:
            control_id=control.get('id')
            if control_id and control_id not in js:raise PrototypeError('输入控件 '+control_id+' 没有与操作逻辑绑定；提交时必须读取实际输入.value，不能只校验未同步的PA.state。')
    state_keys=set(scope.get('shared_state',{}))
    for key in re.findall(r'PA\.update\s*\(\s*\{\s*([a-zA-Z_$][\w$]*)\s*:',js):
        if state_keys and key not in state_keys:raise PrototypeError('共享状态写入层级错误：'+key+' 不在顶层契约中；请更新实际嵌套对象后，通过PA.update({契约顶层对象名:更新对象})保存。')
    if 'document.currentScript' in js:raise PrototypeError('页面脚本在进入页面时才执行，不能使用document.currentScript；直接使用宿主传入的root。')
    if re.search(r'\b(?:fetch|eval)\s*\(|document\.write\s*\(',js):raise PrototypeError('演示模块不能调用外部接口或动态执行代码。')
    return dict(css=css,html=html,js=js)

def atomic_text(path,text):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);temporary=path.with_name(path.name+'.tmp');temporary.write_text(text,encoding='utf-8');os.replace(temporary,path)

def join_continuation(prefix,suffix):
    # Remove only a provable repeated overlap; never trim code across a cut string.
    suffix=re.sub(r'^```(?:html)?\s*|\s*```$','',suffix,flags=re.I)
    for length in range(min(len(prefix),len(suffix),2000),19,-1):
        if prefix.endswith(suffix[:length]):return prefix+suffix[length:]
    return prefix+suffix

THEME='''*{box-sizing:border-box}[hidden],.hidden{display:none!important}body{margin:0;background:#f3f5f9;color:#172033;font:15px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}.pa-header{padding:18px 28px;background:#fff;border-bottom:1px solid #dce3ef}.pa-header h1{font-size:21px;margin:0 0 12px}.pa-nav{display:flex;gap:8px;flex-wrap:wrap}button,a,input,textarea,select{font:inherit}button{cursor:pointer;border:1px solid #b7c8ee;border-radius:8px;background:white;color:#2356c9;padding:8px 14px}button:disabled{opacity:.5;cursor:default}.primary{background:#2459da;color:white}.danger{color:#d73333;border-color:#efaaaa}main{max-width:1320px;margin:auto;padding:24px}[data-pa-page][hidden]{display:none!important}.card{background:white;border:1px solid #dfe5ef;border-radius:12px;padding:20px;margin-bottom:16px}.row,.actions{display:flex;gap:12px;flex-wrap:wrap;align-items:center}.field{display:flex;flex-direction:column;gap:6px;margin:12px 0}input,textarea,select{border:1px solid #cbd5e1;border-radius:7px;padding:9px;max-width:100%}.table-wrap{overflow:auto}table{width:100%;border-collapse:collapse}th,td{text-align:left;border-bottom:1px solid #e4e9f0;padding:10px;white-space:nowrap}.muted{color:#68778f}.badge,.notice{border-radius:7px;background:#eef4ff;padding:5px 10px}.pa-feedback{position:fixed;right:20px;bottom:20px;background:#fff3dd;border:1px solid #ebc578;padding:12px;z-index:999}'''
RUNTIME='''(()=>{const pages=[...document.querySelectorAll('main>[data-pa-page]')],callbacks={},initial=__INITIAL__;let state=initial;const templates=Object.fromEntries(pages.map(p=>[p.id,p.innerHTML]));const key=__STORAGE_KEY__;try{const saved=sessionStorage.getItem(key);if(saved)state=Object.assign({},initial,JSON.parse(saved));}catch(e){}function save(){try{sessionStorage.setItem(key,JSON.stringify(state));}catch(e){}}function feedback(text){let node=document.getElementById('pa-feedback');node.hidden=false;node.textContent=text;}window.PA={state,update(patch){Object.assign(state,patch);save();},register(id,fn){if(!pages.some(p=>p.id===id)||typeof fn!=='function')throw Error('页面注册无效');callbacks[id]=fn;},navigate(id){const target=pages.find(p=>p.id===id);if(!target){feedback('页面不存在');return;}pages.forEach(p=>p.hidden=p!==target);target.innerHTML=templates[id];const records=state.records;const selected=state.selectedRecordId||state.currentRecordId||(Array.isArray(records)&&records.length===1?records[0].id:null);if(selected)target.dataset.paRecordId=selected;try{if(callbacks[id])callbacks[id](target);}catch(e){feedback('此页面部分演示交互发生错误，请检查输入或返回重试。');console.error(e);}window.scrollTo(0,0);}};document.addEventListener('click',e=>{const nav=e.target.closest('[data-pa-navigate]');if(nav){e.preventDefault();PA.navigate(nav.dataset.paNavigate);}const open=e.target.closest('[data-pa-open]');if(open){const dialog=document.getElementById(open.dataset.paOpen);if(dialog)dialog.hidden=false;}const close=e.target.closest('[data-pa-close]');if(close){const dialog=close.closest('[data-pa-dialog]');if(dialog)dialog.hidden=true;}});})();'''

def assemble(scope,fragments):
    pieces=[validate_fragment(fragments[p['id']],p,scope) for p in scope['pages']]
    ids=[]
    for p in pieces:
        parser=FragmentParser();parser.feed(p['html']);ids+=parser.ids
    if len(set(ids))!=len(ids):raise PrototypeError('组合原型出现重复控件编号。')
    def script_data(value):return json.dumps(value,ensure_ascii=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
    runtime=RUNTIME.replace('__INITIAL__',script_data(scope.get('shared_state',{}))).replace('__STORAGE_KEY__',script_data('pa-demo-'+hash_text(json.dumps(scope,sort_keys=True,ensure_ascii=False))[:20]))
    nav=''.join('<button type="button" data-pa-navigate="'+escape(p['id'],quote=True)+'">'+escape(p['actor']+' · '+p['name'])+'</button>' for p in scope['pages'])
    html='<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+escape(scope['title'])+'</title><style>'+THEME+'\n'+'\n'.join(p['css'] for p in pieces)+'</style></head><body><header class="pa-header"><h1>'+escape(scope['title'])+'</h1><nav class="pa-nav">'+nav+'</nav><small class="muted">前端演示：角色入口仅用于体验，不代表已接入真实身份认证。</small></header><main>'+''.join(p['html'] for p in pieces)+'</main><div id="pa-feedback" class="pa-feedback" hidden role="status"></div><script>'+runtime+'</script>'
    for page,piece in zip(scope['pages'],pieces):
        js=piece['js']
        if not re.search(r'PA\.register\s*\(',js):js='PA.register('+script_data(page['id'])+',function(root){'+js+'\n});'
        html+='<script>(()=>{'+js+'\n})();</script>'
    html+='<script>PA.navigate('+script_data(scope['pages'][0]['id'])+');</script></body></html>'
    return html

class ModularPrototype:
    def __init__(self,llm):self.llm=llm
    def run(self,directory,scope,prd,previous_html=None,change_request=None):
        directory=Path(directory);source_digest=hash_text(json.dumps(scope,ensure_ascii=False,sort_keys=True)+'\0'+prd+'\0'+(previous_html or '')+'\0'+str(CONTRACT_VERSION))
        root=directory/'.prototype-modules'/source_digest;root.mkdir(parents=True,exist_ok=True)
        manifest_path=root/'manifest.json'
        try:manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
        except (OSError,ValueError):manifest={'schema':'product-agent/prototype-modules','version':1,'source_digest':source_digest,'modules':{}}
        saved=manifest['modules'];fragments={}
        contract=json.dumps(dict(title=scope['title'],pages=[{k:p[k] for k in ('id','name','actor')} for p in scope['pages']],shared_state=scope.get('shared_state',{}),confirmed_rules=scope.get('locked_rules',[]),business_flow=scope.get('flow',[])),ensure_ascii=False)
        template=(Path(__file__).parent/'prompts/html_module.txt').read_text(encoding='utf-8')
        for index,page in enumerate(scope['pages']):
            name=page['id'];path=root/(name+'.html');partial=root/(name+'.partial.txt');entry=saved.get(name,{})
            try:
                text=path.read_text(encoding='utf-8')
                if entry.get('sha256')!=hash_text(text):raise PrototypeError('模块检查点不匹配')
                validate_fragment(text,page,scope);fragments[name]=text
                notify({'state':'module_reused','module':name,'title':page['name'],'index':index+1,'total':len(scope['pages'])});continue
            except (OSError,ValueError):pass
            notify({'state':'module_started','module':name,'title':page['name'],'index':index+1,'total':len(scope['pages'])})
            prompt=template+'\n已锁定的共享契约：\n'+contract+'\n仅生成当前页面：\n'+json.dumps(dict(page,actions=[dict(a,action_id='a'+str(i+1)) for i,a in enumerate(page.get('actions',[]))]),ensure_ascii=False)
            # For refinements, preserve the old page when an exact page ID exists.
            if previous_html:
                previous=re.search(r'<section\b[^>]*\bid=[\'\"]'+re.escape(name)+r'[\'\"][\s\S]*?</section>',previous_html,re.I)
                if previous and ('data-pa-name' not in previous.group().split('>')[0] or re.search(r'data-pa-name=[\'\"]'+re.escape(page['name'])+r'[\'\"]',previous.group().split('>')[0])):prompt+='\n旧版同页面参考（保留未涉及布局和内容）：\n'+previous.group()[:30000]
                prompt+='\n本次修改：'+(change_request or '')
            invalid=root/(name+'.invalid.txt')
            text=partial.read_text(encoding='utf-8') if partial.is_file() else ''
            cached_invalid=invalid.read_text(encoding='utf-8') if invalid.is_file() and not text else ''
            # At most two continuations, then retain partial and fail visibly.
            for continuation in range(0 if cached_invalid else 3):
                request=prompt if not text else prompt+'\n以下是已接收但截断的原文，只输出它后面的剩余字符，不重复、不重写前缀。断点可能在字符串中，应原样续接，完成其余片段：\n'+text
                try:
                    with model_call_details(operation='html_module',module=name):
                        chunk=self.llm.chat(request,max_tokens=6000,stream=True,retry_invalid_output=True,prefer_backup=getattr(self.llm,'last_role',None)=='备用模型')
                    text=join_continuation(text,chunk) if text else chunk
                    break
                except ModelOutputError as error:
                    if error.code!='output_truncated' or not error.partial_text:raise
                    text=join_continuation(text,error.partial_text) if text else error.partial_text
                    atomic_text(partial,text)
                    notify({'state':'artifact_checkpoint','artifact':'html_partial','module':name})
                    if len(text)>5000 and not re.search(r'<section\b',text,re.I):
                        atomic_text(invalid,text);partial.unlink(missing_ok=True);break
                    if continuation==2:raise PrototypeError('原型页面“'+page['name']+'”多次达到长度上限，已保留片段，可继续补全。') from None
            if cached_invalid:text=cached_invalid
            for repair in range(2):
                try:validate_fragment(text,page,scope);break
                except PrototypeError as error:
                    atomic_text(root/(name+'.invalid.txt'),text)
                    if repair:raise PrototypeError('原型页面“'+page['name']+'”格式修复未通过：'+str(error)) from None
                    with model_call_details(operation='html_repair',module=name):
                        repair_source=re.sub(r'<style\b[\s\S]*?(?:</style>|$)','<style data-pa-module-style></style>',text,flags=re.I)
                        text=self.llm.chat(prompt+'\n只修正当前模块格式或交互入口，不增加业务，返回完整模块。问题：'+str(error)+'\n现有可复用HTML与脚本（已移除冗余样式，缺失部分按契约补齐）：\n'+repair_source,max_tokens=6000,stream=True,retry_invalid_output=True,prefer_backup=getattr(self.llm,'last_role',None)=='备用模型')
            text=normalize_actions(clean_fragment(text),page);atomic_text(path,text);partial.unlink(missing_ok=True);invalid.unlink(missing_ok=True)
            saved[name]={'sha256':hash_text(text),'name':page['name']};atomic_text(manifest_path,json.dumps(manifest,ensure_ascii=False,indent=2));fragments[name]=text
            notify({'state':'artifact_checkpoint','artifact':'html_module','module':name,'title':page['name'],'index':index+1,'total':len(scope['pages'])})
        html=assemble(scope,fragments);atomic_text(directory/'prototype.html',html)
        return html
