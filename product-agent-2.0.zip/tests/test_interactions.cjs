/* Code-only regression: DOM model + Figma API contract substitute. No browser/Figma launch. */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.resolve(__dirname,'..');
const {spawnSync}=require('node:child_process');
class Element {
 constructor(tag,attrs={},text=''){this.tagName=tag.toUpperCase();this.nodeType=1;this.attrs={...attrs};this._text='';this.childNodes=text?[{nodeType:3,textContent:text}]:[];this.parentElement=null;this.disabled=false;
  this.style={setProperty:(key,val)=>{const map=this.styles();map[key]=val;this.attrs.style=Object.entries(map).map(([k,v])=>k+':'+v).join(';');},removeProperty:key=>{const m=this.styles();delete m[key];this.attrs.style=Object.entries(m).map(([k,v])=>k+':'+v).join(';');}};
  Object.defineProperty(this.style,'cssText',{get:()=>this.attrs.style||'',set:v=>this.attrs.style=v});
  this.classList={contains:key=>(this.attrs.class||'').split(/\s+/).includes(key),toggle:(key,on)=>{const keys=new Set((this.attrs.class||'').split(/\s+/).filter(Boolean));if(on===undefined)on=!keys.has(key);if(on)keys.add(key);else keys.delete(key);this.attrs.class=[...keys].join(' ');}};
 }
 styles(){return Object.fromEntries((this.attrs.style||'').split(';').filter(s=>s.includes(':')).map(s=>s.split(':').map(v=>v.trim())).map(([k,...v])=>[k,v.join(':')]));}
 get id(){return this.attrs.id||'';} get children(){return this.childNodes.filter(n=>n.nodeType===1);} get textContent(){return this._text+this.childNodes.map(n=>n.textContent).join('');} set textContent(t){this._text='';this.childNodes=t?[{nodeType:3,textContent:t}]:[];}
 get hidden(){return this.hasAttribute('hidden');}set hidden(v){if(v)this.setAttribute('hidden','');else this.removeAttribute('hidden');}
 getAttribute(k){return this.attrs[k]??null;}setAttribute(k,v){this.attrs[k]=String(v);}removeAttribute(k){delete this.attrs[k];}hasAttribute(k){return k in this.attrs;}
 appendChild(el){el.parentElement=this;this.childNodes.push(el);return el;}append(...els){els.forEach(el=>this.appendChild(el));}replaceChildren(...els){this.childNodes=[];this._text='';this.append(...els);}remove(){if(this.parentElement)this.parentElement.childNodes=this.parentElement.childNodes.filter(n=>n!==this);this.parentElement=null;}
 matches(selectors){return selectors.split(',').some(raw=>{let s=raw.trim();let good=true;s=s.replace(/\[([^=\]]+)(?:="([^"]*)")?\]/g,(_,k,v)=>{good=good&&this.hasAttribute(k)&&(v===undefined||this.getAttribute(k)===v);return '';});s=s.replace(/#([\w:-]+)/g,(_,id)=>{good=good&&this.id===id;return '';});s=s.replace(/\.([\w-]+)/g,(_,c)=>{good=good&&this.classList.contains(c);return '';});return good&&(!s||this.tagName.toLowerCase()===s);});}
 querySelectorAll(s){return this.children.flatMap(c=>[...(c.matches(s)?[c]:[]),...c.querySelectorAll(s)]);}querySelector(s){return this.querySelectorAll(s)[0]||null;}closest(s){return this.matches(s)?this:this.parentElement?.closest(s)||null;}
}
function model(){
 const body=new Element('body'),title=new Element('span',{id:'page-title'},'首页'),nav=new Element('nav');body.append(title,nav);
 const pages=['dashboard','reservation','settings'].map((id,i)=>new Element('section',{id,class:'view-section'+(i===0?' active':'')},id));
 const menus=pages.map((p,i)=>new Element('a',{onclick:`switchView('${p.id}', this)`,class:i===0?'active':''},p.id));nav.append(...menus);body.append(...pages);
 const dialog=new Element('div',{id:'detail-modal',class:'modal-overlay',style:'display:none'});const content=new Element('div',{id:'modal-content'});const close=new Element('button',{onclick:'closeModal()'},'关闭');dialog.append(content,close);body.append(dialog);
 const table=new Element('table');const headers=new Element('tr');headers.append(new Element('th',{},'姓名'),new Element('th',{},'操作'));const row=new Element('tr');const actions=new Element('td');const details=new Element('button',{onclick:"showDetail('record1')"},'详情');actions.append(details);row.append(new Element('td',{},'演示顾客'),actions);table.append(headers,row);pages[1].append(table,new Element('button',{onclick:'submitBooking()'},'提交'),new Element('input',{placeholder:'手机号'}));
 const document={body,getElementById:id=>(body.id===id?body:body.querySelector('#'+id)),querySelectorAll:s=>body.querySelectorAll(s),createElement:tag=>new Element(tag)};
 const computed=el=>({display:el.styles().display || (el.classList.contains('view-section')&&!el.classList.contains('active')?'none':'block'),visibility:'visible'});
 const context=vm.createContext({document,window:{},getComputedStyle:computed,innerWidth:1440,innerHeight:900,Date,Map,Set,console});
 vm.runInContext(fs.readFileSync(path.join(root,'static/figma-interactions.js'),'utf8'),context);
 const visible=el=>{for(let n=el;n;n=n.parentElement)if(computed(n).display==='none'||n.hidden)return false;return true;};
 const capture=async(options)=>{
  const walk=el=>({type:'FRAME',name:el.id||el.tagName,x:0,y:0,width:100,height:30,opacity:1,radii:[0,0,0,0],borders:Array.from({length:4},()=>({width:0,style:'none',color:null})),background:null,action:options.actionFor(el),children:el.children.filter(visible).map(walk)});
  return {width:1440,height:900,background:null,nodes:[walk(options.root)],elementCount:body.querySelectorAll('section,button,a,div,input').length,warnings:[]};
 };
 return {context,document,body,title,pages,menus,dialog,content,details,capture};
}
function runtime(failReactions=false){
 const nodes=[],messages=[];let index=0;
 const make=type=>{const n={id:'node:'+index++,type,children:[],removed:false,appendChild(c){this.children.push(c);c.parent=this;},resize(w,h){this.width=w;this.height=h;},async setReactionsAsync(reactions){if(failReactions)throw new Error('reaction write failed');for(const r of reactions){const a=r.actions[0];if(a.type==='NODE' && a.navigation==='NAVIGATE'){let top=this;while(top.parent && top.parent!==figma.currentPage)top=top.parent;const destination=nodes.find(n=>n.id===a.destinationId);if(!destination||destination.parent!==figma.currentPage||destination===top)throw new Error('NAVIGATE destination must be a different top-level frame');if(!figma.currentPage.flowStartingPoints.some(f=>f.nodeId===top.id))figma.currentPage.flowStartingPoints=[...figma.currentPage.flowStartingPoints,{nodeId:top.id,name:'Figma 自动起点'}];}}this.reactions=reactions;},remove(){this.removed=true;},setPluginData(){throw new Error('No ID');}};nodes.push(n);return n;};
 const initial=[{nodeId:'existing',name:'已有流程'}];let flows=initial;
 const figma={showUI(){},ui:{postMessage(m){messages.push(m);}},listAvailableFontsAsync:async()=>[{fontName:{family:'Inter',style:'Regular'}}],loadFontAsync:async()=>{},createFrame:()=>make('FRAME'),createText:()=>make('TEXT'),createRectangle:()=>make('RECTANGLE'),currentPage:{selection:[],flowStartingPoints:initial,appendChild(node){node.parent=this;}},viewport:{center:{x:0,y:0},scrollAndZoomIntoView(){}},notify(){}};
 Object.defineProperty(figma.currentPage,'flowStartingPoints',{get:()=>flows,set:value=>{if(new Set(value.map(f=>f.nodeId)).size!==value.length)throw new Error('Found duplicate input nodeIds');flows=value;}});
 vm.runInContext(fs.readFileSync(path.join(root,'figma-plugin/code.js'),'utf8'),vm.createContext({figma,__html__:'',setTimeout,console}));
 return {figma,nodes,messages,initial};
}
(async()=>{
 const m=model(),before=JSON.stringify(m.body,(key,val)=>['parentElement','style','classList'].includes(key)?undefined:val);
 const api=m.context.window.productAgentInteractions;
 const v2=await api.capturePrototype(m.capture);
 assert.equal(v2.version,2);assert.equal(v2.frames.filter(f=>f.kind==='screen').length,3);
 assert.ok(v2.frames.find(f=>f.id==='overlay:detail-modal:record1'));
 assert.ok(v2.frames.find(f=>f.id==='overlay:unsupported'));
 assert.ok(v2.unsupportedActions.some(a=>a.label==='提交'));
 assert.equal(JSON.stringify(m.body,(key,val)=>['parentElement','style','classList'].includes(key)?undefined:val),before,'DOM state must be restored');
 assert.equal(m.title.textContent,'首页');
 const rt=runtime();await rt.figma.ui.onmessage({type:'import',scene:v2});
 const report=rt.messages.at(-1);assert.equal(report.type,'complete',JSON.stringify(report));assert.equal(report.screens,3);assert.ok(report.connections>=9);
 const reactions=rt.nodes.flatMap(n=>n.reactions||[]);assert.equal(reactions.filter(r=>r.actions[0].navigation==='NAVIGATE').length,6,'Three screens should each link only to the other two screens');for(const type of ['NAVIGATE','OVERLAY','CLOSE'])assert.ok(reactions.some(r=>r.trigger.type==='ON_CLICK'&&r.actions[0].navigation===type || type==='CLOSE'&&r.actions[0].type==='CLOSE'));
 assert.equal(rt.figma.currentPage.flowStartingPoints[0].nodeId,'existing');assert.equal(rt.figma.currentPage.flowStartingPoints.length,2);
 await rt.figma.ui.onmessage({type:'import',scene:v2});assert.equal(rt.messages.at(-1).type,'complete');
 assert.equal(rt.figma.currentPage.flowStartingPoints.length,3,'Repeated imports preserve earlier starts without duplicates');
 assert.equal(new Set(rt.figma.currentPage.flowStartingPoints.map(f=>f.nodeId)).size,3);
 for(const r of reactions)if(r.actions[0].type==='NODE')assert.ok(rt.nodes.some(n=>n.id===r.actions[0].destinationId));
 const flatten=ns=>ns.flatMap(n=>[n,...flatten(n.children||[])]);
 const invalid=JSON.parse(JSON.stringify(v2));flatten(invalid.frames[0].nodes).find(n=>n.action?.type==='NAVIGATE').action.target='missing';
 const bad=runtime();await bad.figma.ui.onmessage({type:'import',scene:invalid});assert.equal(bad.messages.at(-1).type,'error');assert.equal(bad.nodes.length,0);
 const failure=runtime(true);await failure.figma.ui.onmessage({type:'import',scene:v2});assert.equal(failure.messages.at(-1).type,'error');assert.ok(failure.nodes.filter(n=>n.parent===failure.figma.currentPage).every(n=>n.removed));assert.equal(failure.figma.currentPage.flowStartingPoints.length,1);
 const scrolling=JSON.parse(JSON.stringify(v2));
 scrolling.frames[0].nodes[0].scrollDirection='HORIZONTAL';
 const scrollingRuntime=runtime();await scrollingRuntime.figma.ui.onmessage({type:'import',scene:scrolling});
 assert.equal(scrollingRuntime.messages.at(-1).type,'complete');
 assert.ok(scrollingRuntime.nodes.some(node=>node.overflowDirection==='HORIZONTAL'&&node.clipsContent));
 const invalidScroll=JSON.parse(JSON.stringify(scrolling));invalidScroll.frames[0].nodes[0].scrollDirection='invalid';
 const invalidScrollRuntime=runtime();await invalidScrollRuntime.figma.ui.onmessage({type:'import',scene:invalidScroll});
 assert.equal(invalidScrollRuntime.messages.at(-1).type,'error');assert.equal(invalidScrollRuntime.nodes.length,0);
 const legacy={schema:v2.schema,version:1,width:1440,height:900,nodes:v2.frames[0].nodes.map(n=>({...n,action:undefined})),warnings:[]};const old=runtime();await old.figma.ui.onmessage({type:'import',scene:legacy});assert.equal(old.messages.at(-1).type,'complete');assert.equal(old.messages.at(-1).connections,0);assert.ok(old.messages.at(-1).warnings.some(w=>w.includes('旧版静态文件')));
 const declarative=new Element('button',{'data-pa-navigate':'settings'});assert.equal(api.describe(declarative).page.id,'settings');
 assert.equal(api.describe(new Element('button',{onclick:"switchView('reservation'); submitBooking()"})).type,'UNSUPPORTED');
 assert.equal(api.describe(new Element('a',{href:'#'})).type,'UNSUPPORTED');
 assert.equal(api.describe(new Element('button',{'data-pa-open':'detail-modal'})).type,'OVERLAY');
 assert.equal(api.describe(new Element('button',{onclick:"switchRole('customer')"})).type,'UNSUPPORTED'); // No customer page exists in this fixture.
 m.pages[2].setAttribute('id','customer');assert.equal(api.describe(new Element('button',{onclick:"switchRole('customer')"})).page.id,'customer');
 // Navigation markers must never be exported as additional screens.
 const marked=model();marked.menus.forEach((menu,index)=>menu.setAttribute('data-pa-page','menu-'+index));
 const markedScene=await marked.context.window.productAgentInteractions.capturePrototype(marked.capture);
 assert.equal(markedScene.frames.filter(f=>f.kind==='screen').length,3);
 assert.equal(new Set(markedScene.frames.map(f=>f.id)).size,markedScene.frames.length);
 for(const frame of markedScene.frames.filter(f=>f.kind==='screen')){
   const destinations=flatten(frame.nodes).filter(node=>node.action?.type==='NAVIGATE').map(node=>node.action.target);
   for(const page of marked.pages)assert.ok(destinations.includes('screen:'+page.id),'Every page must retain each sidebar menu and its navigation target');
 }

 // Real panels without HTML IDs still need unique frame identifiers.
 const anonymous=model();anonymous.menus.forEach(menu=>menu.remove());
 anonymous.pages.forEach(page=>{page.removeAttribute('id');page.setAttribute('data-pa-page','');});
 const anonymousScene=await anonymous.context.window.productAgentInteractions.capturePrototype(anonymous.capture);
 assert.equal(anonymousScene.frames.filter(f=>f.kind==='screen').length,3);
 assert.equal(new Set(anonymousScene.frames.map(f=>f.id)).size,anonymousScene.frames.length);
 if(process.env.PRODUCT_AGENT_REPAIRED_JSON){
   const repaired=JSON.parse(fs.readFileSync(process.env.PRODUCT_AGENT_REPAIRED_JSON,'utf8'));
   const repairedRuntime=runtime();await repairedRuntime.figma.ui.onmessage({type:'import',scene:repaired});
   assert.equal(repairedRuntime.messages.at(-1).type,'complete',JSON.stringify(repairedRuntime.messages.at(-1)));
   assert.equal(repairedRuntime.messages.at(-1).screens,4);
   console.log('PASS: repaired downloaded JSON imports four editable screens in API model');
 }
 const failureModel=model(),saved=failureModel.pages.map(p=>p.getAttribute('style'));
 await assert.rejects(failureModel.context.window.productAgentInteractions.capturePrototype(async()=>{throw new Error('capture error');}));
 assert.deepEqual(failureModel.pages.map(p=>p.getAttribute('style')),saved);

 const history=process.env.PRODUCT_AGENT_HISTORY||path.join(root,'project/projects');
 const py=`import json,sys
from pathlib import Path
from html.parser import HTMLParser
class Tree(HTMLParser):
 def __init__(self):
  super().__init__();self.root={'tag':'root','attrs':{},'children':[],'text':''};self.stack=[self.root]
 def handle_starttag(self,tag,attrs):
  n={'tag':tag,'attrs':dict((k,v or '') for k,v in attrs),'children':[],'text':''};self.stack[-1]['children'].append(n)
  if tag not in ['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr']:self.stack.append(n)
 def handle_endtag(self,tag):
  for i in range(len(self.stack)-1,0,-1):
   if self.stack[i]['tag']==tag:self.stack=self.stack[:i];break
 def handle_data(self,data):
  if self.stack[-1]['tag'] not in ['script','style']:self.stack[-1]['text']+=data
out=[]
for f in Path(sys.argv[1]).glob('*/prototype.html'):
 t=Tree();t.feed(f.read_text());out.append({'id':f.parent.name,'tree':t.root})
print(json.dumps(out))`;
 const parsed=spawnSync('python3',['-c',py,history],{encoding:'utf8'});assert.equal(parsed.status,0,parsed.stderr);
 for(const fixture of JSON.parse(parsed.stdout)){
  const convert=data=>{const e=new Element(data.tag,data.attrs,data.text);for(const c of data.children)e.appendChild(convert(c));return e;};
  const tree=convert(fixture.tree),body=tree.querySelector('body');
  const document={body,getElementById:id=>tree.querySelector('#'+id),querySelectorAll:s=>body.querySelectorAll(s),createElement:tag=>new Element(tag)};
  const computed=el=>({display:el.styles().display||((el.classList.contains('view-section')||el.classList.contains('page'))&&!el.classList.contains('active')?'none':'block'),visibility:'visible'});
  const context=vm.createContext({window:{},document,getComputedStyle:computed,innerWidth:1440,innerHeight:900,Date,Map,Set,console});
  vm.runInContext(fs.readFileSync(path.join(root,'static/figma-interactions.js'),'utf8'),context);
  const visible=el=>{for(let n=el;n;n=n.parentElement)if(computed(n).display==='none'||n.hidden)return false;return true;};
  const capture=async options=>{
   const walk=el=>({type:'FRAME',name:el.id||el.tagName,x:0,y:0,width:100,height:30,opacity:1,radii:[0,0,0,0],borders:Array.from({length:4},()=>({width:0,style:'none',color:null})),background:null,action:options.actionFor(el),children:el.children.filter(visible).map(walk)});
   return {width:1440,height:900,nodes:[walk(options.root)],elementCount:100,warnings:[]};
  };
  const scene=await context.window.productAgentInteractions.capturePrototype(capture);
  const expected=body.querySelectorAll('[data-pa-page],.view-section[id],.page[id]').filter(el=>!el.matches('button,a,input,select,textarea,[onclick],[role="button"]')).length||1;
  assert.equal(scene.frames.filter(f=>f.kind==='screen').length,expected);
  const menuTargets=body.querySelectorAll('a[data-pa-page]').map(el=>context.window.productAgentInteractions.describe(el)).filter(a=>a?.type==='NAVIGATE').map(a=>'screen:'+a.page.id);
  for(const frame of scene.frames.filter(f=>f.kind==='screen')){
    const targets=flatten(frame.nodes).filter(node=>node.action?.type==='NAVIGATE').map(node=>node.action.target);
    for(const target of menuTargets)assert.ok(targets.includes(target),'Historical sidebar navigation must remain present on every screen: '+target);
  }
  const r=runtime();await r.figma.ui.onmessage({type:'import',scene});assert.equal(r.messages.at(-1).type,'complete',JSON.stringify(r.messages.at(-1)));
  console.log('PASS historical markup:',fixture.id,expected,'screen(s),',r.messages.at(-1).connections,'native connections (DOM/API models only)');
 }

 console.log(`PASS: 3 screens; detail/limitation overlays; ${report.connections} native click reactions; valid destinations; automatic flow-start deduplication; repeated-import flow preservation; full rollback; v1 compatibility; declarative/legacy mappings; DOM restoration; no business script execution`);
})().catch(error=>{console.error(error);process.exitCode=1;});
