import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import test_features
from agents.workflow_agent import WorkflowAgent,WorkflowGenerationError,evidence_catalog,resolve_evidence
from workflow_document import validate_workflow
from workflow_fixtures import sample_workflow

class WorkflowV1Tests(unittest.TestCase):
    def test_reference_variants_resolve_to_real_source(self):
        catalog=evidence_catalog('# PRD','<body>原型</body>')
        for item in [{'ref':' p001 '},'P001',{'source':'PRD','quote':'# PRD'},{'source':'requirement.md','quote':'# PRD'}]:
            data=sample_workflow();data['flows'][0]['nodes'][1]['evidence']=[item]
            result=resolve_evidence(data,catalog)
            validate_workflow(result,'# PRD','<body>原型</body>')
            self.assertEqual(result['flows'][0]['nodes'][1]['evidence'],[{'source':'prd','quote':'# PRD'}])

    def test_invalid_source_explains_node_and_does_not_invent_evidence(self):
        data=sample_workflow();node=data['flows'][0]['nodes'][1];node['evidence']=[{'source':'unknown','quote':'# PRD'}]
        with self.assertRaises(WorkflowGenerationError) as error:resolve_evidence(data,evidence_catalog('# PRD',''))
        self.assertIn(node['id'],str(error.exception));self.assertIn('ref',str(error.exception))

    def test_alias_never_accepts_nonexistent_quote(self):
        data=sample_workflow();data['flows'][0]['nodes'][1]['evidence']=[{'source':'html','quote':'编造功能'}]
        result=resolve_evidence(data,evidence_catalog('# PRD','<body>原型</body>'))
        with self.assertRaisesRegex(ValueError,'引用在当前'):validate_workflow(result,'# PRD','<body>原型</body>')

    def test_agent_loads_single_business_flow_prompt(self):
        with tempfile.TemporaryDirectory() as tmp:
            directory=Path(tmp);(directory/'requirement.md').write_text('# PRD');(directory/'prototype.html').write_text('<body>原型</body>')
            data=sample_workflow();data['flows'][0]['nodes'][1]['evidence']=[{'ref':'P001'}]
            with patch('agents.workflow_agent.LLM.chat',return_value=json.dumps(data)) as model:
                WorkflowAgent().run(output_dir=directory)
            prompt=model.call_args.args[0]
            self.assertIn('flows 只放一个整体流程',prompt);self.assertIn('P001',prompt)
            self.assertTrue((directory/'workflow.svg').exists())

    def test_generic_terminal_role_uses_existing_adjacent_lane_only(self):
        data=sample_workflow();data['actors']=['用户']
        result=resolve_evidence(data,evidence_catalog('# PRD','<body>原型</body>'))
        self.assertEqual(result['flows'][0]['nodes'][-1]['actor'],'用户')
        validate_workflow(result,'# PRD','<body>原型</body>')
        bad=sample_workflow();bad['flows'][0]['nodes'][1]['actor']='未知管理员'
        with self.assertRaisesRegex(ValueError,'角色'):validate_workflow(resolve_evidence(bad,evidence_catalog('# PRD','')),'# PRD','')
