const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../static/refinement-task.js'),'utf8');
async function main(){
 function setup(response){
  let reloaded=0;const timers=[];
  const root={dataset:{state:'running',stage:'queued',statusUrl:'/status'}};
  const message={textContent:''},note={textContent:''},refresh={addEventListener(){}};
  const steps=['queued','prd','html','checking','ready'].map(stage=>({dataset:{stage},classList:{toggle(){}}}));
  const document={getElementById:id=>({'task':root,'task-message':message,'poll-message':note,'refresh-status':refresh}[id]),querySelectorAll:selector=>selector.includes('.steps')?steps:[]};
  const context={document,window:{location:{reload(){reloaded++;}}},AbortController,fetch:response,setTimeout:(fn,delay)=>{timers.push({fn,delay});return timers.length;},clearTimeout(){}};
  vm.runInNewContext(source,context);
  return {message,note,timers,get reloaded(){return reloaded;}};
 }
 async function settle(){for(let i=0;i<8;i++)await Promise.resolve();}
 let state=setup(async()=>({ok:true,json:async()=>({state:'running',stage:'html',message:'正在生成原型'})}));await settle();state=await state;await settle();
 assert.equal(state.message.textContent,'正在生成原型');assert.equal(state.reloaded,0);
 assert.ok(state.timers.some(t=>t.delay===2000));
 let ready=await setup(async()=>({ok:true,json:async()=>({state:'ready',stage:'ready',message:'待确认'})}));await settle();assert.equal(ready.reloaded,1);
 let broken=await setup(async()=>{throw Error('offline');});await settle();assert.equal(broken.reloaded,0);assert.match(broken.note.textContent,/不代表.*生成失败/);assert.ok(broken.timers.some(t=>t.delay===2000));
 let failed=await setup(async()=>({ok:true,json:async()=>({state:'failed',stage:'prd',message:'服务繁忙'})}));await settle();assert.equal(failed.reloaded,1);
 console.log('PASS: real stage progress, terminal result refresh, network interruption retries without false success');
}
main().catch(e=>{console.error(e);process.exitCode=1;});
