import time
import unittest
from pathlib import Path
from unittest.mock import patch
import test_features as fixtures
module=fixtures.module
from agents.requirement_agent import RequirementAgent
from agents.html_agent import HtmlAgent

class RefinementTests(unittest.TestCase):
    setUp=fixtures.FeatureTests.setUp
    tearDown=fixtures.FeatureTests.tearDown

    @staticmethod
    def generated_prd(requirement, *, output_dir):
        (Path(output_dir)/'requirement.md').write_text('# 更新后的 PRD',encoding='utf-8')
        return '# 更新后的 PRD'

    @staticmethod
    def generated_html(*,output_dir,previous_html=None,change_request=None):
        html='<!DOCTYPE html><html><body><h1>更新后的原型</h1></body></html>'
        (Path(output_dir)/'prototype.html').write_text(html,encoding='utf-8')
        return html

    def start(self,changes='增加手机号搜索'):
        response=self.client.post(f'/projects/{self.id}/refine',data={'csrf_token':self.token,'changes':changes},headers={'Accept':'application/json'})
        self.assertEqual(response.status_code,202)
        task_id=response.json['task_url'].rsplit('/',1)[1]
        return task_id

    def wait(self,task_id):
        deadline=time.monotonic()+3
        while time.monotonic()<deadline:
            job=module.refinement_jobs.status(task_id)
            if job['state']!='running':return job
            time.sleep(.005)
        self.fail('background task did not finish')

    def generate(self):
        with patch.object(RequirementAgent,'run',side_effect=self.generated_prd),patch.object(HtmlAgent,'run',side_effect=self.generated_html):
            task_id=self.start();job=self.wait(task_id)
        self.assertEqual(job['state'],'ready')
        return task_id

    def test_separate_edit_page(self):
        html=self.client.get(f'/edit?project_id={self.id}').get_data(as_text=True)
        self.assertIn('继续优化现有项目',html)
        self.assertIn('确认保存前',html)
        self.assertNotIn('action="/create"',html)
        self.assertEqual(self.client.get('/edit').status_code,302)

    def test_validation_no_ai(self):
        with patch.object(RequirementAgent,'run') as run:
            self.assertEqual(self.client.post(f'/projects/{self.id}/refine',data={'csrf_token':self.token,'changes':' '}).status_code,400)
            self.assertEqual(self.client.post(f'/projects/{self.id}/refine',data={'changes':'修改'}).status_code,403)
            run.assert_not_called()

    def test_generate_is_draft_until_user_saves(self):
        before={f.name:f.read_bytes() for f in self.manager.project_path(self.id).iterdir()}
        task_id=self.generate()
        self.assertEqual(len(self.manager.list_projects()),1)
        html=self.client.get(f'/refinement-tasks/{task_id}').get_data(as_text=True)
        for text in ['查看优化后 PRD','查看优化后原型','保存为独立新版本','确认覆盖原版']:self.assertIn(text,html)
        self.assertEqual(self.client.get(f'/refinement-tasks/{task_id}/prd').status_code,200)
        with self.client.get(f'/refinement-tasks/{task_id}/preview') as response:
            self.assertIn('更新后的原型',response.get_data(as_text=True))
        self.assertEqual(before,{f.name:f.read_bytes() for f in self.manager.project_path(self.id).iterdir()})
        response=self.client.post(f'/refinement-tasks/{task_id}/save',data={'csrf_token':self.token,'mode':'new'})
        self.assertEqual(response.status_code,303)
        self.assertEqual(len(self.manager.list_projects()),2)
        self.assertTrue(response.location.startswith('/#project-'))
        self.client.post(f'/refinement-tasks/{task_id}/save',data={'csrf_token':self.token,'mode':'new'})
        self.assertEqual(len(self.manager.list_projects()),2)

    def test_stage_progress_is_real_and_duplicate_request_reuses_task(self):
        import threading
        entered=threading.Event();release=threading.Event()
        def prd(*args,**kwargs):
            entered.set();release.wait(2);return self.generated_prd(*args,**kwargs)
        with patch.object(RequirementAgent,'run',side_effect=prd),patch.object(HtmlAgent,'run',side_effect=self.generated_html):
            task=self.start();self.assertTrue(entered.wait(1))
            try:
                status=self.client.get(f'/refinement-tasks/{task}/status').json
                self.assertEqual(status['stage'],'prd');self.assertEqual(status['state'],'running')
                self.assertEqual(self.start(),task)
            finally:release.set()
            self.wait(task)

    def test_timeout_failure_preserves_input_and_source(self):
        import requests
        with patch.object(RequirementAgent,'run',side_effect=requests.Timeout()):
            task=self.start('保留要求');job=self.wait(task)
        self.assertEqual(job['state'],'failed');self.assertIn('超时',job['message'])
        self.assertEqual(job['stage'],'prd');self.assertEqual(len(self.manager.list_projects()),1)
        self.assertIn('保留要求',self.client.get(f'/refinement-tasks/{task}').get_data(as_text=True))

    def test_incomplete_html_cannot_be_saved(self):
        with patch.object(RequirementAgent,'run',side_effect=self.generated_prd),patch.object(HtmlAgent,'run',return_value='invalid'):
            task=self.start();job=self.wait(task)
        self.assertEqual(job['state'],'failed')
        self.assertEqual(self.client.post(f'/refinement-tasks/{task}/save',data={'csrf_token':self.token,'mode':'new'}).status_code,409)
        self.assertEqual(len(self.manager.list_projects()),1)

    def test_task_owner_and_save_csrf(self):
        task=self.generate();url=f'/refinement-tasks/{task}'
        other=module.app.test_client()
        self.assertEqual(other.get(url).status_code,404)
        self.assertEqual(other.get(url+'/status').status_code,404)
        self.assertEqual(other.get(url+'/preview').status_code,404)
        self.assertEqual(self.client.post(url+'/save',data={'mode':'new'}).status_code,403)

    def test_cover_requires_confirmation_and_checks_source(self):
        task=self.generate();url=f'/refinement-tasks/{task}/save'
        self.assertEqual(self.client.post(url,data={'csrf_token':self.token,'mode':'replace'}).status_code,400)
        self.manager.rename_project(self.id,'原版改名')
        self.assertEqual(self.client.post(url,data={'csrf_token':self.token,'mode':'replace','confirmed':'yes'}).status_code,409)
        self.assertEqual(len(self.manager.list_projects()),1)
        self.assertEqual(self.client.post(url,data={'csrf_token':self.token,'mode':'new'}).status_code,303)

    def test_cover_backups_original(self):
        task=self.generate();url=f'/refinement-tasks/{task}/save'
        response=self.client.post(url,data={'csrf_token':self.token,'mode':'replace','confirmed':'yes'})
        self.assertEqual(response.status_code,303)
        self.assertEqual(self.manager.get_prd(self.id),'# 更新后的 PRD')
        backup=next(self.manager.projects_dir.glob('.backup-*'))
        self.assertEqual((backup/'requirement.md').read_text(),'# PRD')
        self.assertEqual(len(self.manager.list_projects()),1)

    def test_interrupted_job_marked_failed(self):
        task=self.generate();job=module.refinement_jobs.read(task)
        job.update(state='running',stage='html');module.refinement_jobs.write(job)
        status=self.client.get(f'/refinement-tasks/{task}/status').json
        self.assertEqual(status['state'],'failed');self.assertIn('重启',status['message'])
