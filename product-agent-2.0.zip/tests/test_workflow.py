import copy
import json
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
from xml.etree import ElementTree as ET
import test_features as fixtures
import test_refinement as helpers
from workflow_fixtures import sample_workflow, generated_workflow
from workflow_document import validate_workflow, write_workflow, validate_bundle, workflow_svg, workflow_drawio, BUNDLE_FILES
from agents.workflow_agent import WorkflowAgent
from agents.requirement_agent import RequirementAgent
from agents.html_agent import HtmlAgent

module=fixtures.module

class DocumentTests(unittest.TestCase):
    def test_editable_shapes_connectors_and_multi_page_exports(self):
        data=sample_workflow();second=copy.deepcopy(data['flows'][0]);second.update(id='second',title='第二条流程');data['flows'].append(second)
        validate_workflow(data,'# PRD','<body>test</body>')
        xml=ET.fromstring(workflow_drawio(data))
        self.assertEqual(len(xml.findall('diagram')),2)
        for page in xml.findall('diagram'):
            cells=page.findall('.//mxCell')
            self.assertEqual(sum(c.get('edge')=='1' for c in cells),2)
            self.assertEqual(sum(c.get('vertex')=='1' and c.get('id').startswith('n-') for c in cells),3)
            self.assertTrue(all(c.get('parent').startswith('lane-') for c in cells if c.get('id').startswith('n-')))
        self.assertEqual(ET.fromstring(workflow_svg(data)).tag,'{http://www.w3.org/2000/svg}svg')

    def test_script_like_labels_are_only_escaped_text(self):
        data=sample_workflow();data['flows'][0]['nodes'][1]['label']='<script>alert(1)</script>&测试'
        svg=workflow_svg(data);self.assertNotIn('<script>',svg)
        self.assertIn('&lt;script&gt;',svg)
        ET.fromstring(workflow_drawio(data))

    def test_duplicate_and_dangling_and_unreachable_nodes_rejected(self):
        for mutate in [lambda f:f['nodes'].append(copy.deepcopy(f['nodes'][0])),lambda f:f['edges'][0].update(target='missing'),lambda f:f['edges'].pop()]:
            data=sample_workflow();mutate(data['flows'][0])
            with self.assertRaises(ValueError):validate_workflow(data,'# PRD','')

    def test_invented_evidence_rejected_but_explicit_pending_allowed(self):
        data=sample_workflow();node=data['flows'][0]['nodes'][1]
        node['evidence'][0]['quote']='不存在的通知服务'
        with self.assertRaises(ValueError):validate_workflow(data,'# PRD','')
        node.update(evidence=[],pending=True)
        self.assertIs(validate_workflow(data,'# PRD',''),data)
        self.assertIn('待确认',workflow_svg(data))

    def test_decisions_need_labeled_branches(self):
        data=sample_workflow();data['flows'][0]['nodes'][1]['type']='decision'
        with self.assertRaises(ValueError):validate_workflow(data,'# PRD','')

    def test_manifest_detects_source_and_export_tampering(self):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp);(d/'requirement.md').write_text('# PRD');(d/'prototype.html').write_text('<body>test</body>')
            write_workflow(sample_workflow(),d);validate_bundle(d)
            (d/'prototype.html').write_text('<body>changed</body>')
            with self.assertRaises(ValueError):validate_bundle(d)
            (d/'prototype.html').write_text('<body>test</body>');(d/'workflow.svg').write_text('bad')
            with self.assertRaises(ValueError):validate_bundle(d)

    def test_agent_uses_both_sources_without_executing_html(self):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp);(d/'requirement.md').write_text('# PRD');(d/'prototype.html').write_text('<body>提交预约<script>secretBusinessCall()</script></body>')
            with patch('agents.workflow_agent.LLM') as llm:
                llm.return_value.chat.return_value='```json\n'+json.dumps(sample_workflow())+'\n```'
                WorkflowAgent().run(output_dir=d)
                prompt=llm.return_value.chat.call_args.args[0]
                self.assertIn('# PRD',prompt);self.assertIn('提交预约',prompt);self.assertNotIn('secretBusinessCall',prompt)
            validate_bundle(d)

class WorkflowIntegrationTests(unittest.TestCase):
    setUp=fixtures.FeatureTests.setUp
    tearDown=fixtures.FeatureTests.tearDown
    start=helpers.RefinementTests.start
    wait=helpers.RefinementTests.wait
    generate=helpers.RefinementTests.generate
    generated_prd=staticmethod(helpers.RefinementTests.generated_prd)
    generated_html=staticmethod(helpers.RefinementTests.generated_html)

    def generate_legacy(self):
        # A pre-existing bundled record fixture, not an exposed generation action.
        import shutil
        with tempfile.TemporaryDirectory() as directory:
            for name in ('requirement.md','prototype.html'):
                shutil.copy2(self.manager.project_path(self.id)/name,Path(directory)/name)
            generated_workflow(output_dir=directory)
            self.manager.attach_workflow(self.id,directory,self.manager.project_fingerprint(self.id))

    def test_independent_entry_and_legacy_attachment_keeps_original_sources(self):
        source=self.manager.project_path(self.id)
        before={n:(source/n).read_bytes() for n in ('requirement.md','prototype.html','raw_requirement.txt')}
        page=self.client.get(f'/projects/{self.id}/workflow').get_data(as_text=True)
        self.assertIn('该历史版本尚未配套 Workflow',page)
        self.assertNotIn('<form',page)
        self.assertIn('Workflow',self.client.get('/').get_data(as_text=True))
        with patch.object(RequirementAgent,'run') as prd,patch.object(HtmlAgent,'run') as html:
            self.generate_legacy();prd.assert_not_called();html.assert_not_called()
        self.assertEqual(before,{n:(source/n).read_bytes() for n in before})
        self.assertEqual(self.manager.get_project(self.id).get('version',1),1)
        self.assertEqual(len(self.manager.list_projects()),1)
        validate_bundle(source)
        self.assertIn('下载可编辑 Workflow',self.client.get(f'/projects/{self.id}/workflow').get_data(as_text=True))

    def test_download_svg_drawio_and_invalid_formats(self):
        self.generate_legacy()
        for extension in ('drawio','svg'):
            with self.client.get(f'/projects/{self.id}/workflow/export?format={extension}') as response:
                self.assertEqual(response.status_code,200);self.assertIn('attachment',response.headers['Content-Disposition']);ET.fromstring(response.data)
        self.assertEqual(self.client.get(f'/projects/{self.id}/workflow/export?format=html').status_code,400)
        self.assertEqual(self.client.get(f'/projects/{self.id}/workflow/image?flow=missing').status_code,404)
        self.assertIn("default-src 'none'",self.client.get(f'/projects/{self.id}/workflow/image').headers['Content-Security-Policy'])

    def test_stale_diagram_cannot_be_downloaded(self):
        self.generate_legacy();(self.manager.project_path(self.id)/'prototype.html').write_text('changed')
        self.assertIn('不一致',self.client.get(f'/projects/{self.id}/workflow').get_data(as_text=True))
        self.assertEqual(self.client.get(f'/projects/{self.id}/workflow/export').status_code,409)

    def test_sync_draft_new_version_and_overwrite_all_three(self):
        task=self.generate();job=module.refinement_jobs.read(task)
        validate_bundle(module.refinement_jobs.path(task))
        page=self.client.get(f'/refinement-tasks/{task}').get_data(as_text=True)
        self.assertIn('生成 Workflow',page);self.assertIn('查看配套 Workflow',page)
        self.assertEqual(self.client.get(f'/refinement-tasks/{task}/workflow').status_code,200)
        self.assertEqual(module.app.test_client().get(f'/refinement-tasks/{task}/workflow-export').status_code,404)
        response=self.client.post(f'/refinement-tasks/{task}/save',data={'csrf_token':self.token,'mode':'replace','confirmed':'yes'})
        self.assertEqual(response.status_code,303)
        source=self.manager.project_path(self.id);validate_bundle(source)
        self.assertTrue(self.manager.get_project(self.id)['has_workflow'])
        for name in BUNDLE_FILES:self.assertEqual((source/name).read_bytes(),(module.refinement_jobs.path(task)/name).read_bytes())
        self.assertIn('# 更新后的 PRD',self.client.get(f'/edit?project_id={self.id}').get_data(as_text=True))

    def test_flow_generation_failure_prevents_any_save_or_overwrite(self):
        before={f.name:f.read_bytes() for f in self.manager.project_path(self.id).iterdir()}
        with patch.object(RequirementAgent,'run',side_effect=self.generated_prd),patch.object(HtmlAgent,'run',side_effect=self.generated_html),patch('refinement_jobs.WorkflowAgent.run',side_effect=ValueError('invalid graph')):
            task=self.start();job=self.wait(task)
        self.assertEqual(job['state'],'failed');self.assertEqual(job['stage'],'workflow')
        self.assertEqual(self.client.post(f'/refinement-tasks/{task}/save',data={'csrf_token':self.token,'mode':'replace','confirmed':'yes'}).status_code,409)
        self.assertEqual(before,{f.name:f.read_bytes() for f in self.manager.project_path(self.id).iterdir()})
        self.assertEqual(len(self.manager.list_projects()),1)

    def test_workflow_stage_is_visible_and_cancellable(self):
        entered=threading.Event();release=threading.Event()
        def flow(**kwargs):entered.set();release.wait(2);return generated_workflow(**kwargs)
        with patch.object(RequirementAgent,'run',side_effect=self.generated_prd),patch.object(HtmlAgent,'run',side_effect=self.generated_html),patch('refinement_jobs.WorkflowAgent.run',side_effect=flow):
            task=self.start();self.assertTrue(entered.wait(1));thread=module.refinement_jobs.active[task]
            try:
                self.assertEqual(self.client.get(f'/refinement-tasks/{task}/status').json['stage'],'workflow')
                self.client.post(f'/refinement-tasks/{task}/cancel',headers={'X-CSRF-Token':self.token})
            finally:release.set();thread.join(2)
        self.assertEqual(module.refinement_jobs.read(task)['state'],'cancelled')
        self.assertEqual(len(self.manager.list_projects()),1)

    def test_legacy_attach_rejects_concurrent_source_change(self):
        import shutil
        with tempfile.TemporaryDirectory() as directory:
            for name in ('requirement.md','prototype.html'):
                shutil.copy2(self.manager.project_path(self.id)/name,Path(directory)/name)
            generated_workflow(output_dir=directory)
            fingerprint=self.manager.project_fingerprint(self.id)
            self.manager.rename_project(self.id,'刚刚修改的项目')
            with self.assertRaises(ValueError):self.manager.attach_workflow(self.id,directory,fingerprint)
        self.assertFalse((self.manager.project_path(self.id)/'workflow.json').exists())

    def test_missing_sources_and_csrf_and_invalid_ids(self):
        self.assertEqual(self.client.post(f'/projects/{self.id}/workflow/generate').status_code,410)
        self.assertEqual(self.client.get('/projects/invalid/workflow').status_code,404)
        (self.manager.project_path(self.id)/'prototype.html').unlink()
        self.assertEqual(self.client.post(f'/projects/{self.id}/workflow/generate',data={'csrf_token':self.token}).status_code,410)

    def test_damaged_bundle_rejected_before_publish(self):
        task=self.generate();directory=module.refinement_jobs.path(task)
        (directory/'workflow.drawio').write_text('invalid')
        with self.assertRaises(ValueError):self.manager.create_project('不应保存',output_dir=directory,require_bundle=True)
        self.assertEqual(len(self.manager.list_projects()),1)

    def test_failed_apply_restores_original_bundle_completely(self):
        task=self.generate();directory=module.refinement_jobs.path(task)
        revision=self.manager.create_project('测试',output_dir=directory,source_project=self.info,source_fingerprint=self.manager.project_fingerprint(self.id),require_bundle=True)
        source=self.manager.project_path(self.id);before={f.name:f.read_bytes() for f in source.iterdir()}
        import os
        real=os.replace;count=0
        def failure(a,b):
            nonlocal count
            count+=1
            if count==7:raise OSError('simulated error after workflow copy')
            return real(a,b)
        with patch('os.replace',side_effect=failure):
            with self.assertRaises(OSError):self.manager.apply_refinement(revision['id'])
        self.assertEqual(before,{f.name:f.read_bytes() for f in source.iterdir()})

    def test_first_generation_saves_complete_bundle(self):
        with patch.object(RequirementAgent,'run',side_effect=self.generated_prd),patch.object(HtmlAgent,'run',side_effect=self.generated_html):
            response=self.client.post('/create',data={'csrf_token':self.token,'requirement':'创建新产品'},headers={'Accept':'application/json'})
            task=response.json['task_url'].rsplit('/',1)[1];job=self.wait(task)
        self.assertEqual(job['state'],'saved');validate_bundle(self.manager.project_path(job['saved_id']))
        self.assertIn('查看 Workflow',self.client.get(f'/projects/{job["saved_id"]}/result').get_data(as_text=True))

    def test_workflow_view_is_read_only_and_opens_existing_content(self):
        self.generate_legacy()
        before={f.name:f.read_bytes() for f in self.manager.project_path(self.id).iterdir()}
        with patch('refinement_jobs.WorkflowAgent.run') as agent:
            response=self.client.get(f'/projects/{self.id}/workflow')
            agent.assert_not_called()
        html=response.get_data(as_text=True)
        self.assertEqual(response.status_code,200)
        self.assertIn('id="workflow-image"',html)
        self.assertIn('<h1>Workflow</h1>',html)
        self.assertNotIn('<form',html);self.assertNotIn('<textarea',html)
        self.assertNotIn('workflow/generate',html)
        self.assertEqual(before,{f.name:f.read_bytes() for f in self.manager.project_path(self.id).iterdir()})

    def test_home_workflow_precedes_optimize_and_old_records_are_disabled(self):
        html=self.client.get('/').get_data(as_text=True)
        self.assertIn('disabled title="该旧版本',html)
        self.generate_legacy()
        html=self.client.get('/').get_data(as_text=True)
        row=html.split('id="project-'+self.id+'"',1)[1].split('</article>',1)[0]
        self.assertLess(row.index('>Workflow</a>'),row.index('>继续优化</a>'))
        self.assertIn(f'/edit?project_id={self.id}',row)
