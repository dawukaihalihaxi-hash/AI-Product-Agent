import unittest
import test_features
from prototype_modules import normalize_actions,validate_fragment,PrototypeError

class ActionLabelTests(unittest.TestCase):
    def setUp(self):
        self.page={'id':'p1','name':'创建展品','actions':[{'label':'保存'}]}
        self.scope={'pages':[self.page]}
    def validate(self,button,js='void 0;'):
        return validate_fragment('<section id="p1" data-pa-page data-pa-name="创建展品">'+button+'</section><script>'+js+'</script>',self.page,self.scope)
    def test_alias_is_canonical_and_keeps_id_and_disabled(self):
        r=self.validate('<button id="p1-save" disabled>保存展品</button>')
        self.assertIn('>保存</button>',r['html']);self.assertIn('id="p1-save"',r['html']);self.assertIn('disabled',r['html']);self.assertIn('data-pa-action="a1"',r['html'])
    def test_spans_and_literal_event_checks_remain_consistent(self):
        r=self.validate('<button><span>保存展品</span></button>',"if (button.textContent === '保存展品') save();")
        self.assertIn('<span>保存</span>',r['html']);self.assertIn("=== '保存'",r['js'])
    def test_states_are_disabled_not_new_actions(self):
        for label in ('已截止','已报名','已保存','提交中'):
            r=self.validate('<button>'+label+'</button>');self.assertIn('disabled',r['html']);self.assertIn(label,r['html'])
    def test_unknown_and_compound_operations_still_rejected(self):
        for label in ('发布','保存并发布','保存并删除','导出全部'):
            with self.assertRaises(PrototypeError):self.validate('<button>'+label+'</button>')
    def test_normalization_idempotent(self):
        text='<button id="save">保存展品</button>'
        first=normalize_actions(text,self.page);self.assertEqual(first,normalize_actions(first,self.page))
    def test_explicit_status_filter_remains_actionable(self):
        self.page['actions']=[{'label':'已发布'}]
        r=self.validate('<button>已发布</button>');self.assertNotIn('disabled',r['html'])
    def test_whitespace_is_presentation(self):
        r=self.validate('<button> 保 存 </button>');self.assertIn('data-pa-action="a1"',r['html'])
    def test_navigation_does_not_get_renamed(self):
        r=self.validate('<button data-pa-navigate="p1">保存展品</button>');self.assertIn('保存展品',r['html'])
