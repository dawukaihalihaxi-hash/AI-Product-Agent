import copy,json,tempfile,unittest,os
from pathlib import Path
from unittest.mock import patch
import test_features
from test_model_fallback import BACKUP,response
from workflow_fixtures import sample_workflow
from agents.workflow_agent import WorkflowAgent,resolve_evidence,evidence_catalog,WorkflowGenerationError
from workflow_document import validate_workflow,validate_bundle
from llm import LLM,ModelOutputError
from model_routing import model_call_context

class SystemReliabilityTests(unittest.TestCase):
    def test_single_object_and_multiple_valid_references(self):
        catalog=evidence_catalog('# PRD','')
        for evidence in [{'ref':'P001'},'P001',[{'ref':'P001'}]*5]:
            data=sample_workflow();data['flows'][0]['nodes'][1]['evidence']=evidence
            validate_workflow(resolve_evidence(data,catalog),'# PRD','')

    def test_workflow_falls_back_after_truncated_primary(self):
        events=[]
        with patch.dict(os.environ,BACKUP),patch('llm.requests.post',side_effect=[response(content='cut',finish='length'),response(content='complete')]) as post,model_call_context(events.append):
            self.assertEqual(LLM().chat('workflow',retry_invalid_output=True),'complete')
        self.assertEqual(post.call_count,2);self.assertIn('switching',[e['state'] for e in events])
        self.assertEqual(next(e['output_code'] for e in events if e['state']=='failed'),'output_truncated')

    def test_failed_output_keeps_precise_reason_and_diagnostics(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp);(folder/'requirement.md').write_text('# PRD');(folder/'prototype.html').write_text('<body>原型</body>')
            with patch('agents.workflow_agent.LLM.chat',side_effect=ModelOutputError('output_truncated','模型输出达到长度上限')):
                with self.assertRaisesRegex(WorkflowGenerationError,'长度上限'):WorkflowAgent().run(output_dir=folder)
            report=json.loads(next((folder/'.workflow-diagnostics').glob('*.report.json')).read_text())
            self.assertEqual(report['code'],'output_truncated');self.assertFalse((folder/'bundle_manifest.json').exists())

    def test_single_object_output_reaches_all_artifacts(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp);(folder/'requirement.md').write_text('# PRD');(folder/'prototype.html').write_text('<body>原型</body>')
            data=sample_workflow();data['flows'][0]['nodes'][1]['evidence']={'ref':'P001'}
            with patch('agents.workflow_agent.LLM.chat',return_value=json.dumps(data)):WorkflowAgent().run(output_dir=folder)
            validate_bundle(folder)
            self.assertTrue((folder/'workflow.drawio').exists());self.assertTrue((folder/'workflow.svg').exists())

    def test_session_survives_browser_restart_but_remains_private(self):
        app=test_features.module.app;client=app.test_client();r=client.get('/')
        self.assertIn('Expires=',r.headers.get('Set-Cookie',''))
        with client.session_transaction() as session:self.assertTrue(session.permanent)
        # A fresh browser receives a separate session, never a shared demo owner.
        other=app.test_client();other.get('/')
        with other.session_transaction() as session:self.assertNotIn('refinement_owner',session)
