from scope_document import write_scope,source_sections

def generated_scope(raw,*,output_dir,changes='',previous_scope=None,base_prd=None):
    source=source_sections(raw)['source']+ ('\n本次明确修改：\n'+changes if changes else '')
    quote=next((x for x in source.splitlines() if x.strip()),'测试')
    data={'schema':'product-agent/scope','version':1,'title':'测试产品','actors':['用户'],'pages':[{'id':'p1','name':'测试页面','actor':'用户','purpose':'测试核心流程','evidence':[quote],'fields':[],'actions':[{'label':'提交','result':'完成','target':''}],'states':['已完成']}],'flow':[{'page':'p1','label':'提交','rule':'','evidence':[quote]}],'acceptance':['可完成提交'],'exclusions':[],'notes':[],'shared_state':{'submitted':False}}
    return write_scope(data,output_dir,source)

def fragment(page='p1',text='测试'):
    return f'<style data-pa-module-style>#{page}{{padding:16px}}</style><section id="{page}" data-pa-page data-pa-name="测试"><h2>{text}</h2><button type="button" data-pa-action="a1">提交</button></section><script data-pa-module-script>PA.register("{page}",function(root){{root.onclick=function(){{PA.update({{submitted:true}});}};}});</script>'
