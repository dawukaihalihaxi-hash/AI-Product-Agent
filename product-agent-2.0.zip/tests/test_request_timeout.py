import unittest
from unittest.mock import patch,Mock
from time import time
import test_features as fixtures
import test_refinement as helpers
from refinement_jobs import JobCancelled
from llm import LLM
module=fixtures.module

class TimeoutTests(unittest.TestCase):
    setUp=fixtures.FeatureTests.setUp
    tearDown=fixtures.FeatureTests.tearDown
    start=helpers.RefinementTests.start
    wait=helpers.RefinementTests.wait
    generate=helpers.RefinementTests.generate
    generated_prd=staticmethod(helpers.RefinementTests.generated_prd)
    generated_html=staticmethod(helpers.RefinementTests.generated_html)

    def test_network_wait_is_bounded(self):
        response=Mock();response.json.return_value={'choices':[{'message':{'content':'ok'}}]}
        with patch('llm.requests.post',return_value=response) as post:
            self.assertEqual(LLM().chat('test'),'ok')
        self.assertEqual(post.call_args.kwargs['timeout'],(10,180))

    def test_overdue_request_fails_and_late_worker_cannot_save(self):
        task=self.generate();service=module.refinement_jobs
        job=service.read(task);job.update(state='running',stage='html',request_started_at=time()-241)
        service.write(job);service.active[task]=object()
        try:
            state=service.status(task)
            self.assertEqual(state['state'],'failed');self.assertIn('超过 4 分钟',state['message'])
            with self.assertRaises(JobCancelled):service.check_cancelled(job)
            with self.assertRaises(JobCancelled):service.update(job,state='ready')
            self.assertEqual(service.read(task)['state'],'failed')
            self.assertEqual(len(self.manager.list_projects()),1)
        finally:service.active.pop(task,None)
