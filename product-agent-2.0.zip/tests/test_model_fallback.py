import json
import os
import threading
import tempfile
import local_model_settings
import unittest
from unittest.mock import patch
import requests
import test_features as fixtures
import test_refinement as helpers
from llm import LLM
from model_routing import fallback_profile, model_call_context
from agents.html_agent import HtmlAgent
from pathlib import Path


def response(status=200, content='ok', code=None, finish='stop'):
    r=requests.Response();r.status_code=status
    r._content=json.dumps({'error':{'code':code}} if status>=400 else {'choices':[{'message':{'content':content},'finish_reason':finish}]}).encode()
    return r

BACKUP={'MODEL_FALLBACK_ENABLED':'1','MODEL_FALLBACK_API_KEY':'backup-secret'}

class FallbackTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.settings_path=patch.object(local_model_settings,'SETTINGS_FILE',Path(self.tmp.name)/'settings.json')
        self.settings_path.start()
        self.env=patch.dict(os.environ,{},clear=True);self.env.start()
    def tearDown(self):
        self.env.stop();self.settings_path.stop();self.tmp.cleanup()

    def test_disabled_keeps_original_request_and_error(self):
        with patch('llm.requests.post',return_value=response(429,code='1305')) as post:
            with self.assertRaises(requests.HTTPError):LLM().chat('requirement')
        post.assert_called_once();self.assertEqual(post.call_args.kwargs['timeout'],(10,180))

    def test_primary_success_never_calls_backup(self):
        with patch.dict(os.environ,BACKUP),patch('llm.requests.post',return_value=response()) as post:
            self.assertEqual(LLM().chat('requirement'),'ok')
        post.assert_called_once()

    def test_busy_uses_separate_key_same_prompt_and_records_event(self):
        events=[]
        with patch.dict(os.environ,BACKUP),patch('llm.requests.post',side_effect=[response(429,code='1305'),response(content='backup html')]) as post,model_call_context(events.append):
            self.assertEqual(LLM().chat('private requirement'),'backup html')
        self.assertEqual(post.call_count,2)
        first,second=post.call_args_list
        self.assertEqual(second.args[0],'https://openrouter.ai/api/v1/chat/completions')
        self.assertEqual(second.kwargs['headers']['Authorization'],'Bearer backup-secret')
        self.assertEqual(second.kwargs['json']['model'],'openrouter/free')
        self.assertEqual(first.kwargs['json']['messages'],second.kwargs['json']['messages'])
        self.assertIn('switching',[e['state'] for e in events])
        serialized=json.dumps(events);self.assertNotIn('secret',serialized);self.assertNotIn('private requirement',serialized)

    def test_timeout_connection_and_server_failure_switch(self):
        for failure in [requests.ReadTimeout(),requests.ConnectionError(),response(503)]:
            with self.subTest(failure=type(failure).__name__),patch.dict(os.environ,BACKUP),patch('llm.requests.post',side_effect=[failure,response()]) as post:
                self.assertEqual(LLM().chat('hello'),'ok');self.assertEqual(post.call_count,2)

    def test_auth_parameter_and_missing_model_errors_do_not_switch(self):
        for status in [400,401,403,404]:
            with self.subTest(status=status),patch.dict(os.environ,BACKUP),patch('llm.requests.post',return_value=response(status)) as post:
                with self.assertRaises(requests.HTTPError):LLM().chat('hello')
                post.assert_called_once()

    def test_failed_backup_never_reports_success(self):
        events=[]
        with patch.dict(os.environ,BACKUP),patch('llm.requests.post',side_effect=[response(429,code='1305'),response(429,code='429')]),model_call_context(events.append):
            with self.assertRaises(requests.HTTPError):LLM().chat('hello')
        self.assertNotIn('succeeded',[e['state'] for e in events])

    def test_missing_key_invalid_url_and_paid_openrouter_rejected_before_transmission(self):
        options=[{'MODEL_FALLBACK_ENABLED':'1'},dict(BACKUP,MODEL_FALLBACK_BASE_URL='http://example.com/v1/chat/completions'),dict(BACKUP,MODEL_FALLBACK_NAME='paid/model'),dict(BACKUP,MODEL_FALLBACK_MAX_TOKENS='bad')]
        for env in options:
            with self.subTest(env=list(env)),patch.dict(os.environ,env),patch('llm.requests.post') as post:
                with self.assertRaises(ValueError):LLM().chat('hello')
                post.assert_not_called()

    def test_custom_compatible_endpoint_and_output_limit(self):
        env=dict(BACKUP,MODEL_FALLBACK_BASE_URL='https://api.siliconflow.cn/v1/chat/completions',MODEL_FALLBACK_NAME='chosen-model',MODEL_FALLBACK_MAX_TOKENS='8192')
        with patch.dict(os.environ,env),patch('llm.requests.post',side_effect=[response(503),response()]) as post:
            LLM().chat('hello')
        self.assertEqual(post.call_args.kwargs['json']['max_tokens'],8192)
        self.assertEqual(post.call_args.args[0],env['MODEL_FALLBACK_BASE_URL'])

    def test_empty_and_truncated_outputs_not_returned_as_success(self):
        for r in [response(content=''),response(content='partial html',finish='length')]:
            with patch.dict(os.environ,BACKUP),patch('llm.requests.post',return_value=r) as post:
                with self.assertRaises(ValueError):LLM().chat('hello')
                post.assert_called_once()

    def test_cancel_between_calls_prevents_fallback(self):
        cancelled=False
        def event(e):
            nonlocal cancelled
            if e['state']=='failed':cancelled=True
        def guard():
            if cancelled:raise RuntimeError('cancelled')
        with patch.dict(os.environ,BACKUP),patch('llm.requests.post',return_value=response(429,code='1305')) as post,model_call_context(event,guard):
            with self.assertRaisesRegex(RuntimeError,'cancelled'):LLM().chat('hello')
        post.assert_called_once()

    def test_hooks_do_not_leak_across_threads_or_contexts(self):
        received=[]
        with patch('llm.requests.post',return_value=response()),model_call_context(received.append):
            t=threading.Thread(target=lambda:LLM().chat('other task'));t.start();t.join()
            self.assertEqual(received,[])
            LLM().chat('this task')
        self.assertEqual([e['state'] for e in received],['requesting','succeeded'])


class TaskFallbackTests(unittest.TestCase):
    setUp=fixtures.FeatureTests.setUp
    tearDown=fixtures.FeatureTests.tearDown
    start=helpers.RefinementTests.start
    wait=helpers.RefinementTests.wait

    def test_html_fallback_preserves_prd_and_task_history(self):
        from scope_fixtures import fragment
        html=fragment(text='预约')
        with patch.dict(os.environ,BACKUP),patch('agents.requirement_agent.RequirementAgent.run',side_effect=helpers.RefinementTests.generated_prd) as prd,patch('llm.requests.post',side_effect=[response(429,code='1305'),response(content=html)]):
            task=self.start();job=self.wait(task)
        self.assertEqual(job['state'],'ready');prd.assert_called_once()
        self.assertEqual(job['models_used']['html'],{'role':'备用模型','model':'openrouter/free'})
        status=self.client.get(f'/refinement-tasks/{task}/status').json
        self.assertEqual(status['model_attempts'],job['model_attempts'])
        self.assertEqual(status['models_used'],job['models_used'])
        self.assertIn('switching',[event['state'] for event in status['model_attempts']])
        self.assertNotIn('backup-secret',json.dumps(status))
        self.assertEqual(len(self.manager.list_projects()),1)
        page=self.client.get(f'/refinement-tasks/{task}').get_data(as_text=True)
        self.assertIn('模型调用与自动切换记录',page);self.assertIn('openrouter/free',page)
        stored=(fixtures.module.refinement_jobs.path(task)/'task.json').read_text()
        self.assertNotIn('backup-secret',stored)
        self.assertIn('预约',(fixtures.module.refinement_jobs.path(task)/'prototype.html').read_text())
        self.assertIn('PA.navigate',(fixtures.module.refinement_jobs.path(task)/'prototype.html').read_text())
