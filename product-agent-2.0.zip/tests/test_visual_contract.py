import copy,unittest
from prototype_modules import design_contract,assemble
from scope_fixtures import generated_scope,fragment

class VisualContractTests(unittest.TestCase):
    def setUp(self):
        import tempfile
        from pathlib import Path
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.scope=generated_scope('创建展品并查看展品详情',output_dir=Path(self.tmp.name))
        self.scope['title']='人生博物馆'
        detail=copy.deepcopy(self.scope['pages'][0]);detail.update(id='p2',name='展品详情')
        self.scope['pages'].append(detail)
    def test_business_navigation_omits_detail_without_removing_page(self):
        html=assemble(self.scope,{'p1':fragment('p1'),'p2':fragment('p2')})
        nav=html.split('<nav')[1].split('</nav>')[0]
        self.assertNotIn('p2',nav);self.assertIn('id="p2"',html)
        self.assertNotIn('角色入口仅用于体验',html)
        self.assertIn('pa-layout-editorial',html)
    def test_explicit_design_uses_existing_pages_and_safe_palette(self):
        self.scope['visual_design']={'layout':'top','navigation_pages':['p1','fake','p1'],'palette':{'accent':'#123abc','ink':'bad;display:none'},'direction':'用户指定设计'}
        design=design_contract(self.scope)
        self.assertEqual(design['navigation_pages'],['p1'])
        self.assertEqual(design['palette'],{'accent':'#123abc'})
        self.assertEqual(design['layout'],'top')
    def test_terminal_fallback_matches_product(self):
        self.scope['title']='订单管理系统'
        self.assertEqual(design_contract(self.scope)['layout'],'sidebar')
        self.scope['title']='家庭点菜';self.scope['confirmed_source']='微信小程序'
        self.assertEqual(design_contract(self.scope)['layout'],'mobile')

    def test_local_styles_cannot_change_other_pages(self):
        from prototype_modules import scope_page_css
        css=scope_page_css('.card, input{color:red}@media(max-width:760px){.row{display:block}}#p1{padding:8px}.label:after{content:"}"}', 'p1')
        self.assertIn('#p1 :is(.card, input)',css)
        self.assertIn('@media(max-width:760px){:is(#p1',css)
        self.assertIn('content:"}"',css)

    def test_model_commentary_is_not_rendered_as_product_ui(self):
        from prototype_modules import clean_fragment
        original=fragment('p1')
        self.assertEqual(clean_fragment('```html\n'+original+'\n```\n说明：脚本实现'),original)
        self.assertEqual(clean_fragment(original+'\n说明：脚本实现'),original)
