import threading
from unittest.mock import patch
from test_resume import ResumeTests as Base
from test_refinement import module, RequirementAgent, HtmlAgent

class TaskDeleteTests(Base):
    def delete(self, task, confirmed=True, token=True, client=None):
        return (client or self.client).post(f'/refinement-tasks/{task}/delete',json={'confirmed':confirmed},headers={'X-CSRF-Token':self.token} if token else {})

    def test_delete_failed_task_removes_artifacts_and_record_only(self):
        task=self.fail_html();folder=module.refinement_jobs.path(task)
        source={p.name:p.read_bytes() for p in self.manager.project_path(self.id).iterdir()}
        self.assertEqual(self.delete(task,token=False).status_code,403)
        self.assertEqual(self.delete(task,confirmed=False).status_code,400)
        stranger=module.app.test_client();self.assertEqual(self.delete(task,client=stranger).status_code,404)
        self.assertTrue(folder.exists())
        self.assertTrue(self.delete(task).json['deleted']);self.assertFalse(folder.exists())
        for route in ('','/status','/prd'):
            self.assertEqual(self.client.get(f'/refinement-tasks/{task}'+route).status_code,404)
        self.assertEqual(self.resume_post(task).status_code,404)
        self.assertNotIn(task,self.client.get('/unfinished-tasks').get_data(as_text=True))
        self.assertNotIn(task,self.client.get('/generation-history').get_data(as_text=True))
        self.assertEqual(source,{p.name:p.read_bytes() for p in self.manager.project_path(self.id).iterdir()})

    def test_delete_ready_and_cancelled_tasks_but_not_saved(self):
        task=self.generate();self.assertEqual(self.delete(task).status_code,200)
        task=self.fail_html();service=module.refinement_jobs;job=service.read(task);job['state']='cancelled';service.write(job)
        self.assertEqual(self.delete(task).status_code,200)
        task=self.generate();service.save(task,'new')
        self.assertEqual(self.delete(task).status_code,409)
        self.assertEqual(len(self.manager.list_projects()),2)

    def test_delete_active_task_hides_then_cleans_without_saving(self):
        entered=threading.Event();release=threading.Event()
        def prd(*args,**kwargs):entered.set();release.wait(2);return self.generated_prd(*args,**kwargs)
        with patch.object(RequirementAgent,'run',side_effect=prd),patch.object(HtmlAgent,'run') as html:
            task=self.start();self.assertTrue(entered.wait(1));service=module.refinement_jobs;thread=service.active[task];folder=service.path(task)
            try:
                self.assertEqual(self.delete(task).status_code,200)
                self.assertEqual(self.client.get(f'/refinement-tasks/{task}').status_code,404)
                self.assertNotIn(task,self.client.get('/unfinished-tasks').get_data(as_text=True))
            finally:release.set();thread.join(2)
            html.assert_not_called()
        self.assertFalse(folder.exists());self.assertEqual(len(self.manager.list_projects()),1)

    def test_separate_duration_completion_and_error_fields(self):
        import requests
        response=requests.Response();response.status_code=429;response._content=b'{"error":{"code":"1305"}}'
        with patch.object(RequirementAgent,'run',side_effect=requests.HTTPError(response=response)),patch('refinement_jobs.sleep'):
            task=self.start();job=self.wait(task)
        self.assertEqual(job['error_provider'],'1305')
        html=self.client.get('/unfinished-tasks').get_data(as_text=True)
        for label in ['累计用时','完成情况','未完成原因','HTTP 状态码：429','模型错误代码：1305','访问量过大','class="delete-task"']:
            self.assertIn(label,html)
        self.assertLess(html.index('aria-label="累计用时"'),html.index('aria-label="完成情况"'))
        self.assertLess(html.index('aria-label="完成情况"'),html.index('aria-label="任务说明"'))

for name in dir(Base):
    if name.startswith('test_') and name not in TaskDeleteTests.__dict__:setattr(TaskDeleteTests,name,None)
del Base
