import io
import json
import unittest
from unittest.mock import patch
from test_refinement import RefinementTests, module, RequirementAgent, HtmlAgent
from agents.workflow_agent import WorkflowAgent
from workflow_fixtures import generated_workflow

class StageImportTests(unittest.TestCase):
    setUp=RefinementTests.setUp
    tearDown=RefinementTests.tearDown
    wait=RefinementTests.wait

    def payload(self):
        return dict(schema='product-agent/stage-backup',version=1,kind='create',name='恢复测试',raw='预约产品',prd='# PRD\n预约产品',html='<!DOCTYPE html><html><body>预约</body></html>',elapsed_seconds=869.5)

    def test_import_and_resume_preserves_artifacts(self):
        data=self.payload()
        with patch.object(RequirementAgent,'run') as prd,patch.object(HtmlAgent,'run') as html,patch.object(WorkflowAgent,'run',side_effect=generated_workflow):
            job=module.refinement_jobs.import_creation_results(data,'owner-test')
            self.assertEqual(job['completed'],dict(prd=True,html=True,workflow=False))
            folder=module.refinement_jobs.path(job['id'])
            self.assertEqual((folder/'prototype.html').read_bytes(),data['html'].encode())
            module.refinement_jobs.resume(job['id']);result=self.wait(job['id'])
            self.assertEqual(result['state'],'saved')
            prd.assert_not_called();html.assert_not_called()
            self.assertEqual((folder/'requirement.md').read_bytes(),data['prd'].encode())

    def test_invalid_artifacts_rejected(self):
        for changes in [dict(html='<html>partial'),dict(elapsed_seconds=float('nan')),dict(raw=''),dict(kind='refine')]:
            with self.subTest(changes=changes),self.assertRaises(ValueError):
                module.refinement_jobs.import_creation_results(dict(self.payload(),**changes),'owner')

    def test_upload_requires_csrf_and_assigns_current_owner(self):
        def form():return dict(backup=(io.BytesIO(json.dumps(self.payload()).encode()),'backup.json'))
        self.assertEqual(self.client.post('/generation-backups/import',data=form()).status_code,403)
        data=form();data['csrf_token']=self.token
        response=self.client.post('/generation-backups/import',data=data)
        self.assertEqual(response.status_code,303)
        self.assertEqual(self.client.get(response.location).status_code,200)
        self.assertEqual(module.app.test_client().get(response.location).status_code,404)
