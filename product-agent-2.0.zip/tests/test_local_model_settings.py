import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import requests
import test_features as fixtures
import local_model_settings as settings
from model_routing import fallback_profile

class LocalSettingsTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.file=Path(self.tmp.name)/'settings.json'
        self.path_patch=patch.object(settings,'SETTINGS_FILE',self.file);self.path_patch.start()
        self.env_patch=patch.dict(os.environ,{},clear=True);self.env_patch.start()
        self.client=fixtures.module.app.test_client();self.client.get('/')
        with self.client.session_transaction() as session:self.csrf=session['csrf_token']
    def tearDown(self):
        self.env_patch.stop();self.path_patch.stop();self.tmp.cleanup()
    def submit(self,key='private-test-key',**options):
        return self.client.post('/settings/backup-model',data={'csrf_token':self.csrf,'api_key':key,'action':'enable'},**options)
    @staticmethod
    def response(status=200):
        r=requests.Response();r.status_code=status;r._content=json.dumps({'choices':[{'message':{'content':'OK'},'finish_reason':'stop'}]} if status==200 else {'error':{'code':1305,'message':'private-test-key'}}).encode();return r
    def test_validate_before_enable_and_no_key_echo(self):
        page=self.client.get('/settings/backup-model');self.assertEqual(page.status_code,200)
        with patch.object(settings.requests,'post',return_value=self.response()) as post:
            result=self.submit();self.assertEqual(result.status_code,303)
        self.assertEqual(post.call_args.args[0],settings.URL)
        self.assertEqual(post.call_args.kwargs['json']['model'],settings.MODEL)
        profile=fallback_profile();self.assertEqual(profile['api_key'],'private-test-key')
        self.assertEqual(profile['model'],settings.MODEL)
        self.assertEqual(self.file.stat().st_mode & 0o777,0o600)
        self.assertNotIn('private-test-key',self.client.get(result.location).get_data(as_text=True))
    def test_failed_test_does_not_save_or_replace_previous(self):
        settings.save_settings({'MODEL_FALLBACK_ENABLED':'0','MODEL_FALLBACK_API_KEY':'previous-key'})
        before=self.file.read_bytes()
        with patch.object(settings.requests,'post',return_value=self.response(429)):
            result=self.submit()
        self.assertEqual(result.status_code,400);self.assertEqual(self.file.read_bytes(),before)
        self.assertIn('HTTP 429',result.get_data(as_text=True));self.assertNotIn('private-test-key',result.get_data(as_text=True))
        self.assertIsNone(fallback_profile())
    def test_csrf_and_cloud_remote_host_rejected(self):
        with patch.object(settings.requests,'post') as post:
            self.assertEqual(self.client.post('/settings/backup-model',data={'api_key':'private-test-key'}).status_code,403)
            self.assertEqual(self.submit(environ_overrides={'REMOTE_ADDR':'10.0.0.1'}).status_code,404)
            self.assertEqual(self.submit(base_url='http://attacker.invalid').status_code,404)
            with patch.dict(os.environ,{'RENDER':'true'}):self.assertEqual(self.client.get('/settings/backup-model').status_code,404)
        post.assert_not_called();self.assertFalse(self.file.exists())
    def test_disable_and_environment_precedence(self):
        with patch.object(settings.requests,'post',return_value=self.response()):self.submit()
        with patch.dict(os.environ,{'MODEL_FALLBACK_ENABLED':'0'}):
            self.assertIsNone(fallback_profile());self.assertEqual(self.submit().status_code,400)
        result=self.client.post('/settings/backup-model',data={'csrf_token':self.csrf,'action':'disable'})
        self.assertEqual(result.status_code,303);self.assertIsNone(fallback_profile())
    def test_invalid_key_and_connection_failure_safe(self):
        with patch.object(settings.requests,'post') as post:
            self.assertEqual(self.submit(' ').status_code,400);post.assert_not_called()
        with patch.object(settings.requests,'post',side_effect=requests.ConnectionError('private-test-key')):
            result=self.submit()
        self.assertEqual(result.status_code,400);self.assertNotIn('private-test-key',result.get_data(as_text=True))
        self.assertFalse(self.file.exists())
