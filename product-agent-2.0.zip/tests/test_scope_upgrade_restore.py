import json,unittest,requests
from unittest.mock import patch
from test_refinement import RefinementTests,module,RequirementAgent,HtmlAgent

class ScopeUpgradeTests(unittest.TestCase):
    setUp=RefinementTests.setUp
    tearDown=RefinementTests.tearDown
    start=RefinementTests.start
    wait=RefinementTests.wait

    def test_old_partial_scope_is_archived_and_latest_modification_replanned(self):
        with patch.object(RequirementAgent,'run',side_effect=RefinementTests.generated_prd),patch.object(HtmlAgent,'run',side_effect=requests.ConnectionError()):
            rid=self.start('考试时间改为90分钟');self.assertEqual(self.wait(rid)['state'],'failed')
        folder=module.refinement_jobs.path(rid);scope=json.loads((folder/'scope.json').read_text());scope['scope_policy']=2;(folder/'scope.json').write_text(json.dumps(scope))
        old=(folder/'requirement.md').read_bytes();source_before=self.manager.get_prd(self.id)
        with patch.object(RequirementAgent,'run',side_effect=RefinementTests.generated_prd) as prd,patch.object(HtmlAgent,'run',side_effect=RefinementTests.generated_html):
            module.refinement_jobs.resume(rid);self.assertEqual(self.wait(rid)['state'],'ready')
        prd.assert_called_once();self.assertIn('90分钟',prd.call_args.args[0])
        self.assertEqual(next(folder.glob('.stage-history/*/requirement.md')).read_bytes(),old)
        self.assertEqual(self.manager.get_prd(self.id),source_before)
