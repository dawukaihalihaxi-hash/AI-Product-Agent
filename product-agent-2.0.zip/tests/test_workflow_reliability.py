import copy
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import test_features as fixtures
from workflow_fixtures import sample_workflow
from agents.workflow_agent import WorkflowAgent, WorkflowGenerationError, evidence_catalog, resolve_evidence
from workflow_document import validate_workflow, validate_bundle
from llm import LLM
from test_model_fallback import BACKUP,response
import os

class ReliabilityTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.folder=Path(self.tmp.name)
        (self.folder/'requirement.md').write_text('# PRD\n用户填写活动目标并提交。')
        (self.folder/'prototype.html').write_text('<body>活动目标<script>privateCall()</script></body>')
    def tearDown(self):self.tmp.cleanup()
    def test_source_references_restore_exact_quotes(self):
        catalog=evidence_catalog('# PRD\n**提交**活动目标。','<body>提交<script>not-visible</script></body>')
        self.assertNotIn('not-visible',json.dumps(catalog))
        data=sample_workflow();data['flows'][0]['nodes'][1]['evidence']=[{'ref':'P002'}]
        data=resolve_evidence(data,catalog)
        self.assertEqual(data['flows'][0]['nodes'][1]['evidence'],[{'source':'prd','quote':'**提交**活动目标。'}])
        validate_workflow(data,'# PRD\n**提交**活动目标。','<body>提交</body>')
    def test_repair_once_and_keep_all_source_bytes(self):
        before={f.name:f.read_bytes() for f in self.folder.iterdir()}
        good=sample_workflow();good['flows'][0]['nodes'][1]['evidence']=[{'ref':'P001'}]
        bad=copy.deepcopy(good);bad['flows'][0]['edges'][0]['target']='missing'
        with patch('agents.workflow_agent.LLM') as llm:
            llm.return_value.chat.side_effect=[json.dumps(bad),json.dumps(good)]
            WorkflowAgent().run(output_dir=self.folder)
            self.assertEqual(llm.return_value.chat.call_count,2)
            self.assertIn('连线引用了不存在的节点',llm.return_value.chat.call_args.args[0])
            self.assertEqual(llm.return_value.chat.call_args.kwargs['max_tokens'],8000)
        validate_bundle(self.folder)
        for name,data in before.items():self.assertEqual((self.folder/name).read_bytes(),data)
        records=list((self.folder/'.workflow-diagnostics').glob('*.report.json'))
        self.assertEqual(len(records),2)
        self.assertEqual({json.loads(f.read_text())['state'] for f in records},{'invalid','validated'})
        self.assertTrue(all(f.stat().st_mode & 0o777 == 0o600 for f in records))
    def test_exact_failure_after_bounded_repair_without_fake_success(self):
        invalid=sample_workflow();invalid['flows'][0]['nodes'][1]['evidence']=[{'source':'prd','quote':'这是原文没有的功能'}]
        with patch('agents.workflow_agent.LLM') as llm:
            llm.return_value.chat.return_value=json.dumps(invalid)
            with self.assertRaisesRegex(WorkflowGenerationError,'节点引用在当前 PRD 或原型中不存在'):
                WorkflowAgent().run(output_dir=self.folder)
            self.assertEqual(llm.return_value.chat.call_count,2)
        self.assertFalse((self.folder/'bundle_manifest.json').exists())
        self.assertFalse((self.folder/'workflow.svg').exists())
        self.assertEqual(len(list((self.folder/'.workflow-diagnostics').glob('*.response.txt'))),2)
    def test_unknown_source_id_and_malformed_edges_rejected(self):
        data=sample_workflow();data['flows'][0]['nodes'][1]['evidence']=[{'ref':'P999'}]
        with self.assertRaisesRegex(WorkflowGenerationError,'不存在的资料编号'):resolve_evidence(data,evidence_catalog('# PRD',''))
        data=sample_workflow();data['flows'][0]['edges'][0]['source']={'id':'start'}
        with self.assertRaises(ValueError):validate_workflow(data,'# PRD','')
    def test_json_error_is_specific_and_recorded(self):
        with patch('agents.workflow_agent.LLM') as llm:
            llm.return_value.chat.return_value='{ invalid json'
            with self.assertRaisesRegex(WorkflowGenerationError,'第 1 行'):WorkflowAgent().run(output_dir=self.folder)
        self.assertEqual(len(list((self.folder/'.workflow-diagnostics').glob('*.report.json'))),2)
    def test_stage_budget_applies_to_both_models(self):
        with patch.dict(os.environ,BACKUP),patch('llm.requests.post',side_effect=[response(429,code='1305'),response()]) as post:
            self.assertEqual(LLM().chat('Workflow',max_tokens=8000),'ok')
        self.assertEqual([c.kwargs['json']['max_tokens'] for c in post.call_args_list],[8000,8000])
