import unittest
from unittest.mock import patch
import test_features as fixtures
module=fixtures.module

class RenameTests(unittest.TestCase):
    setUp=fixtures.FeatureTests.setUp
    tearDown=fixtures.FeatureTests.tearDown

    def rename(self,name):
        return self.client.post(f'/projects/{self.id}/rename',json={'name':name},headers={'X-CSRF-Token':self.token})

    def test_rename_persists_and_keeps_project_files(self):
        folder=self.manager.project_path(self.id)
        before={f.name:f.read_bytes() for f in folder.iterdir() if f.name!='info.json'}
        response=self.rename('  门店预约新版  ')
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.json['project']['name'],'门店预约新版')
        self.assertEqual(self.manager.get_project(self.id)['name'],'门店预约新版')
        self.assertEqual(self.manager.list_projects()[0]['name'],'门店预约新版')
        for url in ['/',f'/edit?project_id={self.id}',f'/projects/{self.id}/export']:
            self.assertIn('门店预约新版',self.client.get(url).get_data(as_text=True))
        self.assertEqual(before,{f.name:f.read_bytes() for f in folder.iterdir() if f.name!='info.json'})
        html=self.client.get('/').get_data(as_text=True)
        self.assertIn('rename-project',html)
        self.assertIn('project-rename.js',html)

    def test_validation_and_csrf(self):
        for name in ['', ' ', 'a'*81, 'a\nb', 123, None]:
            self.assertEqual(self.rename(name).status_code,400)
        self.assertEqual(self.manager.get_project(self.id)['name'],self.info['name'])
        self.assertEqual(self.client.post(f'/projects/{self.id}/rename',json={'name':'新名'}).status_code,403)
        self.assertEqual(self.client.post('/projects/invalid/rename',json={'name':'新名'},headers={'X-CSRF-Token':self.token}).status_code,404)
        self.manager.delete_project(self.id)
        self.assertEqual(self.rename('新名').status_code,404)

    def test_failed_write_is_atomic(self):
        target=self.manager.project_path(self.id)/'info.json'
        before=target.read_bytes()
        with patch('os.replace',side_effect=OSError('disk error')):
            with self.assertLogs(module.app.logger,level='ERROR'):
                self.assertEqual(self.rename('新名').status_code,500)
        self.assertEqual(target.read_bytes(),before)
        self.assertEqual(list(target.parent.glob('.info-*.tmp')),[])

    def test_html_names_escaped_and_shared_styles_available(self):
        self.assertEqual(self.rename('<b>测试</b>').status_code,200)
        html=self.client.get('/').get_data(as_text=True)
        self.assertIn('&lt;b&gt;测试&lt;/b&gt;',html)
        for url in ['/',f'/edit?project_id={self.id}',f'/projects/{self.id}/prd',f'/projects/{self.id}/export']:
            self.assertIn('/static/ui.css',self.client.get(url).get_data(as_text=True))
        with self.client.get('/static/ui.css') as response:
            self.assertEqual(response.status_code,200)
