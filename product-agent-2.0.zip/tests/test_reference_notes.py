import copy
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import test_features
from workflow_document import write_workflow,validate_bundle,validate_workflow,reference_notes,digest
from agents.workflow_agent import WorkflowAgent,record_attempt
from workflow_fixtures import sample_workflow

class ReferenceNotesTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.prd='# PRD\n用户每日签到并分享卡片。';self.html='<!doctype html><html><body>每日签到</body></html>'
        (self.root/'requirement.md').write_text(self.prd);(self.root/'prototype.html').write_text(self.html)
    def tearDown(self):self.tmp.cleanup()

    def test_empty_and_long_advisory_notes_do_not_block_or_get_truncated(self):
        long='后续优化方向。'*200
        data=sample_workflow(self.prd);data['notes']=['', '   ',long]+['参考项'+str(i) for i in range(35)]
        generated=write_workflow(data,self.root)
        self.assertEqual(generated['notes'][0],long);self.assertEqual(len(generated['notes']),36)
        result=validate_bundle(self.root);self.assertEqual(result['notes'],generated['notes'])
        self.assertEqual(json.loads((self.root/'workflow.json').read_text())['notes'][0],long)

    def test_optional_and_legacy_note_formats_remain_readable(self):
        for notes in [None,'后续可以思考分享样式',{'建议':'考虑增加卡片模板'},[None,'',{'问题':'待讨论'}]]:
            data=sample_workflow(self.prd);data['notes']=notes
            result=write_workflow(data,self.root)
            self.assertIsInstance(result['notes'],list);validate_bundle(self.root)
        self.assertEqual(reference_notes(None),[])

    def test_invalid_graph_still_rejected_even_with_valid_reference_notes(self):
        data=sample_workflow(self.prd);data['notes']=['参考方向。'*500]
        data['flows'][0]['edges'][0]['target']='missing'
        with self.assertRaisesRegex(ValueError,'不存在的节点'):validate_workflow(data,self.prd,self.html)

    def test_previous_note_only_failure_reuses_result_without_model_call(self):
        data=sample_workflow(self.prd);data['notes']=['', '需后续讨论。'*200]
        raw=json.dumps(data,ensure_ascii=False)
        record_attempt(self.root,raw,{'state':'invalid','source_digest':digest(self.prd,self.html),'reason':'Workflow 流程校验未通过：待确认事项为空或过长。'})
        with patch('agents.workflow_agent.LLM.chat') as model:
            result=WorkflowAgent().run(output_dir=self.root)
        model.assert_not_called();self.assertTrue(result['flows']);validate_bundle(self.root)

    def test_stale_note_failure_never_reused(self):
        data=sample_workflow(self.prd);data['notes']=['']
        record_attempt(self.root,json.dumps(data),{'state':'invalid','source_digest':'old','reason':'待确认事项为空或过长'})
        with patch('agents.workflow_agent.LLM.chat',return_value=json.dumps(sample_workflow(self.prd))) as model:
            WorkflowAgent().run(output_dir=self.root)
        model.assert_called_once()
