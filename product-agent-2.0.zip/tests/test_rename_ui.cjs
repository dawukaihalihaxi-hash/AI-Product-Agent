/* Code-only checks for edit/save/cancel and stale-name synchronization. */
const assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const node=()=>({hidden:false,disabled:false,textContent:'',dataset:{},events:{},addEventListener(type,fn){this.events[type]=fn;},setAttribute(name,value){this[name]=value;},focus(){},select(){}});
const title=node(),edit=node(),form=node(),input=node(),cancel=node(),save=node(),status=node(),deletion=node(),actions=node();title.textContent='原名称';form.hidden=true;
form.querySelector=()=>save;
const selectors={'.project-name':title,'.rename-project':edit,'.rename-form':form,'.rename-input':input,'.cancel-rename':cancel,'.rename-status':status,'.delete-project':deletion,'.actions':actions};
const row={dataset:{projectId:'test-id'},querySelector:s=>selectors[s]};let requests=0,fail=false;
const context=vm.createContext({document:{querySelectorAll:()=>[row]},csrfToken:'token',localStorage:{setItem(){throw new Error('storage unavailable');}},Date,encodeURIComponent,fetch:async(url,options)=>{requests++;assert.ok(url.endsWith('/test-id/rename'));assert.equal(options.headers['X-CSRF-Token'],'token');assert.equal(JSON.parse(options.body).name,'新名称');return {ok:!fail,json:async()=>fail?{error:'保存失败'}:{project:{name:'新名称'}}};}});
vm.runInContext(fs.readFileSync(path.join(__dirname,'../static/project-rename.js'),'utf8'),context);
(async()=>{
 edit.events.click();assert.equal(input.value,'原名称');assert.equal(form.hidden,false);cancel.events.click();assert.equal(form.hidden,true);assert.equal(requests,0);
 edit.events.click();input.value=' ';await form.events.submit({preventDefault(){}});assert.equal(requests,0);assert.ok(status.textContent.includes('请填写'));
 input.value=' 新名称 ';await form.events.submit({preventDefault(){}});assert.equal(title.textContent,'新名称');assert.equal(deletion.dataset.name,'新名称');assert.equal(actions['aria-label'],'新名称的操作');assert.equal(form.hidden,true);assert.equal(save.disabled,false);
 edit.events.click();input.value='新名称';fail=true;await form.events.submit({preventDefault(){}});assert.equal(form.hidden,false);assert.equal(status.textContent,'保存失败');assert.equal(input.disabled,false);assert.equal(title.textContent,'新名称');
 input.events.keydown({key:'Escape',preventDefault(){}});assert.equal(form.hidden,true);
 console.log('PASS: edit/cancel/Escape; empty name blocked; save syncs title/delete/accessibility labels; storage errors tolerated; failed saves retain editable input');
})().catch(error=>{console.error(error);process.exitCode=1;});
