import copy,json,tempfile,unittest,subprocess,os
from pathlib import Path
from unittest.mock import patch
import test_features
from scope_document import ScopeAgent,ScopeError,validate_scope,render_prd,source_sections
from scope_fixtures import generated_scope,fragment
from prototype_modules import ModularPrototype,PrototypeError,validate_fragment,assemble
from llm import ModelOutputError
from workflow_document import write_workflow,validate_bundle
from workflow_fixtures import sample_workflow

class ModularGenerationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.scope=generated_scope('用户提交预约并查看结果',output_dir=self.root)
        second=copy.deepcopy(self.scope['pages'][0]);second.update(id='p2',name='结果页面')
        self.scope['pages'].append(second)
        self.scope['pages'][0]['actions'][0]['target']='p2'
        self.prd=render_prd(self.scope);(self.root/'requirement.md').write_text(self.prd)
    def tearDown(self):self.tmp.cleanup()

    def test_complete_module_survives_later_failure_and_resume(self):
        from unittest.mock import Mock
        llm=Mock();llm.last_role=None;llm.chat.side_effect=[fragment('p1'),ConnectionError('second failed')]
        with self.assertRaises(ConnectionError):ModularPrototype(llm).run(self.root,self.scope,self.prd)
        module=next((self.root/'.prototype-modules').glob('*/p1.html'));before=module.read_bytes()
        llm.chat.reset_mock();llm.chat.side_effect=None;llm.chat.return_value=fragment('p2')
        result=ModularPrototype(llm).run(self.root,self.scope,self.prd)
        llm.chat.assert_called_once();self.assertEqual(before,module.read_bytes())
        self.assertIn('data-pa-page',result);self.assertTrue(result.endswith('</html>'))
        self.assertEqual((self.root/'requirement.md').read_text(),self.prd)

    def test_truncated_module_is_continued_and_validated(self):
        from unittest.mock import Mock
        whole=fragment('p1');cut=whole.index('PA.register')+9
        llm=Mock();llm.last_role=None;llm.chat.side_effect=[ModelOutputError('output_truncated','cut',partial_text=whole[:cut]),whole[cut:],fragment('p2')]
        result=ModularPrototype(llm).run(self.root,self.scope,self.prd)
        self.assertIn('剩余字符',llm.chat.call_args_list[1].args[0]);self.assertTrue(result.endswith('</html>'))
        self.assertFalse(list((self.root/'.prototype-modules').glob('*/*.partial.txt')))

    def test_invalid_module_repaired_without_regenerating_other_pages(self):
        from unittest.mock import Mock
        llm=Mock();llm.last_role=None;llm.chat.side_effect=[fragment('p1'),'<section>bad</section>',fragment('p2')]
        result=ModularPrototype(llm).run(self.root,self.scope,self.prd)
        self.assertEqual(llm.chat.call_count,3);self.assertIn('只修正当前模块',llm.chat.call_args.args[0]);self.assertIn('PA.navigate',result)

    def test_changed_scope_invalidates_old_modules(self):
        from unittest.mock import Mock
        llm=Mock();llm.last_role=None;llm.chat.side_effect=[fragment('p1'),fragment('p2'),fragment('p1'),fragment('p2')]
        ModularPrototype(llm).run(self.root,self.scope,self.prd)
        changed=copy.deepcopy(self.scope);changed['pages'][0]['purpose']='修改后的页面用途'
        ModularPrototype(llm).run(self.root,changed,self.prd)
        self.assertEqual(llm.chat.call_count,4)

    def test_fragment_rejects_missing_pages_external_calls_and_wrong_ids(self):
        for bad in [fragment('p9'),fragment('p1').replace('<button','<button data-pa-navigate="missing"'),fragment('p1').replace('PA.update','fetch')]:
            with self.assertRaises(PrototypeError):validate_fragment(bad,self.scope['pages'][0],self.scope)

    def test_scope_rejects_invented_actor_and_evidence(self):
        for change in ('actor','quote'):
            data=copy.deepcopy(self.scope)
            if change=='actor':data['actors'].append('系统管理员')
            else:data['pages'][0]['evidence']=['未确认的邮件通知']
            with self.assertRaises(ScopeError):validate_scope(data,self.scope['confirmed_source'])
        prd=render_prd(self.scope)
        for unwanted in ['系统管理员','防作弊','并发50','## 风险分析','## 数据模型']:self.assertNotIn(unwanted,prd)
        self.assertIn('## 五、核心验收点',prd)

    def test_scope_changes_do_not_silently_pass_bundle_validation(self):
        html=assemble(self.scope,{'p1':fragment('p1'),'p2':fragment('p2')});(self.root/'prototype.html').write_text(html)
        data=sample_workflow(self.prd);data['flows'][0]['nodes'][1]['evidence']=[{'source':'prd','quote':self.prd.splitlines()[0]}]
        write_workflow(data,self.root);validate_bundle(self.root)
        (self.root/'scope.json').write_text('{}')
        with self.assertRaisesRegex(ValueError,'范围'):validate_bundle(self.root)

    def test_runtime_shares_state_across_pages_and_scripts_parse(self):
        html=assemble(self.scope,{'p1':fragment('p1'),'p2':fragment('p2')})
        import re
        scripts=re.findall(r'<script>(.*?)</script>',html,re.S)
        node='/Users/k.paris/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
        for script in scripts:
            result=subprocess.run([node,'--check'],input=script,text=True,capture_output=True)
            self.assertEqual(result.returncode,0,result.stderr)
        runtime=scripts[0]
        harness="""global.window=global;window.scrollTo=()=>{};global.sessionStorage={getItem:()=>null,setItem:()=>{}};const pages=[{id:'p1'},{id:'p2'}];global.document={querySelectorAll:()=>pages,addEventListener:()=>{},getElementById:()=>({})};"""
        harness+=runtime+"PA.register('p1',()=>PA.update({published:true}));let seen=false;PA.register('p2',()=>{seen=PA.state.published===true});PA.navigate('p1');PA.navigate('p2');if(!seen||!pages[0].hidden||pages[1].hidden)process.exit(1);"
        result=subprocess.run([node],input=harness,text=True,capture_output=True);self.assertEqual(result.returncode,0,result.stderr)

    def test_database_restore_resumes_only_unfinished_module(self):
        from durable_store import DurableStore
        from model_routing import model_call_context
        from unittest.mock import Mock
        import shutil
        rows={}
        def api(method,url,**kwargs):
            if method=='POST':
                for row in kwargs['json']:rows[(row['kind'],row['record_id'])]=copy.deepcopy(row)
                return Mock(status_code=201)
            return Mock(status_code=200,json=lambda:list(rows.values()))
        store=DurableStore('https://example.supabase.co','test-private',request=api)
        rid='f'*32;directory=self.root/'cache'/'.refinement-drafts'/rid;directory.mkdir(parents=True)
        (directory/'scope.json').write_text(json.dumps(self.scope));(directory/'requirement.md').write_text(self.prd)
        (directory/'task.json').write_text(json.dumps({'id':rid,'owner':'owner','state':'running'}))
        def checkpoint(event):
            if event['state']=='artifact_checkpoint':store.save('task',rid,directory,'owner')
        llm=Mock();llm.last_role=None;llm.chat.side_effect=[fragment('p1'),ConnectionError('interrupted')]
        with model_call_context(checkpoint):
            with self.assertRaises(ConnectionError):ModularPrototype(llm).run(directory,self.scope,self.prd)
        original=next(directory.glob('.prototype-modules/*/p1.html')).read_bytes()
        shutil.rmtree(self.root/'cache');store.restore(self.root/'restored')
        restored=self.root/'restored'/'.refinement-drafts'/rid
        llm.chat.reset_mock();llm.chat.side_effect=None;llm.chat.return_value=fragment('p2')
        html=ModularPrototype(llm).run(restored,self.scope,self.prd)
        llm.chat.assert_called_once();self.assertEqual(next(restored.glob('.prototype-modules/*/p1.html')).read_bytes(),original)
        self.assertIn('</html>',html);self.assertEqual((restored/'requirement.md').read_text(),self.prd)

    def test_confirmed_numeric_rules_survive_scope_and_prd(self):
        from scope_document import write_scope
        raw='用户提交预约并查看结果。客观题选A得10分，其他0分。发布前不可见，发布后显示总分。'
        scoped=write_scope(self.scope,self.root,raw)
        prd=render_prd(scoped)
        self.assertIn('客观题选A得10分，其他0分',prd)
        self.assertIn('发布前不可见',prd)

    def test_repair_reuses_saved_invalid_content(self):
        from unittest.mock import Mock
        llm=Mock();llm.last_role=None;llm.chat.side_effect=['broken', 'still broken']
        with self.assertRaises(PrototypeError):ModularPrototype(llm).run(self.root,self.scope,self.prd)
        llm.chat.reset_mock();llm.chat.side_effect=[fragment('p1'),fragment('p2')]
        ModularPrototype(llm).run(self.root,self.scope,self.prd)
        self.assertEqual(llm.chat.call_count,2)
        self.assertIn('still broken',llm.chat.call_args_list[0].args[0])
        self.assertIn('只修正当前模块',llm.chat.call_args_list[0].args[0])

    def test_body_first_format_and_invalid_current_script(self):
        text=fragment('p1')
        import re
        style=re.search(r'<style[^>]*>.*?</style>',text,re.S).group()
        body_first=text.replace(style,'')+style
        self.assertIn('html',validate_fragment(body_first,self.scope['pages'][0],self.scope))
        with self.assertRaisesRegex(PrototypeError,'currentScript'):
            validate_fragment(text.replace('PA.update','document.currentScript'),self.scope['pages'][0],self.scope)

    def test_action_normalization_preserves_other_attributes(self):
        text=fragment('p1').replace('<button','<button data-pa-action-label="提交"')
        from prototype_modules import normalize_actions
        normalized=normalize_actions(text,self.scope['pages'][0])
        self.assertIn('data-pa-action-label="提交"',normalized)
        validate_fragment(normalized,self.scope['pages'][0],self.scope)

    def test_input_binding_and_shared_update_layer_are_validated(self):
        text=fragment('p1').replace('</section>','<input id="p1-unbound"></section>')
        with self.assertRaisesRegex(PrototypeError,'没有与操作逻辑绑定'):
            validate_fragment(text,self.scope['pages'][0],self.scope)
        scope=copy.deepcopy(self.scope);scope['shared_state']={'record':{'score':0}}
        text=fragment('p1').replace('PA.update({submitted:true})','PA.update({score:10})')
        with self.assertRaisesRegex(PrototypeError,'写入层级'):
            validate_fragment(text,scope['pages'][0],scope)
