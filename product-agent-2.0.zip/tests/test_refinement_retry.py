import unittest
from unittest.mock import patch
import requests
import test_features as fixtures
import test_refinement as refinement
from agents.requirement_agent import RequirementAgent
from agents.html_agent import HtmlAgent

class RetryTests(unittest.TestCase):
    setUp=fixtures.FeatureTests.setUp
    tearDown=fixtures.FeatureTests.tearDown
    start=refinement.RefinementTests.start
    wait=refinement.RefinementTests.wait

    @staticmethod
    def failure(code='1305'):
        response=requests.Response();response.status_code=429
        response._content=('{"error":{"code":"'+code+'"}}').encode()
        return requests.HTTPError(response=response)

    def test_busy_retries_without_duplicate_history_or_prd(self):
        count=0
        def run(*args,**kwargs):
            nonlocal count
            count+=1
            if count<3:raise self.failure()
            return refinement.RefinementTests.generated_html(*args,**kwargs)
        with patch.object(RequirementAgent,'run',side_effect=refinement.RefinementTests.generated_prd) as prd,patch.object(HtmlAgent,'run',side_effect=run),patch('refinement_jobs.sleep') as sleep:
            task=self.start();job=self.wait(task)
        self.assertEqual(job['state'],'ready');self.assertEqual(prd.call_count,1)
        self.assertEqual(sleep.call_count,17);self.assertEqual(len(self.manager.list_projects()),1)

    def test_exhausted_retries_report_exact_cause(self):
        with patch.object(RequirementAgent,'run',side_effect=self.failure()),patch('refinement_jobs.sleep'):
            task=self.start();job=self.wait(task)
        self.assertEqual(job['state'],'failed');self.assertIn('访问量过大',job['message'])

    def test_quota_not_retried(self):
        with patch.object(RequirementAgent,'run',side_effect=self.failure('1113')),patch('refinement_jobs.sleep') as sleep:
            task=self.start();job=self.wait(task)
        sleep.assert_not_called();self.assertIn('余额不足',job['message'])

    def test_lowercase_valid_html_accepted(self):
        html='<!doctype html><HTML><BODY>ok</BODY></HTML>'
        agent=HtmlAgent()
        self.assertTrue(agent.validate_html(agent.clean_html(html)))
