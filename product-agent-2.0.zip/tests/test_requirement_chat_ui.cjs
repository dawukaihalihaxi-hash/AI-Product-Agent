const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict');
const nodes=new Map();
function node(){return {value:'',textContent:'',disabled:false,hidden:false,dataset:{},children:[],events:{},scrollHeight:100,scrollTop:0,clientHeight:100,addEventListener(name,fn){this.events[name]=fn},append(n){this.children.push(n)},replaceChildren(){this.children=[]},querySelector(selector){return nodes.get(selector)}}}
for(const selector of ['.chat-feed','.chat-composer','.chat-input','.chat-status','.chat-brief','.chat-generate','.chat-confirm','.chat-stop','.chat-retry','.chat-new','.chat-generation-status','.chat-recovery','.chat-import','.chat-restore','.chat-download','.chat-summarize','.chat-draft','[type=submit]','[name=conversation_id]','[name=conversation_revision]'])nodes.set(selector,node());
const root=node();root.dataset={kind:'create',project:'',csrf:'token'};nodes.get('.chat-generate').action='/create';
let requests=[],timers=[],location=null,store=new Map(),revision=0;
const chat={id:'a'.repeat(32),kind:'create',state:'idle',revision:0,messages:[],brief:'',message:'开始'};
const sandbox={document:{querySelector:()=>root,createElement:()=>node()},sessionStorage:{getItem:k=>store.get(k),setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)},window:{addEventListener(){},confirm:()=>true,location:{assign:url=>location=url}},setTimeout:(fn)=>{timers.push(fn);return timers.length},clearTimeout(){},AbortController,FormData:class{},fetch:async(url,options)=>{requests.push({url,options});let data;if(url==='/create'){data={task_url:'/task/123'}}else if(url==='/requirement-chats'){data=chat}else if(options.method==='POST'){const body=JSON.parse(options.body);if(body.action==='send'){revision++;chat.state='running';chat.revision=revision;chat.brief='';chat.messages.push({role:'user',content:body.text});}else if(body.action==='summarize'){chat.state='running';chat.last_action='summarize';chat.draft_ready=false;chat.revision=++revision;}data={...chat}}else data={...chat};return {ok:true,status:200,headers:{get:()=> 'application/json'},json:async()=>data};}};
vm.runInNewContext(fs.readFileSync(require('node:path').join(__dirname,'../static/requirement-chat.js'),'utf8'),sandbox);
const flush=()=>new Promise(resolve=>setImmediate(resolve));
(async()=>{
 assert(nodes.get('.chat-confirm').disabled);
 nodes.get('.chat-input').value='预约需求';await nodes.get('.chat-composer').events.submit({preventDefault(){}});await flush();
 assert.equal(requests.length,2);assert(nodes.get('.chat-confirm').disabled);assert.equal(nodes.get('.chat-input').value,'');assert(!nodes.get('.chat-stop').hidden);
 chat.state='idle';chat.brief='完整需求';chat.messages.push({role:'assistant',content:'<script>bad()</script>'});
 await timers.at(-1)();await flush();assert(nodes.get('.chat-confirm').disabled);assert(nodes.get('.chat-draft').hidden);assert(!nodes.get('.chat-summarize').disabled);await nodes.get('.chat-summarize').events.click();await flush();chat.state='idle';chat.draft_ready=true;await timers.at(-1)();await flush();assert(!nodes.get('.chat-draft').hidden);assert(!nodes.get('.chat-confirm').disabled);assert.equal(nodes.get('.chat-brief').textContent,'完整需求');assert.equal(nodes.get('.chat-feed').children[1].textContent,'<script>bad()</script>');
 nodes.get('.chat-input').value='补充内容';nodes.get('.chat-input').events.input();assert(nodes.get('.chat-confirm').disabled);
 nodes.get('.chat-input').value='';nodes.get('.chat-input').events.input();await nodes.get('.chat-generate').events.submit({preventDefault(){}});await flush();assert.equal(location,'/task/123');
 console.log('Requirement chat UI: discussion, explicit summary gate, safe text, pending input guard and explicit generation passed');
})().catch(error=>{console.error(error);process.exitCode=1});
