/* Browser integration + explicit Figma API contract substitute; real Figma QA is separate. */
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const {spawn}=require('node:child_process');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const root=path.resolve(__dirname,'..'),artifacts=path.join(__dirname,'artifacts');
fs.mkdirSync(artifacts,{recursive:true});
const collector=fs.readFileSync(path.join(root,'static/figma-capture.js'),'utf8');
const plugin=fs.readFileSync(path.join(root,'figma-plugin/code.js'),'utf8');
function pluginRuntime(failFont=false) {
 const nodes=[],messages=[];
 const make=type=>{
  const n={id:'node:'+nodes.length,type,children:[],parent:null,removed:false,appendChild(c){if(c.parent)c.parent.children=c.parent.children.filter(n=>n!==c);c.parent=this;this.children.push(c);},resize(w,h){assert.ok(Number.isFinite(w)&&w>0);assert.ok(Number.isFinite(h)&&h>0);this.width=w;this.height=h;},remove(){this.removed=true;if(this.parent)this.parent.children=this.parent.children.filter(n=>n!==this);},async setReactionsAsync(reactions){this.reactions=reactions;},setPluginData(){throw new Error("Local plugin without ID cannot store private plugin data");}};
  nodes.push(n);return n;
 };
 const figma={showUI(){},ui:{postMessage(m){messages.push(m);}},listAvailableFontsAsync:async()=>[{fontName:{family:'Arial',style:'Regular'}},{fontName:{family:'Inter',style:'Regular'}}],loadFontAsync:async()=>{if(failFont)throw new Error('font unavailable');},createFrame:()=>make('FRAME'),createText:()=>make('TEXT'),createRectangle:()=>make('RECTANGLE'),currentPage:{selection:[],flowStartingPoints:[],appendChild(node){node.parent=this;}},viewport:{center:{x:0,y:0},scrollAndZoomIntoView(){}},notify(){}};
 const context=vm.createContext({figma,__html__:'',console,setTimeout});vm.runInContext(plugin,context);
 return {figma,nodes,messages,context};
}
(async()=>{
 let browser,server;
 try {
  browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE||chromium.executablePath()});
  const page=await browser.newPage({viewport:{width:1440,height:900},acceptDownloads:true});
  page.setDefaultTimeout(10000);
  page.on('pageerror',e=>console.log('PAGE ERROR',e.message));
  await page.setContent(`<!doctype html><html><head><style>body{margin:0;font:16px Arial}.card{margin:20px;padding:20px;width:400px;border:1px solid #aaa;border-radius:12px;background:rgb(240,245,250)}button{background:rgb(37,99,235);color:white;border:0;padding:10px}.hidden{display:none}.fancy{box-shadow:0 2px 4px #aaa;background:linear-gradient(red,blue)}.fancy::before{content:'!';}input{padding:8px}</style></head><body><div class="card"><h1>可编辑标题</h1><button>保存按钮</button><input value="演示数据"><select><option>上海</option></select><p>段落内容</p><div class="hidden">不应导出</div><div class="fancy">有限支持</div></div></body></html>`);
  await page.addScriptTag({content:collector});
  const scene=await page.evaluate(()=>window.productAgentCapture());
  const flatten=nodes=>nodes.flatMap(n=>[n,...flatten(n.children||[])]),all=flatten(scene.nodes);
  assert.ok(all.find(n=>n.type==='TEXT'&&n.text==='可编辑标题'));
  assert.ok(all.find(n=>n.name==='button'&&n.background.b>0.8));
  assert.ok(all.find(n=>n.type==='TEXT'&&n.text==='保存按钮'));
  assert.ok(all.find(n=>n.type==='TEXT'&&n.text==='演示数据'));
  assert.ok(all.find(n=>n.type==='TEXT'&&n.text==='上海'));
  assert.ok(!all.find(n=>n.text==='不应导出'));
  for(const code of ['shadow','background-image','pseudo-element','form-control']) assert.ok(scene.warnings.some(w=>w.code===code));
  const runtime=pluginRuntime();
  await runtime.figma.ui.onmessage({type:'import',scene});
  assert.equal(runtime.messages.at(-1).type,'complete');
  assert.ok(runtime.nodes.filter(n=>n.type==='TEXT').length>=5);
  assert.ok(runtime.nodes.find(n=>n.characters==='保存按钮'&&n.parent.type==='FRAME'));
  assert.ok(runtime.nodes.find(n=>n.characters==='演示数据'&&n.parent.name==='input'));
  const before=runtime.nodes.length;
  await runtime.figma.ui.onmessage({type:'import',scene:{...scene,version:99}});
  assert.equal(runtime.messages.at(-1).type,'error');assert.equal(runtime.nodes.length,before);
  const broken=JSON.parse(JSON.stringify(scene));broken.nodes[0].width=-2;
  await runtime.figma.ui.onmessage({type:'import',scene:broken});assert.equal(runtime.messages.at(-1).type,'error');assert.equal(runtime.nodes.length,before);
  const fail=pluginRuntime(true);await fail.figma.ui.onmessage({type:'import',scene});assert.equal(fail.messages.at(-1).type,'error');assert.ok(fail.nodes[0].removed);
  const fallback=pluginRuntime();const fallbackScene=JSON.parse(JSON.stringify(scene));flatten(fallbackScene.nodes).filter(n=>n.type==='TEXT').forEach(n=>n.fontFamily='Unavailable Font');await fallback.figma.ui.onmessage({type:'import',scene:fallbackScene});assert.ok(fallback.messages.at(-1).warnings.some(w=>w.includes('字体替换')));
  const uiSource=fs.readFileSync(path.join(root,'figma-plugin/ui.html'),'utf8').match(/<script>([\s\S]*?)<\/script>/)[1];
  const elements=new Map();
  const fakeDocument={getElementById(id){if(!elements.has(id))elements.set(id,{textContent:'',disabled:false});return elements.get(id);}};
  const uiContext=vm.createContext({document:fakeDocument,window:{},parent:{},console});
  vm.runInContext(uiSource,uiContext);
  uiContext.window.onmessage({source:null,data:{pluginMessage:{type:'complete',count:12,warnings:['字体替换']}}});
  assert.ok(elements.get('status').textContent.includes('12'));
  assert.ok(elements.get('report').textContent.includes('字体替换'));
  console.log('PASS: browser capture; separate text/button/form nodes; hidden-state exclusion; warnings; schema rejection; rollback; font fallback; ID-less plugin; Figma sandbox message relay');
  const py=`import sys,types,os\nsys.path.insert(0,${JSON.stringify(root)})\nc=types.ModuleType('config');c.API_KEY='test';c.BASE_URL='https://example.invalid';c.MODEL='test';sys.modules['config']=c\nimport app\nfrom pathlib import Path\napp.project_manager.projects_dir=Path(os.environ['PRODUCT_AGENT_HISTORY'])\napp.app.run(host='127.0.0.1',port=5127,debug=False)`;
  const history=process.env.PRODUCT_AGENT_HISTORY||path.join(root,'project/projects');
  server=spawn('python3',['-c',py],{env:{...process.env,PRODUCT_AGENT_HISTORY:history},stdio:['ignore','pipe','pipe']});
  let serverOutput='';server.stderr.on('data',s=>serverOutput+=s);
  for(let i=0;i<60;i++) {try{const r=await fetch('http://127.0.0.1:5127/');if(r.ok)break;}catch{}await new Promise(r=>setTimeout(r,100));if(i===59)throw new Error('test server failed: '+serverOutput);}
  const ids=fs.readdirSync(history).filter(id=>fs.existsSync(path.join(history,id,'prototype.html')));
  assert.ok(ids.length,'Need historical HTML fixtures for integration test');
  const summaries=[];
  for(const id of ids) {
   await page.goto(`http://127.0.0.1:5127/projects/${id}/export`);
   const errors=[];const listener=e=>errors.push(e.message);page.on('pageerror',listener);
   await page.locator('#capture').waitFor();await page.waitForFunction(()=>!document.getElementById('capture').disabled);
   await page.locator('#capture').click();await page.waitForFunction(()=>!document.getElementById('download').disabled);
   const downloadEvent=page.waitForEvent('download');await page.locator('#download').scrollIntoViewIfNeeded();
   await page.locator('#download').click();const download=await downloadEvent;
   const output=path.join(artifacts,download.suggestedFilename());await download.saveAs(output);
   const exported=JSON.parse(fs.readFileSync(output,'utf8'));assert.equal(exported.project.id,id);
   const r=pluginRuntime();await r.figma.ui.onmessage({type:'import',scene:exported});assert.equal(r.messages.at(-1).type,'complete',JSON.stringify(r.messages.at(-1)));
   const texts=r.nodes.filter(n=>n.type==='TEXT');assert.ok(texts.length>10);
   summaries.push({id,elements:exported.elementCount,layers:r.messages.at(-1).count,textLayers:texts.length,warnings:exported.warnings.map(w=>w.code),pageErrors:errors});
   if(id==='20261029_182836_046815') {
    await page.frameLocator('#prototype').getByText('预约管理',{exact:true}).click();
    await page.locator('#capture').scrollIntoViewIfNeeded();await page.locator('#capture').click();await page.waitForFunction(()=>!document.getElementById('download').disabled);
    await page.locator('#download').scrollIntoViewIfNeeded();const event=page.waitForEvent('download');await page.locator('#download').click();
    const file=await event;const output=path.join(artifacts,'reservation-controls.json');await file.saveAs(output);
    const state=JSON.parse(fs.readFileSync(output,'utf8')),nodes=flatten(state.nodes);
    assert.ok(nodes.some(n=>n.name.startsWith('button')));assert.ok(nodes.some(n=>n.name.startsWith('input')));assert.ok(nodes.some(n=>n.name.startsWith('select')));
    assert.ok(!nodes.some(n=>n.name==='div#dashboard.view-section.active'));
    console.log('PASS: historical menu switch exports current buttons, input and select instead of hidden dashboard');
   }
   if(id===ids.at(-1))await page.screenshot({path:path.join(artifacts,'export-page.png'),fullPage:true});
   page.off('pageerror',listener);
  }
  await page.goto(`http://127.0.0.1:5127/projects/${ids[0]}/export`);
  await page.waitForFunction(()=>!document.getElementById('capture').disabled);
  await page.locator('#width').fill('1024');await page.locator('#resize').click();
  await page.locator('#capture').click();await page.waitForFunction(()=>!document.getElementById('download').disabled);
  await page.locator('#download').scrollIntoViewIfNeeded();
  const event=page.waitForEvent('download');await page.locator('#download').click();const downloaded=await event;
  const alt=path.join(artifacts,'width-1024.json');await downloaded.saveAs(alt);assert.equal(JSON.parse(fs.readFileSync(alt,'utf8')).viewport.width,1024);
  const bundle=await page.request.get('http://127.0.0.1:5127/figma-plugin/download');assert.equal(bundle.status(),200);assert.ok(bundle.headers()['content-disposition'].includes('.zip'));
  fs.writeFileSync(path.join(artifacts,'results.json'),JSON.stringify(summaries,null,2));
  console.log('PASS: actual sandboxed export page → download JSON → plugin node creation for history projects:',JSON.stringify(summaries));
  console.log('PASS: viewport selection and local plugin bundle download');
 } finally {if(browser)await browser.close();if(server)server.kill();}
})().catch(e=>{console.error(e);process.exitCode=1;});
