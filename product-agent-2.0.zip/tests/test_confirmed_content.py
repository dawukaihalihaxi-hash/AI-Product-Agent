import json,tempfile,unittest
from pathlib import Path
from unittest.mock import Mock,patch
import test_features
from confirmed_content import confirmed_text
from scope_document import ScopeAgent,ScopeError,source_catalog,resolve_scope_evidence,validate_scope,render_prd
from scope_fixtures import generated_scope
from agents.workflow_agent import WorkflowAgent
from workflow_fixtures import sample_workflow

class ConfirmedContentTests(unittest.TestCase):
    def test_nested_advice_removed_without_removing_next_confirmed_section(self):
        text='# 需求草稿\n## 已确认\n用户报名\n## 优化建议与待确认事项（仅供参考）\n自动保存草稿\n### 详情\n是否增加通知？\n## 核心规则\n报名截止当天00:00'
        result=confirmed_text(text)
        self.assertIn('用户报名',result);self.assertIn('报名截止当天00:00',result)
        self.assertNotIn('自动保存',result);self.assertNotIn('是否增加',result)
        self.assertEqual(confirmed_text('# 参考建议管理系统\n用户查看建议'),'# 参考建议管理系统\n用户查看建议')

    def test_fixed_ids_restore_original_quotes_and_reject_invalid_ids(self):
        source='用户参加考试。\n选 A 得 10 分。'
        with tempfile.TemporaryDirectory() as tmp:
            data=generated_scope(source,output_dir=tmp);data['pages'][0]['evidence']=[{'ref':'C0002'}];data['flow'][0]['evidence']=['C0002'];data['notes']=['建议新增通知']
            result=resolve_scope_evidence(data,source_catalog(source));validate_scope(result,source)
            self.assertEqual(result['pages'][0]['evidence'],['选 A 得 10 分。']);self.assertEqual(result['notes'],[])
            result['flow'][0]['evidence']=[{'ref':'C9999'}]
            with self.assertRaisesRegex(ScopeError,'flow第1项'):resolve_scope_evidence(result,source_catalog(source))

    def test_legacy_spacing_allowed_but_number_change_rejected(self):
        source='用户考试，选 A 得 10 分。'
        with tempfile.TemporaryDirectory() as tmp:
            data=generated_scope(source,output_dir=tmp);data['pages'][0]['evidence']=['用户考试，选A得10分。'];validate_scope(data,source)
            data['pages'][0]['evidence']=['用户考试，选A得100分。']
            with self.assertRaises(ScopeError):validate_scope(data,source)

    def test_refinement_reads_old_prd_and_latest_correction_without_advice(self):
        with tempfile.TemporaryDirectory() as tmp:
            data=generated_scope('用户考试',output_dir=tmp);(Path(tmp)/'scope.json').unlink()
            data['pages'][0]['evidence']=[{'ref':'C0001'}];data['flow'][0]['evidence']=[{'ref':'C0001'}]
            llm=Mock();llm.last_role=None;llm.chat.return_value=json.dumps(data,ensure_ascii=False)
            with patch('scope_document.LLM',return_value=llm):scope=ScopeAgent().run('用户考试',base_prd='## 已确认\n旧考试60分钟\n## 优化建议\n新增短信通知',changes='## 本次修改\n改成90分钟\n## 待确认事项\n增加秘密报表',output_dir=tmp)
            prompt=llm.chat.call_args.args[0]
            self.assertIn('旧考试60分钟',prompt);self.assertIn('改成90分钟',prompt)
            self.assertNotIn('新增短信通知',prompt);self.assertNotIn('增加秘密报表',prompt)
            self.assertNotIn('## 六',render_prd(scope));self.assertEqual(scope['notes'],[])

    def test_invalid_scope_saved_for_targeted_retry(self):
        with tempfile.TemporaryDirectory() as tmp:
            data=generated_scope('用户考试',output_dir=tmp);(Path(tmp)/'scope.json').unlink();data['pages'][0]['evidence']=[{'ref':'C9999'}]
            llm=Mock();llm.last_role='备用模型';llm.chat.return_value=json.dumps(data)
            with patch('scope_document.LLM',return_value=llm),self.assertRaises(ScopeError):ScopeAgent().run('用户考试',output_dir=tmp)
            self.assertTrue((Path(tmp)/'.scope-diagnostics/latest.json').is_file())
            data['pages'][0]['evidence']=[{'ref':'C0001'}];llm.chat.return_value=json.dumps(data)
            with patch('scope_document.LLM',return_value=llm):ScopeAgent().run('用户考试',output_dir=tmp)
            self.assertIn('修复现有范围结果',llm.chat.call_args.args[0])

    def test_workflow_does_not_receive_old_advice_or_save_new_notes(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp);(folder/'requirement.md').write_text('# PRD\n用户考试\n## 优化建议\n增加秘密建议模块');(folder/'prototype.html').write_text('<html><body>考试</body></html>')
            data=sample_workflow();data['notes']=['建议新增通知'];data['flows'][0]['nodes'][1]['evidence']=[{'ref':'P001'}]
            with patch('agents.workflow_agent.LLM.chat',return_value=json.dumps(data)) as model:result=WorkflowAgent().run(output_dir=folder)
            self.assertNotIn('秘密建议模块',model.call_args.args[0]);self.assertEqual(result['notes'],[])
