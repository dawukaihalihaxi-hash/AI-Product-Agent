import os,subprocess,sys,unittest
from pathlib import Path

class GuestDemoTests(unittest.TestCase):
    def run_case(self,body):
        root=Path(__file__).resolve().parents[1]
        setup="""
import os,sys,tempfile,json,base64
from pathlib import Path
from unittest.mock import patch
sys.path[:0]=[str(Path.cwd()/'tests'),str(Path.cwd())]
import test_features as fixtures
import wsgi
app=wsgi.app;app.config['TESTING']=True
from project.project_manager import ProjectManager
with tempfile.TemporaryDirectory() as tmp:
 manager=ProjectManager();manager.projects_dir=Path(tmp)/'projects';manager.projects_dir.mkdir();manager.output_dir=Path(tmp)/'output';manager.output_dir.mkdir()
 (manager.output_dir/'requirement.md').write_text('# PRD')
 (manager.output_dir/'prototype.html').write_text('<!doctype html><html><body>private</body></html>')
 with patch.object(fixtures.module,'project_manager',manager):
"""
        code=setup+'\n'.join('  '+line for line in body.splitlines())+'\n'
        env=dict(os.environ,RENDER='true',PRODUCT_AGENT_SECRET_KEY='test-session-signing',MODEL_API_KEY='test-model-key',PRODUCT_AGENT_ACCESS_PASSWORD='test-password',PRODUCT_AGENT_ACCESS_MODE='public',MODEL_FALLBACK_ENABLED='0')
        result=subprocess.run([sys.executable,'-B','-c',code],cwd=root,env=env,text=True,capture_output=True)
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)

    def test_guest_opens_without_credentials_and_settings_stay_private(self):
        self.run_case("""client=app.test_client()
r=client.get('/')
assert r.status_code==200 and 'WWW-Authenticate' not in r.headers
assert client.get('/settings/backup-model').status_code==404
assert client.get('/prd').status_code==404
assert client.get('/preview').status_code==404
with client.session_transaction() as s:assert s.get('refinement_owner') and s.permanent
""")

    def test_projects_and_mutations_are_isolated_between_guests(self):
        self.run_case("""first=app.test_client();second=app.test_client();first.get('/');second.get('/')
with first.session_transaction() as s:owner=s['refinement_owner']
project=manager.create_project('私有测试需求',owner=owner);pid=project['id']
assert '私有测试需求' in first.get('/').get_data(as_text=True)
assert '私有测试需求' not in second.get('/').get_data(as_text=True)
assert first.get('/projects/'+pid+'/prd').status_code==200
for suffix in ['/prd','/preview','/export','/figma-source','/workflow','/result']:
 assert second.get('/projects/'+pid+suffix).status_code==404,suffix
for suffix in ['/delete','/rename','/refine','/apply-refinement']:
 assert second.post('/projects/'+pid+suffix).status_code==404,suffix
assert second.get('/edit?project_id='+pid).status_code==404
""")

    def test_password_mode_and_existing_admin_access_remain_available(self):
        self.run_case("""client=app.test_client();legacy=manager.create_project('旧项目')
assert '旧项目' not in client.get('/').get_data(as_text=True)
headers={'Authorization':'Basic '+base64.b64encode(b'demo:test-password').decode()}
assert '旧项目' in client.get('/',headers=headers).get_data(as_text=True)
with patch.dict(os.environ,{'PRODUCT_AGENT_ACCESS_MODE':'password'}):
 assert client.get('/').status_code==401
 assert client.get('/',headers=headers).status_code==200
 assert client.get('/healthz').status_code==200
""")

    def test_generated_guest_project_keeps_task_owner(self):
        self.run_case("""from refinement_jobs import RefinementJobs
from workflow_fixtures import generated_workflow
service=RefinementJobs(manager,app.logger)
data={'schema':'product-agent/stage-backup','version':1,'kind':'create','name':'访客产品','raw':'测试','prd':'# PRD','html':'<!doctype html><html><body>test</body></html>'}
job=service.import_creation_results(data,'guest-owner');folder=service.path(job['id'])
generated_workflow(output_dir=folder);service.checkpoint(job,'workflow');service.update(job,state='ready')
pid=service.save(job['id'],'new');assert manager.get_project(pid)['owner']=='guest-owner'
""")
