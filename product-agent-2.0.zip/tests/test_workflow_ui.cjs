const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const script=fs.readFileSync(path.join(__dirname,'../static/workflow-view.js'),'utf8');
const events={},elements={};
function element(id,extra={}){return elements[id]={style:{},addEventListener:(type,handler)=>events[id+':'+type]=handler,...extra};}
const image=element('workflow-image',{naturalWidth:1000,complete:false,dataset:{baseUrl:'/image'}});
const view=element('workflow-viewport',{clientWidth:520,scrollTop:20,scrollLeft:20});
for(const id of ['zoom-status','zoom-in','zoom-out','zoom-fit','flow-select'])element(id);
vm.runInNewContext(script,{document:{getElementById:id=>elements[id],querySelectorAll:()=>[]}});
events['workflow-image:load']();assert.equal(image.style.width,'500px');
events['zoom-in:click']();assert.equal(image.style.width,'600px');
events['zoom-fit:click']();assert.equal(image.style.width,'500px');
events['flow-select:change']({target:{value:'预约&取消',options:[{text:'预约取消'}],selectedIndex:0}});
assert.equal(image.src,'/image?flow='+encodeURIComponent('预约&取消'));assert.equal(view.scrollTop,0);
console.log('PASS: read-only Workflow preview fit/zoom and flow selection');
