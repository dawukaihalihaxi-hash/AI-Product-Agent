from pathlib import Path
from unittest.mock import patch
import test_refinement as refinement
from test_refinement import RequirementAgent, HtmlAgent
import unittest

class ResultTests(unittest.TestCase):
    setUp=refinement.RefinementTests.setUp
    tearDown=refinement.RefinementTests.tearDown

    def generate(self):
        with patch.object(RequirementAgent,'run',side_effect=refinement.RefinementTests.generated_prd), patch.object(HtmlAgent,'run',side_effect=refinement.RefinementTests.generated_html):
            response=self.client.post(f'/projects/{self.id}/refine',data={'csrf_token':self.token,'changes':'增加搜索'},headers={'Accept':'application/json'})
            task_id=response.json['task_url'].rsplit('/',1)[1]
            refinement.RefinementTests.wait(self,task_id)
        response=self.client.post(f'/refinement-tasks/{task_id}/save',data={'csrf_token':self.token,'mode':'new'})
        self.assertEqual(response.status_code,303)
        return next(p for p in self.manager.list_projects() if p['id']!=self.id), response.headers['Location']

    def apply(self, revision, **kwargs):
        return self.client.post(f'/projects/{revision["id"]}/apply-refinement',data={'csrf_token':self.token,'confirmed':'yes'},**kwargs)

    def test_retired_result_redirects_and_history_has_no_button(self):
        revision,url=self.generate()
        self.assertTrue(url.startswith('/#project-'))
        html=self.client.get('/').get_data(as_text=True)
        self.assertNotIn('>优化结果</a>',html)
        self.assertIn(f'/edit?project_id={revision["id"]}',html)
        response=self.client.get(f'/projects/{revision["id"]}/refinement-result')
        self.assertEqual(response.status_code,303)
        self.assertTrue(response.location.startswith('/#project-'))
        self.assertEqual(len(self.manager.list_projects()),2)

    def test_apply_backups_and_preserves_generated_revision(self):
        original=self.manager.get_prd(self.id)
        revision,url=self.generate()
        self.assertEqual(self.apply(revision).status_code,303)
        self.assertEqual(self.manager.get_prd(self.id),'# 更新后的 PRD')
        backups=list(self.manager.projects_dir.glob('.backup-*'))
        self.assertEqual((backups[0]/'requirement.md').read_text(),original)
        self.assertEqual(len(self.manager.list_projects()),1)
        current=self.manager.get_project(self.id)
        self.assertEqual(current['version'],2)
        html=self.client.get(f'/edit?project_id={self.id}').get_data(as_text=True)
        self.assertIn('# 更新后的 PRD',html)
        self.assertEqual(self.apply(revision).status_code,303)
        self.assertEqual(len(list(self.manager.projects_dir.glob('.backup-*'))),1)

    def test_confirmation_and_csrf(self):
        revision,_=self.generate()
        url=f'/projects/{revision["id"]}/apply-refinement'
        self.assertEqual(self.client.post(url,data={'confirmed':'yes'}).status_code,403)
        self.assertEqual(self.client.post(url,data={'csrf_token':self.token}).status_code,400)
        self.assertEqual(self.manager.get_prd(self.id),'# PRD')

    def test_changed_source_cannot_be_overwritten(self):
        revision,_=self.generate()
        self.manager.rename_project(self.id,'用户刚修改名称')
        self.assertEqual(self.apply(revision).status_code,409)
        self.assertEqual(self.manager.get_prd(self.id),'# PRD')

    def test_missing_source_keeps_new_result(self):
        revision,url=self.generate()
        self.manager.delete_project(self.id)
        self.assertEqual(self.client.get(url).status_code,200)
        self.assertEqual(self.apply(revision).status_code,409)
        self.assertIsNotNone(self.manager.get_html_path(revision['id']))

    def test_failed_replace_restores_source(self):
        revision,_=self.generate()
        source=self.manager.project_path(self.id)
        before={f.name:f.read_bytes() for f in source.iterdir()}
        import os
        real=os.replace
        calls=0
        def fail_once(a,b):
            nonlocal calls
            calls+=1
            if calls==2: raise OSError('simulated disk error')
            return real(a,b)
        with patch('os.replace',side_effect=fail_once):
            with self.assertRaises(OSError):self.manager.apply_refinement(revision['id'])
        self.assertEqual(before,{f.name:f.read_bytes() for f in source.iterdir()})
        self.assertFalse(self.manager.get_project(revision['id']).get('applied_to_source_at'))
