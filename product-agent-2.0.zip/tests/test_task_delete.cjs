const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../static/task-delete.js'),'utf8');
function setup(confirm,result){
 let handler,calls=0,reloaded=0;const note={textContent:''};
 const button={disabled:false,dataset:{name:'预约系统',url:'/delete'},addEventListener(type,fn){handler=fn;},closest(){return {querySelector(){return note;}};}};
 const root={dataset:{csrf:'csrf'},querySelectorAll(){return [button];}};
 vm.runInNewContext(source,{document:{getElementById(){return root;}},window:{confirm:()=>confirm,location:{reload(){reloaded++;}}},AbortController,setTimeout,clearTimeout,fetch:async(url,args)=>{calls++;assert.equal(args.headers['X-CSRF-Token'],'csrf');assert.deepEqual(JSON.parse(args.body),{confirmed:true});return result;}});
 return {button,note,click:()=>handler(),calls:()=>calls,reloaded:()=>reloaded};
}
(async()=>{
 let test=setup(false);await test.click();assert.equal(test.calls(),0);
 test=setup(true,{ok:true,json:async()=>({deleted:true})});await test.click();assert.equal(test.reloaded(),1);assert.equal(test.button.disabled,true);
 test=setup(true,{ok:false,json:async()=>({error:'删除未完成'})});await test.click();assert.equal(test.reloaded(),0);assert.equal(test.button.disabled,false);assert.match(test.note.textContent,/删除未完成/);
 console.log('PASS: task deletion confirmation, authenticated request, success refresh and failure retry');
})().catch(error=>{console.error(error);process.exitCode=1;});
