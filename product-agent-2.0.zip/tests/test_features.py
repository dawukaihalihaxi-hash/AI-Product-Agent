import io
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
config = types.ModuleType('config')
config.API_KEY = 'test'; config.BASE_URL = 'https://example.invalid'; config.MODEL = 'test'
sys.modules.setdefault('config', config)
import app as module
from project.project_manager import ProjectManager

class FeatureTests(unittest.TestCase):
    def setUp(self):
        import os
        self.model_env = patch.dict(os.environ, {'MODEL_FALLBACK_ENABLED':'0'})
        self.model_env.start()
        self.addCleanup(self.model_env.stop)
        self.tmp = tempfile.TemporaryDirectory()
        self.manager = ProjectManager()
        self.manager.projects_dir = Path(self.tmp.name) / 'projects'
        self.manager.projects_dir.mkdir()
        self.manager.output_dir = Path(self.tmp.name) / 'output'
        self.manager.output_dir.mkdir()
        (self.manager.output_dir / 'requirement.md').write_text('# PRD')
        (self.manager.output_dir / 'prototype.html').write_text('<html><body><h1>测试</h1></body></html>')
        self.info = self.manager.create_project('测试需求')
        self.id = self.info['id']
        self.mock = patch.object(module, 'project_manager', self.manager)
        self.mock.start()
        from workflow_fixtures import generated_workflow
        self.workflow_mock = patch('refinement_jobs.WorkflowAgent.run', side_effect=generated_workflow)
        self.workflow_mock.start()
        from scope_fixtures import generated_scope
        self.scope_mock=patch('refinement_jobs.ScopeAgent.run',side_effect=generated_scope)
        self.scope_mock.start()
        self.addCleanup(self.scope_mock.stop)
        module.app.config['TESTING'] = True
        self.client = module.app.test_client()
        self.client.get('/')
        with self.client.session_transaction() as session:
            self.token = session['csrf_token']

    def tearDown(self):
        self.workflow_mock.stop(); self.mock.stop(); self.tmp.cleanup()

    def delete(self, **kwargs):
        return self.client.post(f'/projects/{self.id}/delete', headers={'X-CSRF-Token': self.token}, **kwargs)

    def test_confirmation_and_csrf_required(self):
        self.assertEqual(self.delete(json={}).status_code, 400)
        self.assertEqual(self.client.post(f'/projects/{self.id}/delete', json={'confirmed': True}).status_code, 403)
        self.assertIsNotNone(self.manager.get_project(self.id))

    def test_delete_persists_and_invalidates_views(self):
        self.assertEqual(self.delete(json={'confirmed': True}).status_code, 200)
        self.assertEqual(self.manager.list_projects(), [])
        self.assertFalse((self.manager.projects_dir / self.id).exists())
        for suffix in ['prd', 'preview']:
            self.assertEqual(self.client.get(f'/projects/{self.id}/{suffix}').status_code, 404)
        self.assertEqual(self.delete(json={'confirmed': True}).status_code, 200)
        self.assertTrue((self.manager.output_dir / 'prototype.html').exists())

    def test_invalid_path(self):
        for value in ['..', '../output', '/tmp', 'invalid']:
            with self.assertRaises(ValueError): self.manager.delete_project(value)

    def test_existing_views(self):
        for url in ['/', f'/projects/{self.id}/prd', f'/projects/{self.id}/preview', f'/edit?project_id={self.id}']:
            with self.client.get(url) as response:
                self.assertEqual(response.status_code, 200)
        self.assertEqual(self.client.post('/create', data={'requirement': ' '}).status_code, 400)

    def test_export_page_and_html(self):
        with self.client.get(f'/projects/{self.id}/export') as response:
            self.assertEqual(response.status_code, 200)
            html = response.get_data(as_text=True)
            self.assertIn('生成 Figma 图层数据', html)
            self.assertIn('id="interactive" type="checkbox" checked', html)
            self.assertIn('sandbox="allow-scripts"', html)
            self.assertIn(self.id, html)
        with self.client.get(f'/projects/{self.id}/export?format=html') as response:
            self.assertEqual(response.status_code, 200)
            self.assertIn('attachment', response.headers['Content-Disposition'])
            self.assertEqual(response.data, (self.manager.output_dir / 'prototype.html').read_bytes())
        self.assertEqual(self.client.get(f'/projects/{self.id}/export?format=bad').status_code, 400)

    def test_capture_source_is_isolated_and_keeps_original(self):
        original = (self.manager.projects_dir / self.id / 'prototype.html').read_bytes()
        with self.client.get(f'/projects/{self.id}/figma-source') as response:
            self.assertEqual(response.status_code, 200)
            self.assertIn('productAgentCapture', response.get_data(as_text=True))
            self.assertIn('productAgentInteractions', response.get_data(as_text=True))
            self.assertIn("connect-src 'none'", response.headers['Content-Security-Policy'])
            self.assertIn('sandbox allow-scripts;', response.headers['Content-Security-Policy'])
        self.assertEqual((self.manager.projects_dir / self.id / 'prototype.html').read_bytes(), original)

    def test_plugin_bundle(self):
        from zipfile import ZipFile
        with self.client.get('/figma-plugin/download') as response:
            self.assertEqual(response.status_code, 200)
            with ZipFile(io.BytesIO(response.data)) as bundle:
                self.assertEqual(set(bundle.namelist()), {'manifest.json', 'code.js', 'ui.html', 'README.md'})
                manifest = json.loads(bundle.read('manifest.json'))
                self.assertEqual(manifest['networkAccess']['allowedDomains'], ['none'])
                self.assertIn('createText', bundle.read('code.js').decode())

    def test_export_missing_and_deleted(self):
        self.assertEqual(self.client.get('/projects/invalid/export').status_code, 404)
        (self.manager.projects_dir / self.id / 'prototype.html').unlink()
        self.assertEqual(self.client.get(f'/projects/{self.id}/export').status_code, 404)
        self.delete(json={'confirmed': True})
        self.assertEqual(self.client.get(f'/projects/{self.id}/export').status_code, 404)

    def test_create_regression(self):
        import test_refinement as refinement
        with patch.object(module.RequirementAgent, 'run', side_effect=refinement.RefinementTests.generated_prd), patch.object(module.HtmlAgent, 'run', side_effect=refinement.RefinementTests.generated_html):
            response = self.client.post('/create', data={'requirement': '新的需求','csrf_token':self.token},headers={'Accept':'application/json'})
            self.assertEqual(response.status_code,202)
            task_id=response.json['task_url'].rsplit('/',1)[1]
            job=refinement.RefinementTests.wait(self,task_id)
        self.assertEqual(job['state'],'saved')
        response=self.client.get(f'/projects/{job["saved_id"]}/result')
        self.assertEqual(response.status_code,200)
        self.assertIn('导出至 Figma',response.get_data(as_text=True))
        self.assertEqual(len(self.manager.list_projects()),2)

    def test_ui_confirmation_and_sync(self):
        html = self.client.get('/').get_data(as_text=True)
        for value in ['window.confirm', 'confirmed: true', "addEventListener('storage'", 'window.location.reload']:
            self.assertIn(value, html)

    def test_project_save_retry_does_not_duplicate_after_database_failure(self):
        from durable_store import DurabilityError
        from unittest.mock import Mock
        store=Mock();store.save.side_effect=[DurabilityError('temporary database failure'),None]
        self.manager.store=store;reserved='20261112_120000_000001'
        with self.assertRaises(DurabilityError):
            self.manager.create_project('retry requirement',project_id=reserved,owner='owner')
        retry=self.manager.create_project('retry requirement',project_id=reserved,owner='owner')
        self.assertEqual(retry['id'],reserved)
        self.assertEqual(len(self.manager.list_projects()),2)
        with self.assertRaises(ValueError):self.manager.create_project('retry requirement',project_id=reserved,owner='other')

if __name__ == '__main__': unittest.main()
