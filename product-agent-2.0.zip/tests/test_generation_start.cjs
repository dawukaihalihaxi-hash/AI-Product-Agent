const vm=require('node:vm'),fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const script=fs.readFileSync(path.join(__dirname,'../static/generation-start.js'),'utf8');
async function run(fetch){
 let submit,assigned;
 const input={value:'预约系统'},status={textContent:''},button={disabled:false};
 const form={action:'/create',querySelector:selector=>selector.includes('requirement')?input:button,addEventListener:(type,handler)=>submit=handler};
 const document={getElementById:id=>id==='creation-form'?form:status};
 const context={document,fetch,AbortController,FormData:class {},setTimeout:()=>1,clearTimeout(){},TypeError,sessionStorage:{setItem(){},getItem(){}},window:{location:{assign:url=>assigned=url},addEventListener(){}}};
 vm.runInNewContext(script,context);await submit({preventDefault(){}});
 return {status,button,input,get assigned(){return assigned;}};
}
(async()=>{
 let s=await run(async()=>{throw new TypeError('offline')});assert.match(s.status.textContent,/端口/);assert.match(s.status.textContent,/需求已保留/);assert.equal(s.button.disabled,false);assert.equal(s.input.value,'预约系统');
 s=await run(async()=>({ok:false,status:403,headers:{get:()=> 'application/json'},json:async()=>({error:'页面已过期，请刷新'})}));assert.match(s.status.textContent,/页面已过期/);assert.equal(s.button.disabled,false);
 s=await run(async()=>({ok:false,status:502,headers:{get:()=> 'text/html'}}));assert.match(s.status.textContent,/HTTP 502/);assert.equal(s.assigned,undefined);
 s=await run(async()=>({ok:true,status:202,headers:{get:()=> 'application/json'},json:async()=>({task_url:'/task/1'})}));assert.equal(s.assigned,'/task/1');
 console.log('PASS: first generation connection failures, HTTP errors, retained input, and task navigation');
})().catch(error=>{console.error(error);process.exitCode=1;});
