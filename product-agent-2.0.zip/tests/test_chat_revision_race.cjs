const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict');
const nodes=new Map();
function node(){return {value:'',textContent:'',disabled:false,hidden:false,dataset:{},children:[],events:{},scrollHeight:100,scrollTop:0,clientHeight:100,addEventListener(name,fn){this.events[name]=fn},append(n){this.children.push(n)},replaceChildren(){this.children=[]},querySelector(selector){return nodes.get(selector)}}}
for(const selector of ['.chat-feed','.chat-composer','.chat-input','.chat-status','.chat-brief','.chat-generate','.chat-confirm','.chat-stop','.chat-retry','.chat-new','.chat-generation-status','.chat-recovery','.chat-import','.chat-restore','.chat-download','.chat-summarize','.chat-draft','[type=submit]','[name=conversation_id]','[name=conversation_revision]'])nodes.set(selector,node());
const root=node();root.dataset={kind:'create',project:'',csrf:'token'};nodes.get('.chat-generate').action='/create';
let requests=[],timers=[],location=null,store=new Map(),revision=0;
let resolveOld;const oldResponse=new Promise(r=>resolveOld=r);
const chat={id:'a'.repeat(32),kind:'create',state:'idle',revision:0,messages:[],brief:'',message:'开始'};
const sandbox={document:{querySelector:()=>root,createElement:()=>node()},sessionStorage:{getItem:k=>store.get(k),setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)},window:{addEventListener(){},confirm:()=>true,location:{assign:url=>location=url}},setTimeout:(fn)=>{timers.push(fn);return timers.length},clearTimeout(){},AbortController,FormData:class{},fetch:async()=>oldResponse};
const newest={id:'a'.repeat(32),kind:'create',state:'idle',revision:5,messages:[{role:'user',content:'改成90分钟'}],brief:'最新草稿：90分钟',draft_ready:true,message:'已整理'};
store.set('product-agent-chat:create:',newest.id);store.set('product-agent-chat:create::snapshot',JSON.stringify(newest));
vm.runInNewContext(fs.readFileSync(require('node:path').join(__dirname,'../static/requirement-chat.js'),'utf8'),sandbox);
(async()=>{
 assert.equal(nodes.get('.chat-brief').textContent,'最新草稿：90分钟');
 resolveOld({ok:true,status:200,headers:{get:()=> 'application/json'},json:async()=>({...newest,revision:4,brief:'旧草稿：60分钟'})});
 await new Promise(r=>setImmediate(r));await new Promise(r=>setImmediate(r));
 assert.equal(nodes.get('.chat-brief').textContent,'最新草稿：90分钟');
 assert.equal(nodes.get('[name=conversation_revision]').value,5);
 console.log('PASS: delayed old response cannot replace newest draft or submitted revision');
})().catch(e=>{console.error(e);process.exitCode=1});
