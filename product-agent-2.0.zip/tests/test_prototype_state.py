import unittest,copy,tempfile,json
from pathlib import Path
from unittest.mock import Mock
import test_features
from prototype_state import patch_keys,state_errors,state_instructions
from prototype_modules import ModularPrototype
from scope_fixtures import generated_scope,fragment
from scope_document import render_prd

class StateContractTests(unittest.TestCase):
 def test_every_key_quoted_and_shorthand_is_checked(self):
  self.assertEqual(patch_keys("PA.update({records: rows, 'examRecord': {answer: x}, extra});"),['records','examRecord','extra'])
 def test_nested_keys_comments_and_strings_are_not_operations(self):
  js='// PA.update({bad:1})\nlet x="PA.update({bad:1})"; PA.update({records: rows.map(r=>({...r, answer:"a,b}"}))});'
  self.assertEqual(patch_keys(js),['records'])
 def test_unknown_container_is_not_guessed_into_collection(self):
  scope={'shared_state':{'records':[]}}
  self.assertEqual(state_errors('PA.update({examRecord:{answer:1}})',scope),['examRecord'])
  self.assertEqual(state_errors('PA.update({records: updated})',scope),[])
 def test_actual_contract_and_completed_scripts_are_supplied(self):
  text=state_instructions({'shared_state':{'items':[{'id':'x','value':0}]}},{'p1':'<script>PA.update({items: rows})</script>'})
  self.assertIn('PA.state["items"]',text);self.assertIn('PA.update({items: rows})',text);self.assertNotIn('examRecord',text)
 def test_cached_failure_repaired_and_completed_module_untouched(self):
  with tempfile.TemporaryDirectory() as td:
   root=Path(td);scope=generated_scope('用户提交预约并查看结果',output_dir=root)
   second=copy.deepcopy(scope['pages'][0]);second.update(id='p2',name='结果页');scope['pages'].append(second)
   prd=render_prd(scope);llm=Mock();llm.last_role=None
   llm.chat.side_effect=[fragment('p1'),ConnectionError('stopped')]
   with self.assertRaises(ConnectionError):ModularPrototype(llm).run(root,scope,prd)
   first=next((root/'.prototype-modules').glob('*/p1.html'));before=first.read_bytes()
   invalid=first.parent/'p2.invalid.txt';bad=fragment('p2').replace('PA.update({','PA.update({examRecord:1,')
   invalid.write_text(bad);llm.chat.reset_mock();llm.chat.side_effect=None;llm.chat.return_value=fragment('p2')
   ModularPrototype(llm).run(root,scope,prd)
   self.assertEqual(first.read_bytes(),before);llm.chat.assert_called_once()
   prompt=llm.chat.call_args.args[0]
   self.assertIn('实际共享数据读写规范',prompt);self.assertIn('p1 已有读写脚本',prompt);self.assertIn(bad,prompt)
