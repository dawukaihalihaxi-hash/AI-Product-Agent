const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
function element(id,width,x=0){return {id,tagName:'DIV',nodeType:1,className:'',children:[],childNodes:[],scrollWidth:width,clientWidth:width,scrollHeight:100,clientHeight:100,scrollLeft:0,scrollTop:0,getBoundingClientRect:()=>({x,y:0,width,height:100})};}
(async()=>{
 const body=element('body',1440);body.tagName='BODY';
 const scroll=element('table-container',500),child=element('table',1000,-40);scroll.scrollWidth=1000;scroll.scrollLeft=40;scroll.childNodes=scroll.children=[child];body.childNodes=body.children=[scroll];
 const style=el=>new Proxy({display:'block',visibility:'visible',opacity:'1',backgroundColor:'rgba(0,0,0,0)',overflowX:el===scroll?'auto':'visible',overflowY:'visible',textTransform:'none',mixBlendMode:'normal',zIndex:'auto'}, {get:(obj,key)=>key in obj?obj[key]:String(key).includes('Radius')?'0px':String(key).endsWith('Width')?'0px':'none'});
 const document={body,documentElement:{scrollWidth:1440,scrollHeight:900},fonts:{ready:Promise.resolve()},getAnimations:()=>[],querySelector:()=>null,querySelectorAll:()=>[]};
 const context=vm.createContext({document,window:{addEventListener(){}},getComputedStyle:style,Node:{ELEMENT_NODE:1,TEXT_NODE:3},innerWidth:1440,innerHeight:900,requestAnimationFrame:fn=>fn(),setTimeout:()=>1,parent:{}});
 vm.runInContext(fs.readFileSync(path.join(__dirname,'../static/figma-capture.js'),'utf8'),context);
 const scene=await context.window.productAgentCapture();const container=scene.nodes[0].children[0];
 assert.equal(container.scrollDirection,'HORIZONTAL');assert.equal(container.clip,true);
 assert.equal(container.children[0].x,0);assert.equal(container.children[0].width,1000);
 assert.equal(scroll.scrollLeft,40,'capture must not alter the real prototype scroll position');
 console.log('PASS: horizontal scroll metadata, full content width, scroll offset normalization, unchanged prototype state');
})().catch(error=>{console.error(error);process.exitCode=1;});
