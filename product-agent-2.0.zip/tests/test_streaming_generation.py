import json
import unittest
from unittest.mock import patch
import requests
from test_features import module
from llm import LLM
from model_routing import model_call_context
from test_model_fallback import response,BACKUP
import os

class StreamTests(unittest.TestCase):
    def make(self,parts,finish='stop',done=True):
        r=requests.Response();r.status_code=200;r.headers['Content-Type']='text/event-stream'
        lines=['data: '+json.dumps({'choices':[{'delta':{'content':text},'finish_reason':None}]}) for text in parts]
        if finish:lines.append('data: '+json.dumps({'choices':[{'delta':{},'finish_reason':finish}]}))
        if done:lines.append('data: [DONE]')
        r.iter_lines=lambda **kwargs:iter(line.encode() for line in lines)
        r.close=lambda:None
        return r

    def test_streamed_html_uses_separate_backup_and_progress(self):
        events=[]
        with patch.dict(os.environ,BACKUP),patch('llm.requests.post',side_effect=[response(429,code='1305'),self.make(['<!doctype html>','<html><body>原型</body></html>'])]) as post,model_call_context(events.append):
            result=LLM().chat('需求',stream=True,max_tokens=16000)
        self.assertTrue(result.endswith('</html>'))
        self.assertTrue(post.call_args.kwargs['stream']);self.assertTrue(post.call_args.kwargs['json']['stream'])
        self.assertEqual(post.call_args.kwargs['json']['max_tokens'],16000)
        self.assertIn('progress',[e['state'] for e in events]);self.assertIn('succeeded',[e['state'] for e in events])

    def test_partial_or_length_outputs_never_succeed(self):
        for finish in [None,'length']:
            with patch.dict(os.environ,{'MODEL_FALLBACK_ENABLED':'0'}),patch('llm.requests.post',return_value=self.make(['partial'],finish=finish)):
                with self.assertRaises(ValueError):LLM().chat('需求',stream=True)

    def test_cancel_checked_during_stream_not_only_after_full_response(self):
        def guard():
            guard.count+=1
            if guard.count>2:raise RuntimeError('cancelled')
        guard.count=0
        with patch.dict(os.environ,{'MODEL_FALLBACK_ENABLED':'0'}),patch('llm.requests.post',return_value=self.make(['a','b','c'])),model_call_context(None,guard):
            with self.assertRaisesRegex(RuntimeError,'cancelled'):LLM().chat('需求',stream=True)

    def test_wall_budget_checked_while_receiving(self):
        with patch('llm.time.monotonic',return_value=211):
            with self.assertRaises(requests.Timeout):LLM.read_stream(self.make(['a']),210,'备用模型','test')

    def test_progress_refreshes_watchdog_without_growing_call_history(self):
        from refinement_jobs import RefinementJobs
        from unittest.mock import Mock
        service=RefinementJobs(None,None);service.update=Mock()
        service.model_event({},'html',{'state':'progress','role':'备用模型','model':'test','characters':1000})
        values=service.update.call_args.kwargs
        self.assertIn('request_started_at',values);self.assertNotIn('model_attempts',values)
        self.assertIn('1000',values['message'])

    def test_checkpoint_disappearing_during_resume_does_not_break_status(self):
        from refinement_jobs import RefinementJobs
        from pathlib import Path
        from unittest.mock import Mock
        service=RefinementJobs(None,None);service.path=Mock(return_value=Path('/unused'))
        with patch.object(Path,'read_bytes',side_effect=FileNotFoundError()):
            self.assertEqual(service.completed({'id':'test','checkpoint_schema':1}),{'prd':False,'html':False,'workflow':False})
