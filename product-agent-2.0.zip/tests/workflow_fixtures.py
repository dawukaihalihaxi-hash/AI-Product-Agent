from pathlib import Path
from workflow_document import write_workflow

def sample_workflow(prd='# PRD'):
    return {'schema':'product-agent/workflow','version':1,'title':'测试业务流程','actors':['用户','系统'],'notes':[],
        'flows':[{'id':'main','title':'主业务流程','nodes':[
            {'id':'start','type':'start','actor':'用户','label':'开始','evidence':[]},
            {'id':'step','type':'process','actor':'用户','label':'执行当前需求','evidence':[{'source':'prd','quote':prd.splitlines()[0][:100]}]},
            {'id':'end','type':'end','actor':'系统','label':'结束','evidence':[]}],
            'edges':[{'source':'start','target':'step','label':''},{'source':'step','target':'end','label':''}]}]}

def generated_workflow(*,output_dir):
    directory=Path(output_dir)
    return write_workflow(sample_workflow((directory/'requirement.md').read_text()),directory)
