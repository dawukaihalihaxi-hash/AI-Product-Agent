import base64,copy,json,tempfile,unittest
from pathlib import Path
from unittest.mock import Mock
import test_features
from durable_store import DurableStore,DurabilityError

class DurableStoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.rows={}
        def api(method,url,**kwargs):
            if method=='POST':
                for row in kwargs['json']:self.rows[(row['kind'],row['record_id'])]=copy.deepcopy(row)
                return Mock(status_code=201)
            return Mock(status_code=200,json=lambda:list(self.rows.values()))
        self.store=DurableStore('https://example.supabase.co','private-test-key',request=api)
    def tearDown(self):self.tmp.cleanup()
    def task(self):
        rid='a'*32;folder=self.root/'original'/'.refinement-drafts'/rid;folder.mkdir(parents=True)
        (folder/'task.json').write_text(json.dumps({'id':rid,'state':'failed','owner':'private-owner'}));(folder/'requirement.md').write_text('原始PRD')
        (folder/'.prototype-modules'/'digest').mkdir(parents=True);(folder/'.prototype-modules'/'digest'/'p1.html').write_text('完成的模块')
        return rid,folder
    def test_cache_wipe_restores_task_and_modules_byte_exact(self):
        rid,folder=self.task();self.store.save('task',rid,folder,'private-owner')
        restored=self.root/'restored';restored.mkdir();self.store.restore(restored)
        for name in ['task.json','requirement.md','.prototype-modules/digest/p1.html']:
            self.assertEqual((folder/name).read_bytes(),(restored/'.refinement-drafts'/rid/name).read_bytes())
        self.assertNotEqual(self.rows[('task',rid)]['owner_hash'],'private-owner')
    def test_deleted_tasks_are_not_resurrected(self):
        rid,folder=self.task();self.store.save('task',rid,folder,'owner');self.store.save('task',rid,folder,'owner',deleted=True)
        restored=self.root/'restored';restored.mkdir();self.store.restore(restored)
        self.assertFalse((restored/'.refinement-drafts'/rid).exists())
    def test_private_files_and_path_tampering_never_restore(self):
        rid,folder=self.task();(folder/'.session-secret').write_text('do-not-copy');self.store.save('task',rid,folder,'owner')
        row=self.rows[('task',rid)];self.assertNotIn('.session-secret',row['payload']['files'])
        row['payload']['files']['../../outside.txt']={'data':'','sha256':''}
        with self.assertRaises(DurabilityError):self.store.restore_record(self.root/'restored',row)
    def test_corrupt_snapshot_is_rejected_before_any_write(self):
        rid,folder=self.task();self.store.save('task',rid,folder,'owner')
        row=self.rows[('task',rid)];row['payload']['files']['requirement.md']['sha256']='wrong'
        target=self.root/'restored';target.mkdir()
        with self.assertRaises(DurabilityError):self.store.restore_record(target,row)
        self.assertFalse((target/'.refinement-drafts'/rid).exists())
    def test_unavailable_database_is_not_reported_as_saved(self):
        rid,folder=self.task();store=DurableStore('https://example.supabase.co','key',request=Mock(return_value=Mock(status_code=403)))
        with self.assertRaisesRegex(DurabilityError,'HTTP 403'):store.save('task',rid,folder,'owner')
        self.assertTrue((folder/'requirement.md').exists())
    def test_chat_snapshot_does_not_include_other_conversations(self):
        folder=self.root/'chats';folder.mkdir();rid='b'*32;path=folder/(rid+'.json');chat={'id':rid,'owner':'owner'};path.write_text(json.dumps(chat));(folder/('c'*32+'.json')).write_text('private other')
        self.store.save_chat(path,chat);files=self.rows[('chat',rid)]['payload']['files'];self.assertEqual(list(files),[rid+'.json'])
