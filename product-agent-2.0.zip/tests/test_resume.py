import json
import threading
import time
from pathlib import Path
from unittest.mock import patch
import requests
from test_refinement import RefinementTests, RequirementAgent, HtmlAgent, module
from refinement_jobs import RefinementJobs
from agents.workflow_agent import WorkflowAgent
from workflow_fixtures import generated_workflow

class ResumeTests(RefinementTests):
    # Keep only the new cases here; the base cases run in their own module.
    def fail_html(self, create=False):
        with patch.object(RequirementAgent,'run',side_effect=self.generated_prd), patch.object(HtmlAgent,'run',side_effect=requests.ConnectionError()):
            if create:
                response=self.client.post('/create',data={'csrf_token':self.token,'requirement':'新的预约产品'},headers={'Accept':'application/json'})
                task=response.json['task_url'].split('/')[-1]
            else:task=self.start()
            self.assertEqual(self.wait(task)['state'],'failed')
        return task

    def resume_post(self, task):
        return self.client.post(f'/refinement-tasks/{task}/resume',data={'csrf_token':self.token})

    def test_partial_home_preview_and_resume_skips_prd(self):
        task=self.fail_html();service=module.refinement_jobs
        folder=service.path(task);prd=(folder/'requirement.md').read_bytes()
        home=self.client.get('/').get_data(as_text=True)
        self.assertIn('未完成与待确认的任务（1）',home);self.assertNotIn(task,home)
        history=self.client.get('/unfinished-tasks').get_data(as_text=True)
        self.assertIn(task,history);self.assertIn('PRD：已保留',history)
        self.assertLess(history.index('<h2>'),history.index('class="description"'))
        self.assertEqual(self.client.get(f'/refinement-tasks/{task}/prd').status_code,200)
        with self.client.get(f'/refinement-tasks/{task}/prd?download=1') as response:
            self.assertIn('attachment',response.headers['Content-Disposition'])
        self.assertEqual(self.client.get(f'/refinement-tasks/{task}/preview').status_code,404)
        with patch.object(RequirementAgent,'run') as prd_run, patch.object(HtmlAgent,'run',side_effect=self.generated_html) as html_run:
            self.assertEqual(self.resume_post(task).status_code,303)
            job=self.wait(task)
            self.assertEqual(job['state'],'ready');prd_run.assert_not_called();html_run.assert_called_once()
        self.assertEqual(prd,(folder/'requirement.md').read_bytes())
        self.assertEqual(job['resume_count'],1);self.assertEqual(len(job['attempts']),1)
        self.assertEqual(len(self.manager.list_projects()),1)

    def test_initial_partial_persists_and_finishes_as_one_project(self):
        task=self.fail_html(create=True)
        self.assertIn(task,self.client.get('/unfinished-tasks').get_data(as_text=True))
        with patch.object(RequirementAgent,'run') as prd,patch.object(HtmlAgent,'run',side_effect=self.generated_html):
            self.resume_post(task);job=self.wait(task);prd.assert_not_called()
        self.assertEqual(job['state'],'saved');self.assertEqual(len(self.manager.list_projects()),2)
        self.assertNotIn(task,self.client.get('/').get_data(as_text=True))

    def test_workflow_failure_resumes_only_workflow(self):
        with patch.object(RequirementAgent,'run',side_effect=self.generated_prd),patch.object(HtmlAgent,'run',side_effect=self.generated_html),patch.object(WorkflowAgent,'run',side_effect=ValueError()):
            task=self.start();job=self.wait(task)
        self.assertEqual(job['completed'],{'prd':True,'html':True,'workflow':False})
        with patch.object(RequirementAgent,'run') as prd,patch.object(HtmlAgent,'run') as html,patch.object(WorkflowAgent,'run',side_effect=generated_workflow) as workflow:
            self.resume_post(task);self.assertEqual(self.wait(task)['state'],'ready')
            prd.assert_not_called();html.assert_not_called();workflow.assert_called_once()

    def test_restart_and_frozen_source(self):
        task=self.fail_html();service=module.refinement_jobs
        frozen=json.loads((service.path(task)/'context.json').read_text())['previous_html']
        self.manager.get_html_path(self.id).write_text('<html>changed</html>')
        restored=RefinementJobs(self.manager,module.app.logger)
        with patch.object(module,'refinement_jobs',restored),patch.object(RequirementAgent,'run') as prd,patch.object(HtmlAgent,'run',side_effect=self.generated_html) as html:
            self.resume_post(task);self.assertEqual(self.wait(task)['state'],'ready')
            self.assertEqual(html.call_args.kwargs['previous_html'],frozen);prd.assert_not_called()
            self.assertEqual(self.client.post(f'/refinement-tasks/{task}/save',data={'csrf_token':self.token,'mode':'replace','confirmed':'yes'}).status_code,409)

    def test_legacy_adopts_prd_and_ownership_csrf(self):
        task=self.fail_html();service=module.refinement_jobs
        job=service.read(task);job.pop('checkpoint_schema');job.pop('checkpoints');service.write(job)
        (service.path(task)/'context.json').unlink()
        self.assertEqual(self.client.post(f'/refinement-tasks/{task}/resume').status_code,403)
        stranger=module.app.test_client();self.assertEqual(stranger.get(f'/refinement-tasks/{task}/prd').status_code,404)
        self.assertEqual(stranger.post(f'/refinement-tasks/{task}/resume').status_code,404)
        with patch.object(RequirementAgent,'run') as prd,patch.object(HtmlAgent,'run',side_effect=self.generated_html):
            self.resume_post(task);self.assertEqual(self.wait(task)['state'],'ready');prd.assert_not_called()

    def test_repeated_resume_and_identical_submission_use_one_task(self):
        task=self.fail_html();entered=threading.Event();release=threading.Event()
        def html(**kwargs):entered.set();release.wait(2);return self.generated_html(**kwargs)
        with patch.object(RequirementAgent,'run') as prd,patch.object(HtmlAgent,'run',side_effect=html) as run:
            try:
                self.resume_post(task);self.assertTrue(entered.wait(1))
                self.assertEqual(self.resume_post(task).status_code,303)
                self.assertEqual(self.start(),task)
            finally:release.set()
            self.assertEqual(self.wait(task)['state'],'ready');run.assert_called_once();prd.assert_not_called()

    def test_corrupt_checkpoint_regenerates_from_first_invalid_stage(self):
        task=self.fail_html();folder=module.refinement_jobs.path(task)
        (folder/'requirement.md').write_text('corrupt')
        with patch.object(RequirementAgent,'run',side_effect=self.generated_prd) as prd,patch.object(HtmlAgent,'run',side_effect=self.generated_html):
            self.resume_post(task);self.assertEqual(self.wait(task)['state'],'ready');prd.assert_called_once()
        self.assertTrue(list(folder.glob('.partial-*-requirement.md')))

    def test_restart_of_running_task_keeps_checkpoint(self):
        task=self.fail_html();service=module.refinement_jobs
        job=service.read(task);job.update(state='running',request_started_at=None);service.write(job)
        restored=RefinementJobs(self.manager,module.app.logger)
        with patch.object(module,'refinement_jobs',restored),patch.object(RequirementAgent,'run') as prd,patch.object(HtmlAgent,'run',side_effect=self.generated_html):
            history=self.client.get('/unfinished-tasks').get_data(as_text=True)
            self.assertIn('服务重启',history);self.assertIn(task,history)
            self.resume_post(task);self.assertEqual(self.wait(task)['state'],'ready');prd.assert_not_called()

    def test_stopped_inflight_request_must_exit_before_resume(self):
        entered=threading.Event();release=threading.Event()
        def html(**kwargs):entered.set();release.wait(2);return self.generated_html(**kwargs)
        with patch.object(RequirementAgent,'run',side_effect=self.generated_prd),patch.object(HtmlAgent,'run',side_effect=html):
            task=self.start();self.assertTrue(entered.wait(1));thread=module.refinement_jobs.active[task]
            try:
                self.client.post(f'/refinement-tasks/{task}/cancel',headers={'X-CSRF-Token':self.token})
                self.assertEqual(self.resume_post(task).status_code,409)
            finally:release.set();thread.join(2)
        with patch.object(RequirementAgent,'run') as prd,patch.object(HtmlAgent,'run',side_effect=self.generated_html):
            self.resume_post(task);self.assertEqual(self.wait(task)['state'],'ready');prd.assert_not_called()

    def test_unverified_prd_is_not_reused_and_pause_is_excluded(self):
        def broken(requirement,*,output_dir):
            (Path(output_dir)/'requirement.md').write_text('partial')
            raise requests.ConnectionError()
        with patch.object(RequirementAgent,'run',side_effect=broken):
            task=self.start();self.assertEqual(self.wait(task)['state'],'failed')
        service=module.refinement_jobs;job=service.read(task)
        job['finished_at']=time.time()-3600;service.write(job)
        with patch.object(RequirementAgent,'run',side_effect=self.generated_prd) as prd,patch.object(HtmlAgent,'run',side_effect=self.generated_html):
            self.resume_post(task);result=self.wait(task);prd.assert_called_once()
        self.assertEqual(result['state'],'ready');self.assertLess(result['elapsed_seconds'],30)
        self.assertEqual(self.client.get(f'/refinement-tasks/{task}/workflow-image').status_code,200)

# Avoid running inherited test methods twice.
for name in list(RefinementTests.__dict__):
    if name.startswith('test_') and name not in ResumeTests.__dict__:
        setattr(ResumeTests,name,None)

del RefinementTests
