"""Loopback-only UI for explicitly testing and enabling the selected free backup."""
import json
import os
import tempfile
from pathlib import Path
from threading import RLock
import requests

SETTINGS_FILE = Path(__file__).with_name('.model-fallback.json')
URL = 'https://api.siliconflow.cn/v1/chat/completions'
MODEL = 'XingChenAGI/Xing4.0-29B'
_lock = RLock()


def read_settings():
    with _lock:
        try:
            return json.loads(SETTINGS_FILE.read_text(encoding='utf-8'))
        except FileNotFoundError:
            return {}


def save_settings(settings):
    with _lock:
        descriptor, name = tempfile.mkstemp(prefix='.model-fallback-', suffix='.tmp', dir=SETTINGS_FILE.parent)
        try:
            with os.fdopen(descriptor, 'w', encoding='utf-8') as file:
                json.dump(settings, file, ensure_ascii=False)
            os.replace(name, SETTINGS_FILE)
        finally:
            if os.path.exists(name):
                os.unlink(name)


def test_key(key):
    try:
        response = requests.post(URL, headers={'Authorization':'Bearer '+key, 'Content-Type':'application/json'},
            json={'model':MODEL, 'messages':[{'role':'user','content':'只回复 OK，不要解释。'}], 'max_tokens':512, 'temperature':0.2}, timeout=(10,30))
        if not response.ok:
            code = None
            try:
                value = response.json().get('error',{}).get('code')
                if isinstance(value,(int,str)) and str(value).isdigit(): code = str(value)[:16]
            except (ValueError,TypeError,AttributeError): pass
            reasons={401:'密钥未通过认证',403:'账户或模型权限不足，请查看硅基流动账户状态',429:'备用服务当前限流或额度受限',400:'模型调用参数未被接受',404:'模型或接口不存在'}
            reason = reasons.get(response.status_code,'备用服务暂时不可用')
            raise ValueError(reason+f'（HTTP {response.status_code}'+(f'，错误码 {code}' if code else '')+'）；未启用新配置。')
        data=response.json()
        choice=data['choices'][0];content=choice['message']['content']
        if not isinstance(content,str) or not content.strip() or choice.get('finish_reason')=='length':
            raise ValueError('接口已响应，但未返回完整测试文本；未启用新配置。')
    except requests.Timeout:
        raise ValueError('连接备用服务超时，原配置保留，请稍后重试。') from None
    except requests.RequestException:
        raise ValueError('无法连接备用服务，原配置保留，请检查网络。') from None
    except (KeyError,IndexError,TypeError):
        raise ValueError('备用服务响应格式异常，未启用新配置。') from None
