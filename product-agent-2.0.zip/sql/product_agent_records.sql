-- Server-side only. No anonymous/authenticated policies or public browser access.
create table if not exists public.product_agent_records (
 kind text not null check (kind in ('task','project','chat','archive')),
 record_id text not null, owner_hash text, payload jsonb not null,
 revision bigint not null default 1, updated_at timestamptz not null default now(),
 primary key(kind,record_id), check (octet_length(payload::text)<=12000000)
);
alter table public.product_agent_records enable row level security;
revoke all on public.product_agent_records from public,anon,authenticated;
grant select,insert,update on public.product_agent_records to service_role;
create index if not exists product_agent_records_owner on public.product_agent_records(owner_hash,kind);
