"""Validated workflow data, deterministic SVG/draw.io rendering and version manifests."""
import hashlib
import json
import re
import textwrap
from collections import deque
from html.parser import HTMLParser
from pathlib import Path
from xml.etree import ElementTree as ET

SCHEMA = 'product-agent/workflow'
WORKFLOW_FILES = ('workflow.json', 'workflow.drawio', 'workflow.svg', 'bundle_manifest.json')
BUNDLE_FILES = ('requirement.md', 'prototype.html') + WORKFLOW_FILES

class VisibleText(HTMLParser):
    def __init__(self):
        super().__init__(); self.skip=0; self.parts=[]
    def handle_starttag(self, tag, attrs):
        if tag in ('script','style'): self.skip+=1
    def handle_endtag(self, tag):
        if tag in ('script','style') and self.skip: self.skip-=1
    def handle_data(self, data):
        if not self.skip and data.strip(): self.parts.append(data.strip())

def prototype_text(html):
    parser=VisibleText(); parser.feed(html)
    return '\n'.join(parser.parts)

def digest(prd, html):
    return hashlib.sha256((prd+'\0'+html).encode()).hexdigest()

def compact(text):
    return re.sub(r'\s+', '', text)

def bounded(value, name, limit=100):
    if not isinstance(value,str) or not value.strip() or len(value)>limit:
        raise ValueError(name+'为空或过长')
    return value.strip()

def reference_notes(value):
    """Advisory text is stored separately from the executable graph contract.

    Preserve non-empty text in full; do not let formatting or arbitrary note
    lengths invalidate otherwise valid flows. Legacy structured notes remain
    readable as text rather than being silently discarded.
    """
    values=value if isinstance(value,list) else ([] if value is None else [value])
    result=[]
    for item in values:
        if item is None:continue
        text=item.strip() if isinstance(item,str) else json.dumps(item,ensure_ascii=False)
        if text:result.append(text)
    return result

def validate_workflow(data, prd, html):
    if not isinstance(data,dict) or data.get('schema')!=SCHEMA or data.get('version')!=1:
        raise ValueError('业务流程数据格式无效')
    bounded(data.get('title'),'流程标题')
    actors=data.get('actors')
    if not isinstance(actors,list) or not 1<=len(actors)<=8 or len(set(map(str,actors)))!=len(actors):
        raise ValueError('流程角色需为 1–8 个且不能重复')
    for actor in actors: bounded(actor,'角色',30)
    flows=data.get('flows')
    if not isinstance(flows,list) or not 1<=len(flows)<=8: raise ValueError('业务流程需为 1–8 个')
    # Optional reference notes are not a prerequisite for graph validity.
    sources={'prd':compact(prd),'prototype':compact(prototype_text(html))}
    used_flows=set(); total=0
    for flow in flows:
        if not isinstance(flow,dict): raise ValueError('流程格式无效')
        fid=bounded(flow.get('id'),'流程编号',60)
        if fid in used_flows: raise ValueError('流程编号重复')
        used_flows.add(fid); bounded(flow.get('title'),'业务流程标题')
        nodes=flow.get('nodes'); edges=flow.get('edges')
        if not isinstance(nodes,list) or not 2<=len(nodes)<=40 or not isinstance(edges,list) or not 1<=len(edges)<=100:
            raise ValueError('节点或连线数量无效')
        total+=len(nodes)
        if total>120: raise ValueError('全部流程超过 120 个节点，请拆分需求')
        ids={}; outgoing={}; incoming={}
        for node in nodes:
            if not isinstance(node,dict): raise ValueError('流程节点格式无效')
            nid=bounded(node.get('id'),'节点编号',60)
            if nid in ids: raise ValueError('节点编号重复')
            ids[nid]=node; outgoing[nid]=[]; incoming[nid]=[]
            bounded(node.get('label'),'节点文字',100)
            if node.get('type') not in ('start','process','decision','end') or node.get('actor') not in actors:
                raise ValueError('节点 '+str(node.get('id','?'))+' 类型或角色无效；类型只允许 start/process/decision/end，角色必须属于：'+'、'.join(actors))
            if 'pending' in node and not isinstance(node['pending'],bool): raise ValueError('待确认状态无效')
            evidence=node.get('evidence',[])
            if not isinstance(evidence,list): raise ValueError('节点依据格式无效')
            if node['type'] in ('process','decision') and not evidence and not node.get('pending'):
                raise ValueError('缺少依据的业务步骤必须标为待确认')
            for item in evidence:
                if not isinstance(item,dict) or not isinstance(item.get('source'),str) or item.get('source') not in sources: raise ValueError('节点依据来源无效')
                quote=bounded(item.get('quote'),'引用内容',400)
                if compact(quote) not in sources[item['source']]: raise ValueError('节点引用在当前 PRD 或原型中不存在')
        seen_edges=set()
        for edge in edges:
            if not isinstance(edge,dict) or not isinstance(edge.get('source'),str) or not isinstance(edge.get('target'),str) or edge.get('source') not in ids or edge.get('target') not in ids:
                raise ValueError('连线引用了不存在的节点')
            label=edge.get('label','')
            if not isinstance(label,str) or len(label)>80: raise ValueError('分支文字无效')
            key=(edge['source'],edge['target'],label)
            if key in seen_edges: raise ValueError('重复连线')
            seen_edges.add(key); outgoing[edge['source']].append(edge['target']); incoming[edge['target']].append(edge['source'])
        starts=[n['id'] for n in nodes if n['type']=='start']; ends=[n['id'] for n in nodes if n['type']=='end']
        if not starts or not ends: raise ValueError('流程缺少开始或结束节点')
        def reachable(seeds, links):
            seen=set(seeds); queue=deque(seeds)
            while queue:
                for target in links[queue.popleft()]:
                    if target not in seen: seen.add(target); queue.append(target)
            return seen
        if reachable(starts,outgoing)!=set(ids) or reachable(ends,incoming)!=set(ids):
            raise ValueError('存在无法到达或无法结束的孤立流程')
        for node in nodes:
            nid=node['id']
            if node['type']=='start' and incoming[nid]: raise ValueError('开始节点不能有入线')
            if node['type']=='end' and outgoing[nid]: raise ValueError('结束节点不能有出线')
            if node['type']=='decision':
                branches=[edge for edge in edges if edge['source']==nid]
                if len(branches)<2 or any(not edge.get('label','').strip() for edge in branches):
                    raise ValueError('判断节点需至少两个带说明的分支')
    return data

def layout(flow, actors):
    # Separate lanes by role; preserve model's ordered business steps, not arbitrary HTML position.
    boxes={}; lane_width=300; cursor=100
    for node in flow['nodes']:
        x=30+actors.index(node['actor'])*lane_width+35
        count=len(lines(node['label'],13 if node['type']=='decision' else 18))
        height=max(90 if node['type']=='decision' else 78, count*18*(2 if node['type']=='decision' else 1)+24)
        boxes[node['id']]=(x,cursor,230,height)
        cursor+=height+60
    return boxes,len(actors)*lane_width+60,cursor+60

def lines(value, width=16):
    return textwrap.wrap(value,width=width,break_long_words=True,break_on_hyphens=False) or ['']

def workflow_svg(data, flow_id=None):
    ns='http://www.w3.org/2000/svg'; ET.register_namespace('',ns)
    flows=[f for f in data['flows'] if flow_id is None or f['id']==flow_id]
    if not flows: raise ValueError('流程不存在')
    rendered=[(f,*layout(f,data['actors'])) for f in flows]
    width=max(item[2] for item in rendered); height=sum(item[3]+40 for item in rendered)
    root=ET.Element('{'+ns+'}svg',{'viewBox':f'0 0 {width} {height}','width':str(width),'height':str(height),'role':'img'})
    def el(parent,tag,attrs=None,text=None):
        n=ET.SubElement(parent,'{'+ns+'}'+tag,attrs or {})
        if text is not None:n.text=str(text)
        return n
    el(root,'title',text=data['title'])
    defs=el(root,'defs'); marker=el(defs,'marker',{'id':'arrow','viewBox':'0 0 10 10','refX':'9','refY':'5','markerWidth':'7','markerHeight':'7','orient':'auto-start-reverse'})
    el(marker,'path',{'d':'M 0 0 L 10 5 L 0 10 z','fill':'#64748b'})
    offset=0
    for flow,boxes,w,h in rendered:
        group=el(root,'g',{'transform':f'translate(0 {offset})'})
        el(group,'rect',{'width':str(w),'height':str(h),'fill':'white'})
        el(group,'text',{'x':'30','y':'28','font-size':'20','font-family':'sans-serif','fill':'#172554'},flow['title'])
        for i,actor in enumerate(data['actors']):
            el(group,'rect',{'x':str(30+i*300),'y':'48','width':'300','height':str(h-60),'fill':'#f8fafc' if i%2==0 else '#fff','stroke':'#e2e8f0'})
            el(group,'text',{'x':str(180+i*300),'y':'77','text-anchor':'middle','font-size':'16','font-family':'sans-serif','fill':'#475569'},actor)
        for index,edge in enumerate(flow['edges']):
            sx,sy,sw,sh=boxes[edge['source']];tx,ty,tw,th=boxes[edge['target']]
            if ty>sy:
                x1,y1=sx+sw/2,sy+sh;x2,y2=tx+tw/2,ty;mid=(y1+y2)/2
                points=f'{x1},{y1} {x1},{mid} {x2},{mid} {x2},{y2}'
                lx,ly=(x1+x2)/2+8,mid-7
            else:
                x1,y1=sx+sw,sy+sh/2;x2,y2=tx+tw,ty+th/2;bend=min(w-12,max(x1,x2)+20+(index%3)*6)
                points=f'{x1},{y1} {bend},{y1} {bend},{y2} {x2},{y2}';lx,ly=bend-8,(y1+y2)/2
            el(group,'polyline',{'points':points,'fill':'none','stroke':'#64748b','stroke-width':'1.6','marker-end':'url(#arrow)'})
            if edge.get('label'):
                el(group,'text',{'x':str(lx),'y':str(ly),'font-size':'12','font-family':'sans-serif','fill':'#475569','paint-order':'stroke','stroke':'white','stroke-width':'4'},edge['label'])
        for node in flow['nodes']:
            x,y,nw,nh=boxes[node['id']]; pending=node.get('pending',False)
            attrs={'fill':'#fffbeb' if pending else '#eff6ff','stroke':'#d97706' if pending else '#2563eb','stroke-width':'1.5'}
            if node['type']=='decision':el(group,'polygon',dict(attrs,points=f'{x+nw/2},{y} {x+nw},{y+nh/2} {x+nw/2},{y+nh} {x},{y+nh/2}'))
            else:el(group,'rect',dict(attrs,x=str(x),y=str(y),width=str(nw),height=str(nh),rx='38' if node['type'] in ('start','end') else '9'))
            parts=lines(node['label'],13 if node['type']=='decision' else 18)
            text=el(group,'text',{'x':str(x+nw/2),'y':str(y+nh/2-(len(parts)-1)*9+5),'text-anchor':'middle','font-size':'14','font-family':'sans-serif','fill':'#1f2937'})
            for i,part in enumerate(parts):el(text,'tspan',{'x':str(x+nw/2),'dy':'0' if i==0 else '18'},part)
            if pending:el(group,'text',{'x':str(x+nw-4),'y':str(y-6),'text-anchor':'end','font-size':'11','fill':'#92400e'},'待确认')
        offset+=h+40
    return ET.tostring(root,encoding='unicode',xml_declaration=True)

def workflow_drawio(data):
    root=ET.Element('mxfile',{'host':'Product Agent','type':'device','version':'1.0'})
    for flow in data['flows']:
        boxes,w,h=layout(flow,data['actors'])
        diagram=ET.SubElement(root,'diagram',{'id':flow['id'],'name':flow['title']})
        graph=ET.SubElement(diagram,'mxGraphModel',{'grid':'1','gridSize':'10','page':'1','pageWidth':str(w),'pageHeight':str(h)})
        cells=ET.SubElement(graph,'root'); ET.SubElement(cells,'mxCell',{'id':'0'}); ET.SubElement(cells,'mxCell',{'id':'1','parent':'0'})
        for i,actor in enumerate(data['actors']):
            cell=ET.SubElement(cells,'mxCell',{'id':'lane-'+str(i),'value':actor,'vertex':'1','parent':'1','style':'swimlane;horizontal=1;startSize=36;fillColor=#f8fafc;strokeColor=#e2e8f0;collapsible=0;html=0;'})
            ET.SubElement(cell,'mxGeometry',{'x':str(30+i*300),'y':'48','width':'300','height':str(h-60),'as':'geometry'})
        for node in flow['nodes']:
            x,y,nw,nh=boxes[node['id']]
            shape='rhombus;' if node['type']=='decision' else ('ellipse;' if node['type'] in ('start','end') else 'rounded=1;')
            cell=ET.SubElement(cells,'mxCell',{'id':'n-'+node['id'],'value':node['label']+('（待确认）' if node.get('pending') else ''),'vertex':'1','parent':'lane-'+str(data['actors'].index(node['actor'])),'style':shape+'whiteSpace=wrap;html=0;fillColor='+('#fffbeb' if node.get('pending') else '#eff6ff')+';strokeColor=#2563eb;fontSize=14;'} )
            ET.SubElement(cell,'mxGeometry',{'x':'35','y':str(y-48),'width':str(nw),'height':str(nh),'as':'geometry'})
        for index,edge in enumerate(flow['edges']):
            cell=ET.SubElement(cells,'mxCell',{'id':'e-'+str(index),'value':edge.get('label',''),'edge':'1','parent':'1','source':'n-'+edge['source'],'target':'n-'+edge['target'],'style':'edgeStyle=orthogonalEdgeStyle;rounded=0;endArrow=block;html=0;fontSize=12;'})
            ET.SubElement(cell,'mxGeometry',{'relative':'1','as':'geometry'})
    return ET.tostring(root,encoding='unicode',xml_declaration=True)

def write_workflow(data, directory):
    directory=Path(directory); prd=(directory/'requirement.md').read_text(); html=(directory/'prototype.html').read_text()
    validate_workflow(data,prd,html)
    data=dict(data,notes=reference_notes(data.get('notes')),source_digest=digest(prd,html))
    (directory/'workflow.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    (directory/'workflow.svg').write_text(workflow_svg(data),encoding='utf-8')
    (directory/'workflow.drawio').write_text(workflow_drawio(data),encoding='utf-8')
    manifest={'schema':'product-agent/bundle','version':1,'source_digest':data['source_digest'],'files':{name:hashlib.sha256((directory/name).read_bytes()).hexdigest() for name in BUNDLE_FILES if name!='bundle_manifest.json'}}
    if (directory/'scope.json').is_file():manifest['files']['scope.json']=hashlib.sha256((directory/'scope.json').read_bytes()).hexdigest()
    (directory/'bundle_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    return data

def validate_bundle(directory):
    directory=Path(directory)
    for name in BUNDLE_FILES:
        if not (directory/name).is_file(): raise ValueError('配套内容不完整：'+name)
    prd=(directory/'requirement.md').read_text(); html=(directory/'prototype.html').read_text()
    data=json.loads((directory/'workflow.json').read_text());validate_workflow(data,prd,html)
    manifest=json.loads((directory/'bundle_manifest.json').read_text())
    if data.get('source_digest')!=digest(prd,html) or manifest.get('source_digest')!=data['source_digest']:
        raise ValueError('流程图与当前 PRD、原型不属于同一版本')
    for name in BUNDLE_FILES:
        if name=='bundle_manifest.json':continue
        if manifest.get('files',{}).get(name)!=hashlib.sha256((directory/name).read_bytes()).hexdigest():
            raise ValueError('配套文件校验失败：'+name)
    # Rendered files must be derived from the same validated graph.
    if (directory/'workflow.svg').read_text()!=workflow_svg(data) or (directory/'workflow.drawio').read_text()!=workflow_drawio(data):
        raise ValueError('流程图导出文件与流程数据不一致')
    if 'scope.json' in manifest.get('files',{}) or (directory/'scope.json').is_file():
        if not (directory/'scope.json').is_file() or manifest['files'].get('scope.json')!=hashlib.sha256((directory/'scope.json').read_bytes()).hexdigest():raise ValueError('锁定范围与当前版本不一致')
    return dict(data,notes=reference_notes(data.get('notes')))
