import os

API_KEY = os.environ.get("MODEL_API_KEY", "")
BASE_URL = os.environ.get("MODEL_BASE_URL", 'https://open.bigmodel.cn/api/paas/v4/chat/completions')
MODEL = os.environ.get("MODEL_NAME", 'glm-4.7-flash')
