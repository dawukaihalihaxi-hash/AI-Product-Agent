from pathlib import Path

from flask import Flask, abort, render_template, request, send_file, jsonify, session, redirect, url_for, g
import secrets
from datetime import timedelta
import os

from agents.html_agent import HtmlAgent
from agents.requirement_agent import RequirementAgent
from project.project_manager import ProjectManager


app = Flask(__name__)
def session_signing_key():
    configured = os.environ.get("PRODUCT_AGENT_SECRET_KEY")
    if configured:
        return configured
    key_file = Path(__file__).resolve().parent / ".session-secret"
    try:
        descriptor = os.open(key_file, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        return key_file.read_text(encoding="utf-8").strip()
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        value = secrets.token_hex(32)
        stream.write(value)
    return value

app.secret_key = session_signing_key()
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  PERMANENT_SESSION_LIFETIME=timedelta(days=30))

@app.before_request
def retain_task_session():
    # Keep the same owner after a normal browser restart; never share owners.
    if not session.permanent:
        session.permanent=True


@app.before_request
def protect_bundle_reads():
    # Avoid exposing a partially replaced bundle during a concurrent cover operation.
    if request.endpoint in ('edit','project_prd','project_preview','project_workflow',
                            'project_workflow_image','project_workflow_export'):
        from project.project_manager import _apply_lock
        _apply_lock.acquire()
        g.bundle_read_lock = True

@app.teardown_request
def release_bundle_reads(error=None):
    if getattr(g, 'bundle_read_lock', False):
        from project.project_manager import _apply_lock
        g.bundle_read_lock = False
        _apply_lock.release()


@app.context_processor
def csrf_context():
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_urlsafe(32)
    return {"csrf_token": session["csrf_token"]}

@app.route("/projects/<project_id>/delete", methods=["POST"])
def delete_project(project_id):
    token = request.headers.get("X-CSRF-Token", "")
    if not token or not secrets.compare_digest(token, session.get("csrf_token", "")):
        return jsonify(error="页面已过期，请刷新后重试"), 403
    if (request.get_json(silent=True) or {}).get("confirmed") is not True:
        return jsonify(error="请先确认删除"), 400
    try:
        deleted = project_manager.delete_project(project_id)
    except ValueError:
        abort(404)
    except OSError:
        app.logger.exception("删除项目失败")
        return jsonify(error="删除失败，请刷新并重试"), 500
    return jsonify(deleted=deleted, project_id=project_id)

@app.route("/projects/<project_id>/rename", methods=["POST"])
def rename_project(project_id):
    token = request.headers.get("X-CSRF-Token", "")
    if not token or not secrets.compare_digest(token, session.get("csrf_token", "")):
        return jsonify(error="页面已过期，请刷新后重试"), 403
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return jsonify(error="请填写项目名称"), 400
    try:
        # Resolve the ID before validating the name so missing projects remain a 404.
        if project_manager.get_project(project_id) is None:
            return jsonify(error="该项目已不存在，请刷新列表"), 404
        project = project_manager.rename_project(project_id, payload.get("name"))
        if project is None:
            return jsonify(error="该项目已不存在，请刷新列表"), 404
    except ValueError as error:
        try:
            project_manager.project_path(project_id)
        except ValueError:
            return jsonify(error="无效项目编号"), 404
        return jsonify(error=str(error)), 400
    except OSError:
        app.logger.exception("项目重命名失败：%s", project_id)
        return jsonify(error="保存失败，请稍后重试"), 500
    return jsonify(project=project)


@app.after_request
def prevent_stale_history(response):
    if request.path in ("/", "/edit", "/generation-history", "/unfinished-tasks") or request.path.startswith(("/projects/", "/refinement-tasks/")):
        response.headers["Cache-Control"] = "no-store"
    return response


BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "output"

project_manager = ProjectManager()


@app.route("/")
def index():

    from project.project_manager import _apply_lock
    with _apply_lock:
        projects = project_manager.list_projects()
        if getattr(g,'demo_guest',False):
            projects=[project for project in projects if project.get('owner')==session.get('refinement_owner')]
        for project in projects:
            project['workflow_ready'] = project_manager.workflow_status(project['id'])[0] == 'ready'
    refinement_jobs.manager = project_manager
    owner = session.get('refinement_owner')
    pending = refinement_jobs.history(owner, '*', limit=None, unfinished=True) if owner else []
    return render_template("index.html", projects=projects, pending=pending)


@app.route('/settings/backup-model', methods=['GET', 'POST'])
def backup_model_settings():
    from urllib.parse import urlsplit
    import local_model_settings as settings
    # Never expose a shared cloud administrator's key through the public demo.
    if os.environ.get('RENDER') or request.remote_addr not in ('127.0.0.1','::1') or urlsplit(request.host_url).hostname not in ('127.0.0.1','localhost','::1'):
        abort(404)
    current = settings.read_settings()
    error = None
    if request.method == 'POST':
        token = request.form.get('csrf_token','')
        if not token or not secrets.compare_digest(token,session.get('csrf_token','')):
            return render_template('backup_model_settings.html', has_key=bool(current.get('MODEL_FALLBACK_API_KEY')), enabled=current.get('MODEL_FALLBACK_ENABLED')=='1', error='页面已过期，请刷新后重试。'), 403
        if 'MODEL_FALLBACK_ENABLED' in os.environ:
            error = '当前由启动环境变量控制备用模型。请先移除 MODEL_FALLBACK_ENABLED 环境变量后，再使用此页面配置。'
        elif request.form.get('action') == 'disable':
            current['MODEL_FALLBACK_ENABLED']='0';settings.save_settings(current)
            return redirect(url_for('backup_model_settings', disabled='1'),code=303)
        else:
            key=request.form.get('api_key','').strip() or current.get('MODEL_FALLBACK_API_KEY','')
            if not key or len(key)>512 or any(character.isspace() for character in key):
                error='请填写有效的硅基流动 API Key；无需填写模型页面网址。'
            else:
                try:
                    settings.test_key(key)
                    current={'MODEL_FALLBACK_ENABLED':'1','MODEL_FALLBACK_API_KEY':key,
                             'MODEL_FALLBACK_BASE_URL':settings.URL,'MODEL_FALLBACK_NAME':settings.MODEL,
                             'MODEL_FALLBACK_MAX_TOKENS':'30000','MODEL_FALLBACK_ALLOW_PAID':'0'}
                    settings.save_settings(current)
                    return redirect(url_for('backup_model_settings',success='1'),code=303)
                except ValueError as caught:
                    # test_key only exposes fixed messages and numeric error codes.
                    error=str(caught)
                except OSError:
                    error='保存本地配置失败，原配置保留。'
        return render_template('backup_model_settings.html',has_key=bool(current.get('MODEL_FALLBACK_API_KEY')),enabled=current.get('MODEL_FALLBACK_ENABLED')=='1',error=error),400
    return render_template('backup_model_settings.html',has_key=bool(current.get('MODEL_FALLBACK_API_KEY')),enabled=current.get('MODEL_FALLBACK_ENABLED')=='1',success=request.args.get('success')=='1',disabled=request.args.get('disabled')=='1')


@app.route("/create", methods=["POST"])
def create():
    requirement = request.form.get("requirement", "").strip()
    if request.form.get('conversation_id'):
        try:
            requirement_chats.manager = project_manager
            requirement = requirement_chats.confirmed_brief(request.form['conversation_id'], session.get('refinement_owner'), request.form.get('conversation_revision'), 'create')
        except FileNotFoundError:
            return jsonify(error='讨论记录不存在，请重新开始讨论。'), 409
        except ValueError as error:
            return jsonify(error=str(error)), 409
    if not requirement or len(requirement) > 20000:
        return jsonify(error="请填写 1–20000 字的需求内容。"), 400
    token = request.form.get('csrf_token', '')
    if not token or not secrets.compare_digest(token, session.get('csrf_token', '')):
        return jsonify(error="页面已过期，请刷新后重试；需求不会丢失。"), 403
    owner = session.setdefault('refinement_owner', secrets.token_urlsafe(32))
    refinement_jobs.manager = project_manager
    context = dict(project={'name':requirement.splitlines()[0][:30]}, raw_requirement=requirement, original_prd=None)
    try:
        job = refinement_jobs.start(context, '', owner, kind='create')
    except ValueError as error:
        return jsonify(error=str(error)), 409
    target = url_for('refinement_task_page', task_id=job['id'])
    if request.accept_mimetypes.best == 'application/json':
        return jsonify(task_url=target), 202
    return redirect(target, code=303)


@app.route('/projects/<project_id>/result')
def generated_project_result(project_id):
    context = refinement_context(project_id)
    return render_template('result.html', project=context['project'])


@app.route("/prd")
def prd():

    path = OUTPUT_DIR / "requirement.md"

    if not path.exists():

        return "暂无 PRD 文件", 404


    content = path.read_text(
        encoding="utf-8"
    )

    return render_template(
        "prd.html",
        content=content,
        project=None
    )


@app.route("/preview")
def preview():

    path = OUTPUT_DIR / "prototype.html"

    if not path.exists():

        return "暂无 HTML 原型", 404


    return send_file(
        path
    )


@app.route("/projects/<project_id>/prd")
def project_prd(project_id):

    project = project_manager.get_project(
        project_id
    )

    if not project:

        abort(404)


    content = project_manager.get_prd(
        project_id
    )

    if content is None:

        return "该项目暂无 PRD 文件", 404


    return render_template(
        "prd.html",
        content=content,
        project=project
    )


@app.route("/projects/<project_id>/preview")
def project_preview(project_id):

    project = project_manager.get_project(
        project_id
    )

    if not project:

        abort(404)


    html_path = project_manager.get_html_path(
        project_id
    )

    if html_path is None:

        return "该项目暂无 HTML 原型", 404


    return send_file(
        html_path
    )


def exportable_project(project_id):
    try:
        project = project_manager.get_project(project_id)
        html_path = project_manager.get_html_path(project_id)
    except ValueError:
        abort(404)
    if not project or html_path is None:
        abort(404)
    return project, html_path


@app.route("/projects/<project_id>/export")
def export_project(project_id):
    project, html_path = exportable_project(project_id)
    export_format = request.args.get("format", "figma")
    if export_format == "html":
        return send_file(html_path, as_attachment=True,
                         download_name=f"prototype-{project_id}.html")
    if export_format != "figma":
        return "不支持的导出格式", 400
    return render_template("figma_export.html", project=project)


@app.route("/projects/<project_id>/figma-source")
def figma_source(project_id):
    from flask import Response
    import re
    _, html_path = exportable_project(project_id)
    html = html_path.read_text(encoding="utf-8")
    collector = (BASE_DIR / "static" / "figma-capture.js").read_text(encoding="utf-8")
    # Insert before the final closing body tag; original prototype files stay untouched.
    interactions = (BASE_DIR / "static" / "figma-interactions.js").read_text(encoding="utf-8")
    injection = "<script>" + interactions + "\n" + collector + "</script>"
    endings = list(re.finditer(r"</body\s*>", html, re.IGNORECASE))
    offset = endings[-1].start() if endings else len(html)
    response = Response(html[:offset] + injection + html[offset:], mimetype="text/html")
    response.headers["Content-Security-Policy"] = (
        "sandbox allow-scripts; default-src 'none'; script-src 'unsafe-inline'; "
        "style-src 'unsafe-inline'; img-src data:; font-src data:; "
        "connect-src 'none'; form-action 'none'; base-uri 'none'; frame-src 'none'"
    )
    response.headers["Referrer-Policy"] = "no-referrer"
    return response


@app.route("/figma-plugin/download")
def figma_plugin_download():
    from io import BytesIO
    from zipfile import ZipFile, ZIP_DEFLATED
    archive = BytesIO()
    with ZipFile(archive, "w", ZIP_DEFLATED) as bundle:
        for name in ("manifest.json", "code.js", "ui.html", "README.md"):
            bundle.write(BASE_DIR / "figma-plugin" / name, name)
    archive.seek(0)
    return send_file(archive, mimetype="application/zip", as_attachment=True,
                     download_name="product-agent-figma-plugin.zip")


def refinement_context(project_id):
    try:
        project = project_manager.get_project(project_id)
        if project is None:
            abort(404)
        raw_requirement = project_manager.get_raw_requirement(project_id)
        content = project_manager.get_prd(project_id)
        html_path = project_manager.get_html_path(project_id)
    except ValueError:
        abort(404)
    return dict(project=project, raw_requirement=raw_requirement,
                original_prd=content, has_html=html_path is not None)


def workflow_response(directory, project, *, task_id=None):
    from workflow_document import validate_bundle
    data = validate_bundle(directory)
    if task_id:
        image_url = url_for('task_workflow_image', task_id=task_id)
        drawio_url = url_for('task_workflow_export', task_id=task_id, format='drawio')
        svg_url = url_for('task_workflow_export', task_id=task_id, format='svg')
    else:
        image_url = url_for('project_workflow_image', project_id=project['id'])
        drawio_url = url_for('project_workflow_export', project_id=project['id'], format='drawio')
        svg_url = url_for('project_workflow_export', project_id=project['id'], format='svg')
    return render_template('workflow.html', project=project, data=data, state='ready',
                           image_url=image_url, drawio_url=drawio_url, svg_url=svg_url, draft=bool(task_id))


@app.route('/projects/<project_id>/workflow')
def project_workflow(project_id):
    context = refinement_context(project_id)
    state, data = project_manager.workflow_status(project_id)
    if state == 'ready':
        return workflow_response(project_manager.project_path(project_id), context['project'])
    return render_template('workflow.html', project=context['project'], data=None,
        state=state, draft=False)


@app.route('/projects/<project_id>/workflow/generate', methods=['POST'])
def generate_project_workflow(project_id):
    refinement_context(project_id)
    return jsonify(error='Workflow 随 PRD、原型一起生成。请回到首页点击继续优化，生成完整配套版本。'), 410


def workflow_image_response(directory):
    from workflow_document import validate_bundle, workflow_svg
    data = validate_bundle(directory)
    try: svg = workflow_svg(data, request.args.get('flow') or None)
    except ValueError: abort(404)
    response = app.response_class(svg, mimetype='image/svg+xml')
    response.headers['Content-Security-Policy'] = "default-src 'none'; style-src 'unsafe-inline'; sandbox"
    response.headers['X-Content-Type-Options'] = 'nosniff'
    return response


@app.route('/projects/<project_id>/workflow/image')
def project_workflow_image(project_id):
    refinement_context(project_id)
    state, _ = project_manager.workflow_status(project_id)
    if state != 'ready': return '流程图缺失或已过期，请重新生成。', 409
    return workflow_image_response(project_manager.project_path(project_id))


def workflow_download_response(directory, name):
    from workflow_document import validate_bundle
    validate_bundle(directory)
    extension = request.args.get('format', 'drawio')
    if extension not in ('drawio', 'svg'): abort(400)
    return send_file(Path(directory)/('workflow.'+extension), as_attachment=True,
        download_name='workflow-'+name+'.'+extension,
        mimetype='application/xml' if extension=='drawio' else 'image/svg+xml')


@app.route('/projects/<project_id>/workflow/export')
def project_workflow_export(project_id):
    refinement_context(project_id)
    state, _ = project_manager.workflow_status(project_id)
    if state != 'ready': return '流程图缺失或已过期，请重新生成。', 409
    return workflow_download_response(project_manager.project_path(project_id), project_id)


@app.route('/refinement-tasks/<task_id>/workflow-image')
def task_workflow_image(task_id):
    job = owned_refinement_task(task_id)
    if not job['completed']['workflow']: abort(409)
    return workflow_image_response(refinement_jobs.path(task_id))


@app.route('/refinement-tasks/<task_id>/workflow-export')
def task_workflow_export(task_id):
    job = owned_refinement_task(task_id)
    if not job['completed']['workflow']: abort(409)
    return workflow_download_response(refinement_jobs.path(task_id), task_id)


@app.route("/edit")
def edit():
    project_id = request.args.get("project_id", "").strip()
    if not project_id:
        return redirect(url_for("index"))
    return render_template("refine.html", **refinement_context(project_id))


from refinement_jobs import RefinementJobs
refinement_jobs = RefinementJobs(project_manager, app.logger)

from requirement_chats import RequirementChats
requirement_chats = RequirementChats(project_manager)


def owned_requirement_chat(chat_id):
    requirement_chats.manager = project_manager
    try:
        chat = requirement_chats.status(chat_id)
    except (ValueError, FileNotFoundError):
        abort(404)
    if chat['owner'] != session.get('refinement_owner'):
        abort(404)
    return chat


@app.route('/requirement-chats', methods=['POST'])
def new_requirement_chat():
    token = request.headers.get('X-CSRF-Token', '')
    if not token or not secrets.compare_digest(token, session.get('csrf_token', '')):
        return jsonify(error='页面已过期，请刷新后重试。'), 403
    data = request.get_json(silent=True) or {}
    if not isinstance(data, dict):
        return jsonify(error='无效请求。'), 400
    kind = data.get('kind')
    if kind not in ('create', 'refine'):
        return jsonify(error='请选择有效的讨论模式。'), 400
    context = {}; fingerprint = None
    if kind == 'refine':
        project_id = data.get('project_id', '')
        if not isinstance(project_id, str):
            return jsonify(error='无效项目。'), 400
        from project.project_manager import _apply_lock
        with _apply_lock:
            source = refinement_context(project_id)
            context = dict(project_id=project_id, name=source['project']['name'], requirement=source['raw_requirement'], prd=source['original_prd'])
            path = project_manager.get_html_path(project_id)
            if path:
                from workflow_document import prototype_text
                context['prototype'] = prototype_text(Path(path).read_text(encoding='utf-8'))
            workflow_path = project_manager.projects_dir/project_id/'workflow.json'
            if workflow_path.exists():
                context['workflow'] = workflow_path.read_text(encoding='utf-8')
            fingerprint = project_manager.project_fingerprint(project_id)
    owner = session.setdefault('refinement_owner', secrets.token_urlsafe(32))
    requirement_chats.manager = project_manager
    return jsonify(requirement_chats.public(requirement_chats.create(owner, kind, context, fingerprint))), 201


@app.route('/requirement-chats/restore', methods=['POST'])
def restore_requirement_chat():
    token=request.headers.get('X-CSRF-Token','')
    if not token or not secrets.compare_digest(token,session.get('csrf_token','')):
        return jsonify(error='页面已过期，请刷新后重试。'),403
    data=request.get_json(silent=True) or {}
    if not isinstance(data,dict):return jsonify(error='对话备份无效。'),400
    try:
        messages=RequirementChats.validate_recovery(data.get('messages'))
    except ValueError as error:
        return jsonify(error=str(error)),400
    # Recreate context through the normal authenticated path. Browser copies are
    # discussion data only; an imported draft never becomes generation-ready.
    response=new_requirement_chat()
    response=app.make_response(response)
    if response.status_code!=201:return response
    chat=requirement_chats.restore(response.get_json()['id'],messages)
    return jsonify(requirement_chats.public(chat)),201


@app.route('/requirement-chats/<chat_id>', methods=['GET', 'POST'])
def requirement_chat(chat_id):
    if request.method == 'POST':
        token = request.headers.get('X-CSRF-Token', '')
        if not token or not secrets.compare_digest(token, session.get('csrf_token', '')):
            return jsonify(error='页面已过期，请刷新后重试。'), 403
    chat = owned_requirement_chat(chat_id)
    if request.method == 'POST':
        data = request.get_json(silent=True) or {}
        if not isinstance(data, dict):
            return jsonify(error='无效请求。'), 400
        try:
            if data.get('action') == 'cancel':
                chat = requirement_chats.cancel(chat_id)
            elif data.get('action') in ('send', 'retry', 'summarize'):
                chat = requirement_chats.submit(chat_id, data.get('text', ''), retry=data['action']=='retry', summarize=data['action']=='summarize')
            else:
                return jsonify(error='无效操作。'), 400
        except ValueError as error:
            return jsonify(error=str(error)), 409
    response = jsonify(requirement_chats.public(chat))
    response.headers['Cache-Control'] = 'no-store'
    return response



def owned_refinement_task(task_id):
    try:
        job = refinement_jobs.status(task_id)
    except (ValueError, FileNotFoundError):
        abort(404)
    if job['state'] == 'deleted' or job['owner'] != session.get('refinement_owner'):
        abort(404)
    return job


@app.route("/projects/<project_id>/refine", methods=["POST"])
def refine_project(project_id):
    context = refinement_context(project_id)
    changes = request.form.get("changes", "").strip()
    token = request.form.get("csrf_token", "")
    if not token or not secrets.compare_digest(token, session.get("csrf_token", "")):
        return jsonify(error="页面已过期，请刷新后重试，修改要求不会自动提交。"), 403
    if request.form.get('conversation_id'):
        try:
            requirement_chats.manager = project_manager
            changes = requirement_chats.confirmed_brief(request.form['conversation_id'], session.get('refinement_owner'), request.form.get('conversation_revision'), 'refine', project_id)
        except FileNotFoundError:
            return jsonify(error='讨论记录不存在，请重新开始讨论。'), 409
        except ValueError as error:
            return jsonify(error=str(error)), 409
    if not changes or len(changes) > 20000:
        return jsonify(error="请填写 1–20000 字的修改要求。"), 400
    if not context["raw_requirement"] and not context["original_prd"]:
        return jsonify(error="原项目缺少需求和 PRD，无法优化。"), 400
    owner = session.setdefault('refinement_owner', secrets.token_urlsafe(32))
    # The service uses the configured manager; tests may replace it with isolated storage.
    refinement_jobs.manager = project_manager
    try:
        job = refinement_jobs.start(context, changes, owner)
    except ValueError as error:
        return jsonify(error=str(error)), 409
    target = url_for('refinement_task_page', task_id=job['id'])
    if request.accept_mimetypes.best == 'application/json':
        return jsonify(task_url=target, status_url=url_for('refinement_task_status', task_id=job['id'])), 202
    return redirect(target, code=303)


@app.route('/refinement-tasks/<task_id>/backup')
def export_generation_backup(task_id):
    import json,io
    job=owned_refinement_task(task_id)
    if job.get('kind')!='create':return jsonify(error='当前只支持首次生成阶段备份。'),400
    directory=refinement_jobs.path(task_id)
    payload={'schema':'product-agent/stage-backup','version':1,'kind':'create','name':job['source']['name'],
             'raw':job['raw'],'elapsed_seconds':job.get('elapsed_seconds',0),
             'prd':(directory/'requirement.md').read_text(encoding='utf-8') if job['completed']['prd'] else '',
             'html':(directory/'prototype.html').read_text(encoding='utf-8') if job['completed']['html'] else ''}
    return send_file(io.BytesIO(json.dumps(payload,ensure_ascii=False).encode()),as_attachment=True,download_name='stage-backup-'+task_id+'.json',mimetype='application/json')


@app.route('/generation-backups/import', methods=['POST'])
def import_generation_backup():
    token=request.form.get('csrf_token','')
    if not token or not secrets.compare_digest(token,session.get('csrf_token','')):
        return jsonify(error='页面已过期，请刷新后重试。'),403
    upload=request.files.get('backup')
    if not upload:return jsonify(error='请选择阶段成果备份JSON文件。'),400
    try:
        import json
        content=upload.read(2000001)
        if len(content)>2000000:raise ValueError('阶段备份文件过大。')
        data=json.loads(content.decode('utf-8'))
        refinement_jobs.manager=project_manager
        owner=session.setdefault('refinement_owner',secrets.token_urlsafe(32))
        job=refinement_jobs.import_creation_results(data,owner)
    except (ValueError,UnicodeError) as error:
        return jsonify(error='阶段备份无效，请检查文件内容。' if isinstance(error,UnicodeError) else str(error)),400
    return redirect(url_for('refinement_task_page',task_id=job['id']),code=303)


@app.route('/unfinished-tasks')
def unfinished_tasks():
    refinement_jobs.manager = project_manager
    owner = session.get('refinement_owner')
    attempts = refinement_jobs.history(owner, '*', limit=None, unfinished=True) if owner else []
    return render_template('unfinished_tasks.html', attempts=attempts)


@app.route('/generation-history')
def generation_history():
    refinement_jobs.manager = project_manager
    owner = session.get('refinement_owner')
    attempts = refinement_jobs.history(owner, '*') if owner else []
    return render_template('generation_history.html', attempts=attempts)


@app.route('/refinement-tasks/<task_id>')
def refinement_task_page(task_id):
    job = owned_refinement_task(task_id)
    if job['state'] == 'saved' and job.get('kind') == 'workflow':
        return redirect(url_for('project_workflow', project_id=job['source_id']), code=303)
    if job['state'] == 'saved' and job.get('kind', 'refine') == 'refine':
        saved = project_manager.get_project(job['saved_id'])
        if saved:
            current_id = saved['source_project_id'] if saved.get('applied_to_source_at') else saved['id']
            return redirect(url_for('index', _anchor='project-' + current_id), code=303)
    return render_template('refinement_task.html', job=job, attempts=refinement_jobs.history(job['owner'], job.get('source_id')))


@app.route('/refinement-tasks/<task_id>/status')
def refinement_task_status(task_id):
    job = owned_refinement_task(task_id)
    return jsonify(state=job['state'], stage=job['stage'], message=job['message'],
                   saved_id=job.get('saved_id'), prototype_modules=job.get('prototype_modules',{}), error_kind=job.get('error_kind'), elapsed_seconds=job.get('elapsed_seconds', 0),
                   stage_seconds=job.get('stage_seconds', {}), error_http=job.get('error_http'),
                   model_attempts=job.get('model_attempts', []), models_used=job.get('models_used', {}))


@app.route('/refinement-tasks/<task_id>/delete', methods=['POST'])
def delete_generation_task(task_id):
    owned_refinement_task(task_id)
    token = request.headers.get('X-CSRF-Token', '')
    if not token or not secrets.compare_digest(token, session.get('csrf_token', '')):
        return jsonify(error='页面已过期，请刷新后重试'), 403
    if (request.get_json(silent=True) or {}).get('confirmed') is not True:
        return jsonify(error='请先确认删除任务'), 400
    try:
        refinement_jobs.delete(task_id)
    except ValueError as error:
        return jsonify(error=str(error)), 409
    except OSError:
        return jsonify(error='删除未完成，请稍后重试'), 500
    return jsonify(deleted=True, task_id=task_id)


@app.route('/refinement-tasks/<task_id>/resume', methods=['POST'])
def resume_generation_task(task_id):
    job = owned_refinement_task(task_id)
    token = request.form.get('csrf_token', '') or request.headers.get('X-CSRF-Token', '')
    if not token or not secrets.compare_digest(token, session.get('csrf_token', '')):
        return jsonify(error='页面已过期，请刷新后重试'), 403
    try:
        refinement_jobs.resume(task_id)
    except ValueError as error:
        return render_template('refinement_task.html', job=job, error=str(error)), 409
    return redirect(url_for('refinement_task_page', task_id=task_id), code=303)


@app.route('/refinement-tasks/<task_id>/cancel', methods=['POST'])
def cancel_generation_task(task_id):
    owned_refinement_task(task_id)
    token = request.headers.get('X-CSRF-Token', '')
    if not token or not secrets.compare_digest(token, session.get('csrf_token', '')):
        return jsonify(error='页面已过期，请刷新后重试'), 403
    job = refinement_jobs.cancel(task_id)
    return jsonify(state=job['state'], message=job['message'])


@app.route('/refinement-tasks/<task_id>/<artifact>')
def refinement_task_artifact(task_id, artifact):
    job = owned_refinement_task(task_id)
    if artifact not in ('prd', 'preview', 'workflow') or not job['completed'].get({'preview':'html'}.get(artifact, artifact)):
        abort(404)
    if artifact == 'workflow':
        project = dict(job['source'], version=job['source'].get('version',1) + (1 if job.get('kind')=='refine' else 0))
        return workflow_response(refinement_jobs.path(task_id), project, task_id=task_id)
    file = refinement_jobs.path(task_id) / ('requirement.md' if artifact == 'prd' else 'prototype.html')
    if request.args.get('download') == '1':
        return send_file(file, as_attachment=True, download_name=file.name)
    if artifact == 'prd':
        return render_template('prd.html', content=file.read_text(encoding='utf-8'))
    return send_file(file, mimetype='text/html')


@app.route('/refinement-tasks/<task_id>/save', methods=['POST'])
def save_refinement_task(task_id):
    job = owned_refinement_task(task_id)
    token = request.form.get('csrf_token', '')
    if not token or not secrets.compare_digest(token, session.get('csrf_token', '')):
        abort(403)
    mode = request.form.get('mode')
    if mode == 'replace' and request.form.get('confirmed') != 'yes':
        return render_template('refinement_task.html', job=job, error='请先勾选确认覆盖。'), 400
    try:
        revision_id = refinement_jobs.save(task_id, mode)
    except (ValueError, FileNotFoundError) as error:
        return render_template('refinement_task.html', job=refinement_jobs.status(task_id), error=str(error)), 409
    except OSError:
        return render_template('refinement_task.html', job=job, error='保存失败，请重试；原版未修改。'), 500
    saved = project_manager.get_project(revision_id)
    current_id = saved['source_project_id'] if saved.get('applied_to_source_at') else revision_id
    return redirect(url_for('index', _anchor='project-' + current_id), code=303)


@app.route("/projects/<project_id>/refinement-result")
def refinement_result(project_id):
    project = refinement_context(project_id)['project']
    current_id = project['source_project_id'] if project.get('applied_to_source_at') else project_id
    return redirect(url_for('index', _anchor='project-' + current_id), code=303)


@app.route("/projects/<project_id>/apply-refinement", methods=["POST"])
def apply_refinement(project_id):
    token = request.form.get("csrf_token", "")
    if not token or not secrets.compare_digest(token, session.get("csrf_token", "")):
        abort(403)
    if request.form.get("confirmed") != "yes":
        return "请确认覆盖原版本后再操作。", 400
    try:
        project_manager.apply_refinement(project_id)
    except (ValueError, FileNotFoundError) as error:
        return jsonify(error=str(error)), 409
    except OSError:
        app.logger.exception("应用优化结果失败：%s", project_id)
        return "覆盖失败，原版本已恢复，优化新版本仍保留。请返回重试。", 500
    project = project_manager.get_project(project_id)
    return redirect(url_for("index", _anchor="project-" + project["source_project_id"]), code=303)


@app.errorhandler(404)
def not_found(error):

    return """
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <title>页面不存在</title>
    </head>
    <body style="
        padding: 40px;
        font-family: Arial, sans-serif;
    ">
        <h1>页面不存在</h1>
        <p>没有找到对应的项目或文件。</p>
        <a href="/">返回首页</a>
    </body>
    </html>
    """, 404


if __name__ == "__main__":

    print(
        """
==============================
 Product Agent 2.0

 Web 服务启动：

 http://127.0.0.1:5001

==============================
"""
    )

    app.run(
        host="127.0.0.1",
        port=5001,
        debug=True
    )