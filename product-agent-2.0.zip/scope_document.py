"""Versioned scope shared by PRD, modular prototype and Workflow."""
import hashlib,json,re,os
from pathlib import Path
from llm import LLM
from model_routing import notify, model_call_details

SCHEMA='product-agent/scope'
class ScopeError(ValueError):pass

def source_sections(text):
    """Keep advisory/excluded headings out of the evidence pool, not out of input."""
    confirmed=[];references=[];excluded=[];mode='confirmed'
    for line in text.splitlines():
        if re.match(r'^\s*#{1,6}\s+',line):
            heading=re.sub(r'^\s*#+\s*','',line)
            if re.search('建议|待确认|未来|后续|假设',heading):mode='references'
            elif re.search('未涉及|不涉及|不规划|不包含|排除|不做',heading):mode='excluded'
            else:mode='confirmed'
        {'confirmed':confirmed,'references':references,'excluded':excluded}[mode].append(line)
    return dict(source='\n'.join(confirmed),references='\n'.join(references),excluded='\n'.join(excluded))

def locked_rules(source):
    rules=[]
    for item in re.split(r'[。；;\n]+',source):
        item=item.strip().strip('- ').strip()
        if not item or item.startswith(('#','```')) or len(item)>700:continue
        if item.startswith('|') and re.search(r'\b(Long|String|Date|Boolean|Integer|Float|Double)\b',item):continue
        if re.search(r'\d+\s*(?:分钟|小时|天|分|秒)|发布前|发布后|不可见|不能|不得|禁止|必须|仅可|只有|弃考|不计入|总分\s*[=＝]|手动|人工',item):
            if item not in rules:rules.append(item)
    return rules

def hash_text(text):return hashlib.sha256(text.encode('utf-8')).hexdigest()
def parse_json(text):
    text=re.sub(r'^```(?:json)?\s*|\s*```$','',text.strip(),flags=re.I)
    try:return json.loads(text)
    except (ValueError,TypeError):raise ScopeError('需求范围返回格式不完整，可重试当前步骤。') from None

def short(value,label,limit=500):
    if not isinstance(value,str) or not value.strip() or len(value)>limit:raise ScopeError(label+'无效或过长。')
    return value.strip()

def validate_scope(data, source):
    if not isinstance(data,dict) or data.get('schema')!=SCHEMA or data.get('version')!=1:raise ScopeError('需求范围格式无效。')
    short(data.get('title'),'产品名称',100)
    actors=data.get('actors');pages=data.get('pages');flow=data.get('flow')
    if not isinstance(actors,list) or not 1<=len(actors)<=8 or len(set(map(str,actors)))!=len(actors):raise ScopeError('需求角色无效。')
    for actor in actors:
        short(actor,'角色',30)
        if actor!='用户' and actor not in source:raise ScopeError('需求范围增加了未确认角色：'+actor)
    if not isinstance(pages,list) or not 1<=len(pages)<=16:raise ScopeError('需求页面数量无效，请拆分过大的产品范围。')
    ids=[]
    def evidence(value):
        if not isinstance(value,list) or not 1<=len(value)<=3:raise ScopeError('范围依据应为原文引用列表。')
        for quote in value:
            short(quote,'范围依据',2000)
            if quote not in source:raise ScopeError('需求范围引用了未确认内容。')
    for page in pages:
        if not isinstance(page,dict) or not re.fullmatch(r'[a-z][a-z0-9_]{0,39}',str(page.get('id',''))):raise ScopeError('页面编号无效。')
        ids.append(page['id']);short(page.get('name'),'页面名称',80);short(page.get('purpose'),'页面用途')
        if page.get('actor') not in actors:raise ScopeError('页面引用了未确认角色。')
        evidence(page.get('evidence'))
        for key in ('fields','actions','states'):
            if not isinstance(page.get(key,[]),list) or len(page.get(key,[]))>30:raise ScopeError('页面内容格式无效。')
        for field in page.get('fields',[]):
            if not isinstance(field,dict):raise ScopeError('输入字段无效。')
            short(field.get('name'),'字段名称',80)
            if not isinstance(field.get('required',False),bool):raise ScopeError('字段必填设置无效。')
        for action in page.get('actions',[]):
            if not isinstance(action,dict):raise ScopeError('页面操作无效。')
            short(action.get('label'),'操作名称',80);short(action.get('result'),'操作结果',1200)
        for state in page.get('states',[]):short(state,'状态反馈',300)
    if len(set(ids))!=len(ids):raise ScopeError('页面编号重复。')
    for page in pages:
        if any(action.get('target','') not in ids+[''] for action in page.get('actions',[])):raise ScopeError('操作跳转页面不存在。')
    if not isinstance(flow,list) or not 1<=len(flow)<=40:raise ScopeError('核心业务流程缺失或过长。')
    for step in flow:
        if not isinstance(step,dict) or step.get('page') not in ids:raise ScopeError('流程引用页面不存在。')
        short(step.get('label'),'业务步骤',200);evidence(step.get('evidence'))
    for name in ('acceptance','exclusions','notes'):
        if not isinstance(data.get(name,[]),list) or len(data.get(name,[]))>40:raise ScopeError('范围说明格式无效。')
        for item in data.get(name,[]):short(item,'范围说明',1200)
    if not isinstance(data.get('shared_state',{}),dict) or len(json.dumps(data.get('shared_state',{}),ensure_ascii=False))>12000:raise ScopeError('演示数据契约过长或无效。')
    return data

def write_scope(data,directory,source):
    validate_scope(data,source);data=dict(data,source_digest=hash_text(source),confirmed_source=source,locked_rules=locked_rules(source))
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    temp=directory/'scope.tmp';temp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(temp,directory/'scope.json')
    notify({'state':'artifact_checkpoint','artifact':'scope'})
    return data

class ScopeAgent:
    def run(self,raw,*,output_dir,changes='',previous_scope=None):
        parts=source_sections(raw)
        source=parts['source']+ ('\n本次明确修改：\n'+changes if changes else '')
        target=Path(output_dir)/'scope.json'
        if target.is_file():
            data=json.loads(target.read_text(encoding='utf-8'))
            if data.get('source_digest')==hash_text(source):
                validate_scope(data,source)
                if data.get('locked_rules')!=locked_rules(source):return write_scope(data,output_dir,source)
                return data
        prompt=(Path(__file__).parent/'prompts/scope.txt').read_text(encoding='utf-8')
        prompt+='\nPRD整理规范（范围JSON用于按此规范组装PRD）：\n'+(Path(__file__).parent/'prompts/requirement.txt').read_text(encoding='utf-8')
        prompt+='\n分析资料：\n'+json.dumps(dict(parts,source=source,previous_scope=previous_scope),ensure_ascii=False)
        error=None
        for attempt in range(2):
            with model_call_details(operation='scope'):
                text=LLM().chat(prompt,max_tokens=6500,stream=True,retry_invalid_output=True)
            try:return write_scope(parse_json(text),output_dir,source)
            except ScopeError as exc:
                error=exc
                if attempt==0:prompt+='\n仅修正以下问题，不增加范围：'+str(exc)+'\n上次结果：'+text[:45000]
        raise error

def render_prd(scope):
    """One deterministic PRD from the locked scope; no second scope-expanding call."""
    def cell(v):return str(v).replace('|','／').replace('\n',' ')
    lines=['# '+scope['title'],'','## 一、版本目标与范围','本版本仅演示以下已确认页面和核心业务闭环；数据使用前端演示，不代表已接入真实接口。']
    if scope.get('exclusions'):lines+=['本版本不包含：']+['- '+x for x in scope['exclusions']]
    lines+=['','## 二、角色与页面','| 页面编号 | 页面名称 | 使用角色 | 页面目的 |','|---|---|---|---|']
    lines += ['| '+' | '.join(cell(p[k]) for k in ('id','name','actor','purpose'))+' |' for p in scope['pages']]
    lines+=['','## 三、页面与交互说明']
    for p in scope['pages']:
        lines+=['','### '+p['id']+'：'+p['name'],'- 展示内容：'+p['purpose']]
        for f in p.get('fields',[]):lines+=['- 输入字段：'+f['name']+('（必填）' if f.get('required') else '（选填）')+'；'+str(f.get('rule',''))]
        for a in p.get('actions',[]):lines+=['- 核心操作：'+a['label']+' → '+a['result']+('；跳转 '+a['target'] if a.get('target') else '')]
        for x in p.get('states',[]):lines+=['- 状态反馈：'+x]
    lines+=['','## 四、核心业务流程与规则']
    lines += [f"{i}. [{s['page']}] {s['label']}"+('；'+s['rule'] if s.get('rule') else '') for i,s in enumerate(scope['flow'],1)]
    lines+=['- 确认规则：'+rule for rule in scope.get('locked_rules',[])]
    lines+=['','## 五、核心验收点']+['- '+x for x in scope.get('acceptance',[])]
    lines+=['','## 六、演示假设与待确认事项']+(['- '+x for x in scope.get('notes',[])] or ['无'])
    return '\n'.join(lines)+'\n'
