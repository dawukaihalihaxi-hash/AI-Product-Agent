import time
import json
import requests
from urllib.parse import urlsplit
from pathlib import Path
from uuid import uuid4
from config import API_KEY, BASE_URL, MODEL
from model_routing import fallback_profile, notify


class ModelOutputError(ValueError):
    def __init__(self, code, message, *, partial_text='', finish_reason=None):
        self.code=code
        self.partial_text=partial_text
        self.finish_reason=finish_reason
        super().__init__(message)


class LLM:
    def __init__(self):
        self.api_key = API_KEY
        self.base_url = BASE_URL
        self.model = MODEL

    @staticmethod
    def temporary(error):
        if isinstance(error, (requests.Timeout, requests.ConnectionError)):
            return True
        if isinstance(error, requests.HTTPError) and error.response is not None:
            return error.response.status_code in (429, 500, 502, 503, 504)
        return False

    @staticmethod
    def error_details(error):
        code = error.response.status_code if isinstance(error, requests.HTTPError) and error.response is not None else None
        provider = None
        if code:
            try:
                value = error.response.json().get('error', {}).get('code')
                # Provider error codes only; never publish raw API bodies or exception text.
                if isinstance(value, (int, str)) and str(value).isdigit():
                    provider = str(value)[:16]
            except (ValueError, TypeError, AttributeError):
                pass
        return code, provider

    @staticmethod
    def read_stream(response, deadline, label, model, stats=None):
        parts=[];size=0;finish=None;last_notice=0
        stats={} if stats is None else stats
        for raw in response.iter_lines(chunk_size=256):
            if time.monotonic() >= deadline:
                raise requests.Timeout('Streaming request total time budget exhausted')
            # Calling hooks also checks cancellation, including reasoning-only chunks.
            notify({'state':'heartbeat','role':label,'model':model})
            if not raw:continue
            line=raw.decode('utf-8') if isinstance(raw,bytes) else raw
            if not line.startswith('data:'):continue
            payload=line[5:].strip()
            if payload=='[DONE]':break
            try:
                event=json.loads(payload)
                if isinstance(event.get('usage'),dict):stats['usage']={k:v for k,v in event['usage'].items() if k in ('prompt_tokens','completion_tokens','total_tokens') and isinstance(v,int)}
                if 'error' in event:raise ModelOutputError('stream_error','流式接口返回错误，未保存不完整输出。')
                choices=event.get('choices',[])
                if not choices:continue
                choice=choices[0];delta=choice.get('delta',{})
                reasoning=delta.get('reasoning_content')
                if isinstance(reasoning,str):stats['reasoning_characters']=stats.get('reasoning_characters',0)+len(reasoning)
                text=delta.get('content')
                if text:
                    if not isinstance(text,str):raise ModelOutputError('stream_format','流式输出格式异常。')
                    parts.append(text);size+=len(text)
                if size>500000:raise ModelOutputError('output_size','模型输出超过文件大小上限。')
                if choice.get('finish_reason'):finish=choice['finish_reason']
            except (KeyError,TypeError,json.JSONDecodeError,UnicodeError):
                raise ModelOutputError('stream_format','流式输出格式异常，未保存不完整输出。') from None
            if size and time.monotonic()-last_notice>=2:
                notify({'state':'progress','role':label,'model':model,'characters':size})
                last_notice=time.monotonic()
        stats.update(finish_reason=finish,characters=size)
        if finish=='length':raise ModelOutputError('output_truncated','模型思考阶段达到长度上限，未返回可用正文。' if size==0 and stats.get('reasoning_characters') else '模型输出达到长度上限，未把截断内容作为完整结果保存。',partial_text=''.join(parts),finish_reason=finish)
        if finish!='stop':raise ModelOutputError('stream_incomplete','模型输出连接提前结束，未保存不完整输出。',partial_text=''.join(parts),finish_reason=finish)
        content=''.join(parts)
        if not content.strip():raise ModelOutputError('output_empty','模型未返回可用的文本内容。')
        return content

    def chat(self, prompt, *, max_tokens=None, stream=False, retry_invalid_output=False, prefer_backup=False):
        backup = fallback_profile()
        primary = {'role':'主模型','api_key': self.api_key, 'url': self.base_url, 'model': self.model, 'max_tokens': 30000}
        if backup:backup=dict(backup,role='备用模型')
        profiles = [primary] + ([backup] if backup else [])
        if prefer_backup and backup:profiles=[backup]
        if max_tokens is not None:
            if not isinstance(max_tokens,int) or not 1 <= max_tokens <= 30000:
                raise ValueError('模型输出上限无效。')
            profiles = [dict(profile, max_tokens=min(profile['max_tokens'],max_tokens)) for profile in profiles]
        # Non-stream calls stay below the watchdog. Streams have an idle read
        # timeout and a bounded ten-minute total; progress refreshes the job watchdog.
        deadline = time.monotonic() + (600 if stream else 210) if backup or stream else None
        for index, profile in enumerate(profiles):
            label = profile['role']
            stats={'max_tokens':profile['max_tokens']};started=time.monotonic()
            notify({'state': 'requesting', 'role': label, 'model': profile['model'],'max_tokens':profile['max_tokens']})
            try:
                read_timeout = 180 if not backup else (60 if label=='主模型' else 130)
                if deadline is not None:
                    remaining = deadline - time.monotonic()
                    if remaining <= 10:
                        raise requests.Timeout('Model request time budget exhausted')
                    read_timeout = min(read_timeout, remaining - 10)
                extra={}
                host=urlsplit(profile['url']).hostname
                if host=='open.bigmodel.cn' and profile['model']=='glm-4.7-flash':extra['thinking']={'type':'disabled'}
                if host in ('api.siliconflow.cn','api.siliconflow.com') and profile['model'].lower().startswith('xingchenagi/xing4.0'):extra['enable_thinking']=False
                response = requests.post(
                    profile['url'],
                    headers={'Authorization': 'Bearer ' + profile['api_key'], 'Content-Type': 'application/json'},
                    json={'model': profile['model'], 'messages': [{'role': 'user', 'content': prompt}],
                          'temperature': 0.2, 'max_tokens': profile['max_tokens'], **extra, **({'stream': True} if stream else {})},
                    **({'stream': True} if stream else {}),
                    timeout=(10, read_timeout))
                response.raise_for_status()
                if stream and 'text/event-stream' in response.headers.get('Content-Type', ''):
                    try:
                        content = self.read_stream(response, deadline, label, profile['model'],stats)
                    finally:
                        response.close()
                    self.last_role=label
                    notify({'state': 'succeeded', 'role': label, 'model': profile['model'],**stats,'duration_seconds':round(time.monotonic()-started,2)})
                    return content
                data = response.json()
                if isinstance(data.get('usage'),dict):stats['usage']={k:v for k,v in data['usage'].items() if k in ('prompt_tokens','completion_tokens','total_tokens') and isinstance(v,int)}
                try:
                    choice = data['choices'][0]
                    content = choice['message']['content']
                except (KeyError, IndexError, TypeError):
                    raise ModelOutputError('output_format','模型返回缺少有效内容。') from None
                if not isinstance(content, str) or not content.strip():
                    raise ModelOutputError('output_empty','模型未返回可用的文本内容。')
                stats.update(finish_reason=choice.get('finish_reason'),characters=len(content))
                if choice.get('finish_reason') == 'length':
                    raise ModelOutputError('output_truncated','模型输出达到长度上限，未把截断内容作为完整结果保存。',partial_text=content,finish_reason='length')
                self.last_role=label
                notify({'state': 'succeeded', 'role': label, 'model': profile['model'],**stats,'duration_seconds':round(time.monotonic()-started,2)})
                return content
            except ModelOutputError as error:
                notify({'state':'failed','role':label,'model':profile['model'],'reason':str(error),'output_code':error.code,**stats,'duration_seconds':round(time.monotonic()-started,2)})
                if label=='主模型' and backup and retry_invalid_output:
                    notify({'state':'switching','role':'备用模型','model':backup['model']})
                    continue
                raise
            except (requests.HTTPError, requests.Timeout, requests.ConnectionError) as error:
                status, code = self.error_details(error)
                notify({'state': 'failed', 'role': label, 'model': profile['model'],
                        'http_status': status, 'provider_code': code,
                        'reason': '连接超时' if isinstance(error, requests.Timeout) else '连接失败' if isinstance(error, requests.ConnectionError) else '接口拒绝请求'})
                if label=='主模型' and backup and self.temporary(error):
                    notify({'state': 'switching', 'role': '备用模型', 'model': backup['model']})
                    continue
                raise
