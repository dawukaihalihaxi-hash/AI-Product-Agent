"""Cloud-only entry point. Local `python3 app.py` still listens on 127.0.0.1:5001."""
import os
import json
from pathlib import Path
import secrets
from flask import Response, request, session, g, abort
from werkzeug.middleware.proxy_fix import ProxyFix
from app import app

if os.environ.get('RENDER'):
    for name in ('PRODUCT_AGENT_SECRET_KEY', 'MODEL_API_KEY'):
        if not os.environ.get(name):
            raise RuntimeError('Required cloud setting is missing: ' + name)

app.config.update(SESSION_COOKIE_SECURE=bool(os.environ.get('RENDER')),
                  MAX_CONTENT_LENGTH=2 * 1024 * 1024)
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

def access_mode():
    mode=os.environ.get('PRODUCT_AGENT_ACCESS_MODE','public').strip().lower()
    if mode not in ('public','password'):
        raise RuntimeError('PRODUCT_AGENT_ACCESS_MODE must be public or password')
    if mode=='password' and not os.environ.get('PRODUCT_AGENT_ACCESS_PASSWORD'):
        raise RuntimeError('Password mode requires PRODUCT_AGENT_ACCESS_PASSWORD')
    return mode

# Validate configuration at startup, while keeping the old password available.
access_mode()

@app.before_request
def cloud_access_gate():
    if request.path == '/healthz':
        return None
    password = os.environ.get('PRODUCT_AGENT_ACCESS_PASSWORD')
    auth = request.authorization
    authenticated=bool(password and auth and secrets.compare_digest(auth.password or '',password))
    if access_mode()=='password' and not authenticated:
        return Response('请输入演示访问口令。用户名可填写 demo。',401,
                        {'WWW-Authenticate':'Basic realm="Product Agent Demo", charset="UTF-8"',
                         'Cache-Control':'no-store'})
    g.demo_guest=access_mode()=='public' and not authenticated
    if g.demo_guest:
        session.setdefault('refinement_owner',secrets.token_urlsafe(32))
        # Legacy shared output is private; generated guest projects use owned URLs.
        if request.endpoint in ('prd','preview'):
            abort(404)
        project_id=(request.view_args or {}).get('project_id')
        if request.endpoint=='edit':project_id=request.args.get('project_id')
        if project_id:
            from app import project_manager
            try:project=project_manager.get_project(project_id)
            except ValueError:abort(404)
            if not project or project.get('owner')!=session.get('refinement_owner'):
                abort(404)


@app.get('/healthz')
def healthz():
    release=json.loads(Path(__file__).with_name('RELEASE.json').read_text())
    from app import project_manager
    return {'status':'ok',**release,'storage':'database' if project_manager.store.enabled else 'local-ephemeral'}

@app.context_processor
def cloud_demo_context():
    return {'cloud_demo': bool(os.environ.get('RENDER'))}

@app.after_request
def cloud_headers(response):
    response.headers['X-Robots-Tag'] = 'noindex, nofollow'
    return response
