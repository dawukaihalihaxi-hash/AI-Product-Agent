import os
from pathlib import Path

from confirmed_content import confirmed_text
from llm import LLM


class RequirementAgent:

    def __init__(self):
        self.llm = LLM()


    def run(self, user_requirement, *, output_dir=None):

        print("========== Requirement Agent ==========")

        destination=Path(output_dir) if output_dir is not None else Path(__file__).resolve().parent.parent/'output'
        scope_path=destination/'scope.json'
        if scope_path.is_file():
            import json
            from scope_document import render_prd,validate_scope
            scope=json.loads(scope_path.read_text(encoding='utf-8'))
            validate_scope(scope,scope['confirmed_source'])
            result=render_prd(scope)
            (destination/'requirement.md').write_text(result,encoding='utf-8')
            return result

        # 读取需求分析 Prompt
        with open(
            Path(__file__).resolve().parent.parent / "prompts" / "requirement.txt",
            "r",
            encoding="utf-8"
        ) as f:

            prompt = f.read()


        final_prompt = f"""
{prompt}


========================

用户需求：

{confirmed_text(user_requirement)}
"""


        # 调用大模型
        result = self.llm.chat(final_prompt,max_tokens=12000,stream=True)


        result=confirmed_text(result)

        # 创建输出目录
        destination = Path(output_dir) if output_dir is not None else Path(__file__).resolve().parent.parent / "output"
        os.makedirs(
            destination,
            exist_ok=True
        )


        # 保存 PRD
        if not result or not result.strip():
            raise ValueError("PRD 生成结果为空")
        output_file = destination / "requirement.md"


        with open(
            output_file,
            "w",
            encoding="utf-8"
        ) as f:

            f.write(result)


        print(f"✅ 已保存到：{output_file}")


        return result