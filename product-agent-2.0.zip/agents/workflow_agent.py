import json
import os
import re
from pathlib import Path
from datetime import datetime
from uuid import uuid4
from confirmed_content import confirmed_text
from llm import LLM, ModelOutputError
from model_routing import FallbackConfigurationError
from workflow_document import prototype_text, write_workflow, digest


class WorkflowGenerationError(ValueError):
    """User-readable Workflow failure without provider bodies or credentials."""


def evidence_catalog(prd, html):
    records=[]
    for prefix,source,text in [('P','prd',prd),('H','prototype',prototype_text(html))]:
        index=0
        for line in text.splitlines():
            line=line.strip()
            if not line:continue
            for offset in range(0,len(line),300):
                quote=line[offset:offset+300]
                index+=1
                records.append({'ref':f'{prefix}{index:03d}','source':source,'quote':quote})
    return records


def parse_result(result):
    text=result.strip().lstrip('\ufeff')
    text=re.sub(r'^```(?:json)?\s*|\s*```$', '', text, flags=re.IGNORECASE)
    try:
        return json.loads(text)
    except json.JSONDecodeError as error:
        raise WorkflowGenerationError(f'Workflow 返回的 JSON 格式无效（第 {error.lineno} 行、第 {error.colno} 列）。') from None


def resolve_evidence(data, catalog):
    """Resolve catalog IDs; accept legacy quotes only when their source is verifiable."""
    sources={item['ref']:item for item in catalog}
    aliases={'prd':'prd','requirement':'prd','requirement.md':'prd','prototype':'prototype','html':'prototype','prototype.html':'prototype'}
    if not isinstance(data,dict):return data
    for flow in data.get('flows',[]) if isinstance(data.get('flows'),list) else []:
        if not isinstance(flow,dict):continue
        # A start/end marker has no independent business role. Resolve only the
        # model's generic 'system' marker to its adjacent, already-declared lane.
        nodes=flow.get('nodes',[]);actors=data.get('actors',[])
        if isinstance(nodes,list) and isinstance(actors,list):
            by_id={n.get('id'):n for n in nodes if isinstance(n,dict)}
            edges=flow.get('edges',[])
            for n in nodes:
                if not isinstance(n,dict) or n.get('type') not in ('start','end') or n.get('actor') not in ('系统','system','System') or n.get('actor') in actors:continue
                adjacent=[]
                for edge in edges if isinstance(edges,list) else []:
                    if not isinstance(edge,dict):continue
                    other=edge.get('source') if n.get('type')=='end' and edge.get('target')==n.get('id') else edge.get('target') if n.get('type')=='start' and edge.get('source')==n.get('id') else None
                    if other in by_id and by_id[other].get('actor') in actors:adjacent.append(by_id[other]['actor'])
                if adjacent and len(set(adjacent))==1:n['actor']=adjacent[0]
        for node in flow.get('nodes',[]) if isinstance(flow.get('nodes'),list) else []:
            if not isinstance(node,dict):continue
            evidence_items=node.get('evidence',[])
            if isinstance(evidence_items,(dict,str)):evidence_items=[evidence_items]
            if not isinstance(evidence_items,list):
                raise WorkflowGenerationError(f"流程 {flow.get('id','?')}，节点 {node.get('id','?')}：节点依据格式无效，应为资料编号列表。")
            resolved=[]
            location=f"流程 {flow.get('id','?')}，节点 {node.get('id','?')}"
            for evidence in evidence_items:
                ref=evidence if isinstance(evidence,str) else evidence.get('ref') if isinstance(evidence,dict) else None
                if ref is not None:
                    ref=ref.strip().upper() if isinstance(ref,str) else ref
                    if not isinstance(ref,str) or ref not in sources:
                        raise WorkflowGenerationError(location+'：使用了不存在的资料编号；evidence 必须引用资料清单中的 ref。')
                    item=sources[ref];resolved.append({'source':item['source'],'quote':item['quote']})
                elif isinstance(evidence,dict):
                    source=evidence.get('source');quote=evidence.get('quote')
                    canonical=aliases.get(source.strip().lower()) if isinstance(source,str) else None
                    if canonical is None:
                        raise WorkflowGenerationError(location+'：节点依据来源无效；请改用资料清单中的 ref，不要自行填写来源名称。')
                    # Exact quote membership is still checked by validate_workflow.
                    resolved.append({'source':canonical,'quote':quote})
                else:
                    raise WorkflowGenerationError(location+'：节点依据格式无效；应为 {"ref":"P001"}。')
            node['evidence']=resolved
    data['notes']=[]
    return data


def record_attempt(directory, result, report):
    folder=directory/'.workflow-diagnostics'
    folder.mkdir(exist_ok=True,mode=0o700)
    name=datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid4().hex[:8]
    # These task-local records are excluded from exports and formal project bundles.
    for suffix,content in [('response.txt',result),('report.json',json.dumps(report,ensure_ascii=False,indent=2))]:
        file=folder/(name+'.'+suffix)
        fd=os.open(file,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w',encoding='utf-8') as stream:stream.write(content)


class WorkflowAgent:
    def run(self, *, output_dir):
        directory=Path(output_dir)
        prd=(directory/'requirement.md').read_text(encoding='utf-8')
        html=(directory/'prototype.html').read_text(encoding='utf-8')
        text=prototype_text(html)
        if len(prd)+len(text)>180000:
            raise WorkflowGenerationError('Workflow 输入过长，无法完整核对业务流程，请拆分需求。')
        catalog=evidence_catalog(confirmed_text(prd),html)
        prompt_path=Path(__file__).resolve().parents[1]/'prompts'/'workflow.txt'
        prompt=prompt_path.read_text(encoding='utf-8')+json.dumps(catalog,ensure_ascii=False)
        scope_path=directory/'scope.json'
        if scope_path.is_file():
            scope=json.loads(scope_path.read_text(encoding='utf-8'))
            prompt+='\n已锁定的范围（不得引入范围外的角色、功能或流程）：\n'+json.dumps({k:scope.get(k) for k in ('title','actors','pages','flow','exclusions')},ensure_ascii=False)
        # A previous complete result may have failed only an advisory-text check.
        # Reuse it after full graph/evidence validation instead of another model call.
        diagnostics=directory/'.workflow-diagnostics'
        for report_path in sorted(diagnostics.glob('*.report.json'),reverse=True)[:6]:
            try:
                report=json.loads(report_path.read_text(encoding='utf-8'))
                if report.get('state')!='invalid' or report.get('source_digest')!=digest(prd,html):
                    continue
                response_path=report_path.with_name(report_path.name.removesuffix('.report.json')+'.response.txt')
                result=response_path.read_text(encoding='utf-8')
                generated=write_workflow(resolve_evidence(parse_result(result),catalog),directory)
                record_attempt(directory,result,{'state':'validated','source_digest':digest(prd,html),'reused':'advisory-validation-fix'})
                return generated
            except (ValueError,OSError,TypeError):
                continue
        last_error=None
        for attempt in range(2):
            try:
                result=LLM().chat(prompt,max_tokens=8000,stream=True,retry_invalid_output=True)
            except FallbackConfigurationError:
                raise
            except ModelOutputError as error:
                record_attempt(directory,'',{'state':'model_output_failed','source_digest':digest(prd,html),'code':error.code})
                raise WorkflowGenerationError('Workflow '+str(error)+'；已保留 PRD 和原型。') from None
            except ValueError:
                raise WorkflowGenerationError('Workflow 模型未返回完整可用的文本，可能为空、格式异常或输出被截断；已保留 PRD 和原型。') from None
            if not isinstance(result,str) or not result.strip():
                raise WorkflowGenerationError('Workflow 模型返回内容为空；已保留 PRD 和原型。')
            report={'attempt':attempt+1,'source_digest':digest(prd,html)}
            try:
                data=resolve_evidence(parse_result(result),catalog)
                generated=write_workflow(data,directory)
            except ValueError as error:
                last_error=error if isinstance(error,WorkflowGenerationError) else WorkflowGenerationError('Workflow 流程校验未通过：'+str(error)+'。')
                report.update(state='invalid',reason=str(last_error))
                record_attempt(directory,result,report)
                if attempt==0:
                    prompt+='\n上一份结果未通过校验。只修正以下结果中的结构、引用或图连接问题，不要新增业务功能；返回修正后的完整JSON。\n校验问题：'+str(last_error)+'\n上一份JSON：\n'+result[:60000]
                    continue
                raise last_error from None
            report.update(state='validated');record_attempt(directory,result,report)
            return generated
        raise last_error
