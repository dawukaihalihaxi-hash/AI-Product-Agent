import os
from pathlib import Path
import re

from llm import LLM


class HtmlAgent:

    def __init__(self):
        self.llm = LLM()


    def clean_html(self, content):

        """
        清理模型输出
        """

        # 去除 Markdown代码块
        content = content.replace("```html", "")
        content = content.replace("```", "")

        content = content.strip()


        # 截取DOCTYPE开始的位置
        start = content.lower().find("<!doctype")

        if start != -1:
            content = content[start:]


        # 截取html结束位置
        end = content.lower().rfind("</html>")

        if end != -1:
            content = content[:end + 7]


        return content



    def validate_html(self, content):

        """
        HTML完整性检查
        """

        content = content.lower()
        checks = {

            "DOCTYPE": "<!doctype" in content,

            "html开始": "<html" in content,

            "body开始": "<body" in content,

            "body结束": "</body>" in content,

            "html结束": "</html>" in content

        }


        print("\n========== HTML检查 ==========")

        for key, value in checks.items():

            print(
                f"{key}: {'通过' if value else '失败'}"
            )


        return all(checks.values())



    def run(self, *, output_dir=None, previous_html=None, change_request=None):


        # 读取需求文档

        destination = Path(output_dir) if output_dir is not None else Path(__file__).resolve().parent.parent / "output"
        requirement_path = destination / "requirement.md"


        if not os.path.exists(requirement_path):

            raise Exception(
                "没有找到 output/requirement.md，请先生成需求文档"
            )


        with open(
            requirement_path,
            "r",
            encoding="utf-8"
        ) as f:

            requirement = f.read()



        scope_path=destination/'scope.json'
        if scope_path.is_file():
            import json
            from prototype_modules import ModularPrototype
            from scope_document import validate_scope
            scope=json.loads(scope_path.read_text(encoding='utf-8'))
            validate_scope(scope,scope['confirmed_source'])
            return ModularPrototype(self.llm).run(destination,scope,requirement,previous_html,change_request)

        # 读取HTML Prompt

        with open(
            Path(__file__).resolve().parent.parent / "prompts" / "html.txt",
            "r",
            encoding="utf-8"
        ) as f:

            prompt = f.read()



        final_prompt = f"""
{prompt}


========================

产品需求文档：

{requirement}

========================

再次提醒：

只输出完整HTML。保持实现紧凑，复用样式和组件；不要用大量重复示例数据、内嵌base64图片或无关模块拉长输出。必须实现PRD要求的页面和交互，不能为了缩短输出删掉必要功能。

必须包含：

<!DOCTYPE html>

<html>

<head>

<body>

</body>

</html>

不要输出解释。
"""



        print(
            "========== HTML Agent =========="
        )


        if previous_html:
            final_prompt += f"""

当前任务是优化已有原型。以以下旧 HTML 为基础，结合更新后的 PRD 和本次修改要求修改。
保留未涉及的页面、布局、样式及交互，不要仅重新生成首页，不要删除其他已有模块。
最终仍需输出修改后的完整 HTML，不能只输出片段或补丁。

本次修改要求：
{change_request or ""}

旧 HTML 原型：
{previous_html}
"""

        # 调用模型

        result = self.llm.chat(final_prompt,max_tokens=16000,stream=True,retry_invalid_output=True)



        # 清理

        html = self.clean_html(result)



        # 检查

        if not self.validate_html(html):

            print(
                "\n❌ HTML生成失败，未保存文件"
            )

            return html



        # 创建目录

        os.makedirs(
            destination,
            exist_ok=True
        )


        output_path = (
            destination / "prototype.html"
        )



        # 保存

        with open(
            output_path,
            "w",
            encoding="utf-8"
        ) as f:

            f.write(html)



        print(
            f"\n✅ HTML 已保存：{output_path}"
        )


        print(
            f"文件大小：{os.path.getsize(output_path)} bytes"
        )


        return html