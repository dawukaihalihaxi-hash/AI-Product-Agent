"""Explicit, server-side fallback configuration and per-task model event hooks."""
from contextlib import contextmanager
from contextvars import ContextVar
import os
from urllib.parse import urlsplit
from local_model_settings import read_settings

class FallbackConfigurationError(ValueError):
    """Safe configuration messages, containing no secret values."""


_hooks = ContextVar('model_routing_hooks', default=(None, None))
_details = ContextVar('model_call_details',default={})

@contextmanager
def model_call_details(**values):
    token=_details.set(dict(_details.get(),**values))
    try:yield
    finally:_details.reset(token)


@contextmanager
def model_call_context(on_event=None, check_cancelled=None):
    token = _hooks.set((on_event, check_cancelled))
    try:
        yield
    finally:
        _hooks.reset(token)


def notify(event):
    on_event, check_cancelled = _hooks.get()
    if check_cancelled:
        check_cancelled()
    if on_event:
        on_event(dict(_details.get(),**event))


def fallback_profile():
    settings = os.environ if 'MODEL_FALLBACK_ENABLED' in os.environ else read_settings()
    if settings.get('MODEL_FALLBACK_ENABLED', '').lower() not in ('1', 'true', 'yes'):
        return None
    # No key is reused across providers, and no paid model is selected by default.
    key = settings.get('MODEL_FALLBACK_API_KEY', '').strip()
    url = settings.get('MODEL_FALLBACK_BASE_URL', 'https://openrouter.ai/api/v1/chat/completions').strip()
    model = settings.get('MODEL_FALLBACK_NAME', 'openrouter/free').strip()
    if not key or not model:
        raise FallbackConfigurationError('备用模型已启用，但缺少密钥或模型名称。')
    parts = urlsplit(url)
    if parts.scheme != 'https' or not parts.hostname or parts.username or parts.password or parts.query or parts.fragment:
        raise FallbackConfigurationError('备用模型地址必须是完整 HTTPS 接口地址，不应包含密钥或查询参数。')
    if parts.hostname == 'openrouter.ai' and model != 'openrouter/free' and not model.endswith(':free'):
        if settings.get('MODEL_FALLBACK_ALLOW_PAID', '').lower() not in ('1', 'true', 'yes'):
            raise FallbackConfigurationError('OpenRouter 备用模型不是免费模型；需要明确允许付费后才能启用。')
    try:
        limit = int(settings.get('MODEL_FALLBACK_MAX_TOKENS', '30000'))
    except ValueError:
        raise FallbackConfigurationError('备用模型输出上限必须是整数。') from None
    if not 256 <= limit <= 30000:
        raise FallbackConfigurationError('备用模型输出上限应在 256–30000 之间。')
    return {'api_key': key, 'url': url, 'model': model, 'max_tokens': limit}
