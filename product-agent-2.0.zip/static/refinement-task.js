(() => {
  const root=document.getElementById('task');
  const stages=['queued','prd','html','workflow','checking','ready'];
  function paint(stage){document.querySelectorAll('.steps [data-stage]').forEach(node=>{node.classList.toggle('current',node.dataset.stage===stage);node.classList.toggle('done',stages.indexOf(node.dataset.stage)<stages.indexOf(stage));});}
  paint(root.dataset.stage);
  let busy=false,timer;
  let elapsed=Number(root.dataset.elapsed)||0, syncedAt=Date.now();
  function showTime(){const node=document.getElementById('task-elapsed');if(node){const seconds=Math.floor(elapsed+(root.dataset.state==='running'?(Date.now()-syncedAt)/1000:0));node.textContent=`${Math.floor(seconds/60)} 分 ${seconds%60} 秒`;}}
  showTime();if(root.dataset.state==='running'&&typeof setInterval==='function')setInterval(showTime,1000);
  let lastModelHistory;
  function syncModelHistory(job){
    const panel=document.getElementById('model-call-history'),list=document.getElementById('model-call-list');
    if(!panel||!list||!Array.isArray(job.model_attempts))return;
    const signature=JSON.stringify(job.model_attempts);
    if(signature===lastModelHistory)return;
    const rows=job.model_attempts.map(call=>{
      const row=document.createElement('p');
      const stage={prd:'PRD',html:'原型',workflow:'Workflow'}[call.stage]||call.stage||'';
      const state={requesting:'已发起请求',switching:'正在切换',succeeded:'已返回结果',failed:'调用失败'}[call.state]||call.state||'';
      let text=`${stage} · ${call.role||''} · ${call.model||''}：${state}`;
      if(call.http_status)text+=`（HTTP ${call.http_status}${call.provider_code?'，错误码 '+call.provider_code:''}）`;
      if(call.module)text+=' · 页面 '+call.module;
      if(call.max_tokens)text+=' · 输出预算 '+call.max_tokens;
      if(call.usage&&Number.isFinite(call.usage.completion_tokens))text+=' · 输出用量 '+call.usage.completion_tokens;
      if(call.reason)text+=' · '+call.reason;
      row.textContent=text;return row;
    });
    list.replaceChildren(...rows);
    panel.hidden=rows.length===0;
    lastModelHistory=signature;
  }
  async function poll(){
    if(busy)return;
    busy=true;clearTimeout(timer);
    const note=document.getElementById('poll-message');
    try{
      const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),12000);
      let response;try{response=await fetch(root.dataset.statusUrl,{cache:'no-store',signal:controller.signal});}finally{clearTimeout(timeout);}
      if(!response.ok)throw new Error(response.status===404?'任务页面已过期或登录状态变化，请刷新页面。':'暂时无法读取进度');
      const job=await response.json();
      syncModelHistory(job);
      document.getElementById('task-message').textContent=job.message;paint(job.stage);if(note)note.textContent='';
      if(Number.isFinite(job.elapsed_seconds)){elapsed=job.elapsed_seconds;syncedAt=Date.now();showTime();}
      if(job.state!=='running'){window.location.reload();return;}
    }catch(error){if(note)note.textContent='暂时无法连接服务或读取进度，不代表模型生成失败。请检查网络或稍后刷新；已保存的阶段结果不会因本次查询失败而重跑。';}
    finally{busy=false;}
    timer=setTimeout(poll,2000);
  }
  if(root.dataset.state==='running'){poll();document.getElementById('refresh-status').addEventListener('click',poll);}
  const cancel=document.getElementById('cancel-task');
  if(cancel)cancel.addEventListener('click',async()=>{
    if(!window.confirm('停止本次生成？后续步骤和保存将取消，已发出的模型请求可能仍在执行。'))return;
    cancel.disabled=true;
    try{
      const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),12000);
      let response;try{response=await fetch(root.dataset.cancelUrl,{method:'POST',headers:{'X-CSRF-Token':root.dataset.csrf},signal:controller.signal});}finally{clearTimeout(timeout);}
      const data=await response.json();if(!response.ok)throw new Error(data.error||`停止请求失败（HTTP ${response.status}）`);
      window.location.reload();
    }catch(error){document.getElementById('poll-message').textContent='停止请求尚未确认：'+(error.message||'本地服务连接中断')+'。请重试；不能据此认定已经停止。';cancel.disabled=false;}
  });
  document.querySelectorAll('.save-form').forEach(form=>form.addEventListener('submit',event=>{
    if(form.dataset.replace&&!window.confirm('确认覆盖原版？覆盖前会备份，并保留独立新版本。')){event.preventDefault();return;}
    document.querySelectorAll('.save-form button').forEach(button=>button.disabled=true);
    document.getElementById('save-status').textContent='正在保存，请稍候…';
  }));
})();
