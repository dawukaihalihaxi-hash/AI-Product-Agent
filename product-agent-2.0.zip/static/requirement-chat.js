(() => {
'use strict';
const root=document.querySelector('.requirement-chat');if(!root)return;
const get=s=>root.querySelector(s),feed=get('.chat-feed'),composer=get('.chat-composer'),input=get('.chat-input'),status=get('.chat-status'),brief=get('.chat-brief'),generate=get('.chat-generate'),confirm=get('.chat-confirm'),stop=get('.chat-stop'),retry=get('.chat-retry'),fresh=get('.chat-new'),summarize=get('.chat-summarize'),draft=get('.chat-draft'),recovery=get('.chat-recovery');
const key=`product-agent-chat:${root.dataset.kind}:${root.dataset.project}`;
let id=null,current=null,timer=null,signature='',busy=false,submitting=false,epoch=0,lost=false;
const saved=(name,value)=>{try{if(value===undefined)return sessionStorage.getItem(name);value===null?sessionStorage.removeItem(name):sessionStorage.setItem(name,value);}catch(_){}return null;};
input.value=saved(key+':input')||'';input.addEventListener('input',()=>saved(key+':input',input.value));
async function request(url,body){const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),15000);try{const response=await fetch(url,{method:body?'POST':'GET',headers:{Accept:'application/json',...(body?{'Content-Type':'application/json','X-CSRF-Token':root.dataset.csrf}:{})},body:body?JSON.stringify(body):undefined,signal:controller.signal,cache:'no-store'});if(!(response.headers.get('content-type')||'').includes('application/json'))(()=>{const error=new Error(`服务响应异常（HTTP ${response.status}），请稍后重试。`);error.status=response.status;throw error;})();const data=await response.json();if(!response.ok){const error=new Error(data.error||`请求未完成（HTTP ${response.status}）`);error.status=response.status;throw error;}return data;}finally{clearTimeout(timeout);}}
function errorText(error){return error.name==='AbortError'||error instanceof TypeError?'连接中断或请求超时，输入已保留。可以重新连接或稍后重试。':error.message;}
function missing(error){if(error.status!==404)return false;lost=true;clearTimeout(timer);status.textContent='服务器已找不到原对话，已停止自动重连。请点击恢复本页对话，内容不会自动提交生成。';status.dataset.error='true';controls();return true;}
function controls(){recovery.hidden=!lost;get('.chat-restore').disabled=busy||!current?.messages?.length;get('.chat-download').disabled=!current?.messages?.length;const running=!lost&&current?.state==='running',waiting=lost||running||(current&&['failed','cancelled'].includes(current.state)&&!current.can_retry);composer.querySelector('[type=submit]').disabled=busy||waiting||submitting;stop.hidden=!running;stop.disabled=busy;retry.hidden=!current||!['failed','cancelled'].includes(current.state);retry.disabled=busy||!current?.can_retry;fresh.disabled=busy||running||submitting;summarize.disabled=busy||submitting||waiting||!current?.messages?.some(message=>message.role==='user')||input.value.trim().length>0;draft.hidden=!current?.draft_ready||!current?.brief;confirm.disabled=lost||busy||submitting||!id||current?.state!=='idle'||!current?.draft_ready||!current?.brief||input.value.trim().length>0;composer.querySelector('[type=submit]').hidden=running;}
input.addEventListener('input',controls);
function render(data){if(current?.id===data.id&&(Number(data.revision)<Number(current.revision)||(Number(data.revision)===Number(current.revision)&&current.state!=='running'&&data.state==='running')))return;lost=false;current=data;saved(key+':snapshot',JSON.stringify(data));id=data.id;saved(key,id);status.textContent=data.message||'';summarize.textContent=data.state==='running'&&data.last_action==='summarize'?'正在整理需求草稿…':'内容确认，整理需求草稿';status.dataset.error=String(['failed','cancelled'].includes(data.state));brief.textContent=data.brief||'本轮整理完成后会显示完整草案。';get('[name=conversation_id]').value=id;get('[name=conversation_revision]').value=data.revision;
 const next=JSON.stringify(data.messages);if(next!==signature){signature=next;const near=feed.scrollHeight-feed.scrollTop-feed.clientHeight<80;feed.replaceChildren();for(const message of data.messages){const node=document.createElement('div');node.className='chat-message '+(message.role==='user'?'user':'assistant');node.textContent=message.content;feed.append(node);}if(near||data.messages.at(-1)?.role==='user')feed.scrollTop=feed.scrollHeight;}
 controls();clearTimeout(timer);if(data.state==='running'||(['failed','cancelled'].includes(data.state)&&!data.can_retry))timer=setTimeout(poll,2000);
}
async function poll(){if(!id)return;const version=epoch;try{const data=await request('/requirement-chats/'+id);if(version===epoch)render(data);}catch(error){if(version!==epoch||missing(error))return;status.textContent=errorText(error)+' 正在自动重新连接…';timer=setTimeout(poll,4000);}}
async function act(action){if(busy)return;epoch++;clearTimeout(timer);busy=true;controls();try{if(!id){const data=await request('/requirement-chats',{kind:root.dataset.kind,project_id:root.dataset.project});id=data.id;saved(key,id);}const data=await request('/requirement-chats/'+id,{action,text:input.value});if(action==='send'){input.value='';saved(key+':input','');}render(data);}catch(error){if(missing(error))return;status.textContent=errorText(error);status.dataset.error='true';if(id)timer=setTimeout(poll,2000);}finally{busy=false;controls();}}
composer.addEventListener('submit',event=>{event.preventDefault();if(input.value.trim())act('send');});input.addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.shiftKey&&!event.isComposing){event.preventDefault();if(!composer.querySelector('[type=submit]').disabled&&input.value.trim())act('send');}});summarize.addEventListener('click',()=>{if(!summarize.disabled)act('summarize');});stop.addEventListener('click',()=>act('cancel'));retry.addEventListener('click',()=>act('retry'));fresh.addEventListener('click',()=>{if(!window.confirm('重新开始讨论？当前讨论将不再显示，已有项目不会修改。'))return;epoch++;lost=false;clearTimeout(timer);saved(key+':snapshot',null);id=null;current=null;signature='';saved(key,null);feed.replaceChildren();const greeting=document.createElement('div');greeting.className='chat-message assistant';greeting.textContent='说说你的想法，我们一起把需求聊清楚。';feed.append(greeting);brief.textContent='可以开始新的需求讨论。';status.textContent='请输入你的想法。';controls();});
generate.addEventListener('submit',async event=>{event.preventDefault();if(confirm.disabled)return;submitting=true;controls();const output=get('.chat-generation-status');output.textContent='正在启动生成，即将显示进度…';const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),15000);try{const response=await fetch(generate.action,{method:'POST',body:new FormData(generate),headers:{Accept:'application/json'},signal:controller.signal});if(!(response.headers.get('content-type')||'').includes('application/json'))throw new Error(`服务响应异常（HTTP ${response.status}）`);const data=await response.json();if(!response.ok)throw new Error(data.error||'生成任务启动失败。');window.location.assign(data.task_url);}catch(error){if(!missing(error))output.textContent=errorText(error);submitting=false;controls();}finally{clearTimeout(timeout);}});
get('.chat-restore').addEventListener('click',async()=>{
 if(busy||!current?.messages?.length)return;
 busy=true;controls();status.textContent='正在恢复对话副本…';
 try{const data=await request('/requirement-chats/restore',{kind:root.dataset.kind,project_id:root.dataset.project,messages:current.messages});epoch++;render(data);}
 catch(error){status.textContent=errorText(error);status.dataset.error='true';}
 finally{busy=false;controls();}
});
get('.chat-import').addEventListener('change',async event=>{
 const file=event.target.files?.[0];if(!file||busy)return;
 busy=true;controls();status.textContent='正在校验并恢复对话备份…';
 try{
  if(file.size>500000)throw new Error('备份文件过大，请使用本产品导出的对话备份。');
  const content=JSON.parse(await file.text());
  const data=await request('/requirement-chats/restore',{kind:root.dataset.kind,project_id:root.dataset.project,messages:Array.isArray(content)?content:content.messages});
  epoch++;render(data);
 }catch(error){status.textContent=error instanceof SyntaxError?'备份不是有效JSON文件。':errorText(error);status.dataset.error='true';}
 finally{busy=false;event.target.value='';controls();}
});
get('.chat-download').addEventListener('click',()=>{
 if(!current?.messages?.length)return;
 const url=URL.createObjectURL(new Blob([JSON.stringify({kind:root.dataset.kind,messages:current.messages},null,2)],{type:'application/json'}));
 const anchor=document.createElement('a');anchor.href=url;anchor.download='product-agent-conversation.json';anchor.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
});
window.addEventListener('pageshow',()=>{submitting=false;controls();});
id=saved(key);
if(id){
 try{const snapshot=JSON.parse(saved(key+':snapshot')||'null');if(snapshot?.id===id&&Array.isArray(snapshot.messages)){render(snapshot);clearTimeout(timer);}}
 catch(_){}
 busy=true;controls();request('/requirement-chats/'+id).then(render).catch(error=>{
  if(missing(error))return;
  status.textContent=errorText(error)+' 正在自动重新连接…';timer=setTimeout(poll,4000);
 }).finally(()=>{busy=false;controls();});
}else controls();
})();
