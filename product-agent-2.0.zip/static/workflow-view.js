(() => {
  const image=document.getElementById('workflow-image'),viewport=document.getElementById('workflow-viewport');
  let natural=0,scale=1;
  function zoom(value){if(!natural)return;scale=Math.max(.15,Math.min(3,value));image.style.width=(natural*scale)+'px';document.getElementById('zoom-status').textContent=Math.round(scale*100)+'%';}
  function fit(){if(natural)zoom((viewport.clientWidth-20)/natural);}
  if(image){
    image.addEventListener('load',()=>{natural=image.naturalWidth;fit();});
    image.addEventListener('error',()=>{document.getElementById('zoom-status').textContent='流程图加载失败，请刷新页面。';});
    if(image.complete&&image.naturalWidth){natural=image.naturalWidth;fit();}
    document.getElementById('zoom-in').addEventListener('click',()=>zoom(scale*1.2));
    document.getElementById('zoom-out').addEventListener('click',()=>zoom(scale/1.2));
    document.getElementById('zoom-fit').addEventListener('click',fit);
    document.getElementById('flow-select').addEventListener('change',event=>{image.src=image.dataset.baseUrl+'?flow='+encodeURIComponent(event.target.value);image.alt=event.target.options[event.target.selectedIndex].text+'Workflow';viewport.scrollTop=0;viewport.scrollLeft=0;});
  }
})();
