(() => {
  const root=document.getElementById('unfinished-tasks');
  if(!root)return;
  root.querySelectorAll('.delete-task').forEach(button=>button.addEventListener('click',async()=>{
    if(button.disabled)return;
    if(!window.confirm(`删除任务“${button.dataset.name}”？需求和已生成的阶段成果将被删除；进行中的任务会停止后续处理。此操作不能撤销，已保存的历史项目不受影响。`))return;
    const card=button.closest('.task-card'),note=card.querySelector('.delete-feedback');
    button.disabled=true;note.textContent='正在删除…';
    try{
      const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),12000);
      let response;
      try{response=await fetch(button.dataset.url,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':root.dataset.csrf},body:JSON.stringify({confirmed:true}),signal:controller.signal});}finally{clearTimeout(timeout);}
      const data=await response.json();
      if(!response.ok||data.deleted!==true)throw new Error(data.error||'未确认删除成功');
      window.location.reload();
    }catch(error){note.textContent='删除未确认：'+(error.name==='AbortError'?'请求超时，请刷新列表确认后重试':error.message||'连接中断');button.disabled=false;}
  }));
})();
