(() => {
  const form=document.getElementById('creation-form');if(!form)return;
  const input=form.querySelector('[name="requirement"]');
  const status=document.getElementById('creation-status');
  const button=form.querySelector('[type="submit"]');
  try{if(!input.value)input.value=sessionStorage.getItem('product-agent-new-requirement')||'';}catch(_){}
  form.addEventListener('submit',async event=>{
    event.preventDefault();if(!input.value.trim()){status.textContent='请先填写需求内容。';return;}
    try{sessionStorage.setItem('product-agent-new-requirement',input.value);}catch(_){}
    button.disabled=true;status.textContent='正在创建生成任务，即将进入进度页…';
    try{
      const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);
      let response;try{response=await fetch(form.action,{method:'POST',body:new FormData(form),headers:{Accept:'application/json'},signal:controller.signal});}finally{clearTimeout(timer);}
      const type=response.headers.get('content-type')||'';
      if(!type.includes('application/json'))throw new Error(`本地服务返回异常（HTTP ${response.status}），请确认项目服务已启动，端口地址正确。`);
      const data=await response.json();if(!response.ok)throw new Error(data.error||`提交失败（HTTP ${response.status}）`);
      window.location.assign(data.task_url);
    }catch(error){status.textContent=error instanceof TypeError||error.name==='AbortError'?'无法连接本地服务或连接超时，请确认 VS Code 中服务已启动、端口未被占用，再重新提交。需求已保留。':error.message;button.disabled=false;}
  });
  window.addEventListener('pageshow',()=>{button.disabled=false;});
})();
