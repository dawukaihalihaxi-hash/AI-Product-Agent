/* Explicit prototype semantics. No eval, click(), form submission or application calls. */
(() => {
  'use strict';
  const controlSelector='button,a,input,select,textarea,[onclick],[role="button"],[data-pa-navigate],[data-pa-open],[data-pa-close]';
  const panelSelector='[data-pa-page],.view-section[id],.page[id]';
  const dialogSelector='[data-pa-dialog],[role="dialog"],.modal-overlay[id]';
  const label=el=>(el.getAttribute('aria-label')||el.textContent||el.getAttribute('placeholder')||el.tagName).trim().replace(/\s+/g,' ').slice(0,100);
  const resolve=id=>document.getElementById(id)||document.getElementById('view-'+id)||document.getElementById('page-'+id);
  function describe(el) {
    if(el.disabled || el.getAttribute('aria-disabled')==='true')return null;
    if(el.hasAttribute('data-pa-close'))return {type:'CLOSE'};
    const nav=el.getAttribute('data-pa-navigate');
    if(nav){const page=resolve(nav);return page?{type:'NAVIGATE',page}: {type:'UNSUPPORTED',reason:'跳转目标不存在'};}
    const modal=el.getAttribute('data-pa-open');
    if(modal){const dialog=document.getElementById(modal);return dialog?{type:'OVERLAY',dialog,key:modal}: {type:'UNSUPPORTED',reason:'弹窗目标不存在'};}
    const code=(el.getAttribute('onclick')||'').trim();
    const navigate=code.match(/^(?:return\s+)?(?:switchView|switchPage|showPage|showSection)\(\s*(['"])([\w:-]+)\1(?:\s*,[^;]*)?\)\s*;?$/);
    if(navigate){const page=resolve(navigate[2]);return page?{type:'NAVIGATE',page}: {type:'UNSUPPORTED',reason:'跳转目标不存在'};}
    const role=code.match(/^switchRole\(\s*(['"])(admin|customer)\1\s*\)\s*;?$/);
    if(role){const page=resolve(role[2]==='admin'?'dashboard':'customer');if(page)return {type:'NAVIGATE',page,role:role[2]};}
    if(/^(?:closeModal|hideModal|closeDialog)\(\s*\)\s*;?$/.test(code))return {type:'CLOSE'};
    const open=code.match(/^(?:openModal|showModal|showDetail)\(\s*(['"])([^'"]+)\1\s*\)\s*;?$/);
    if(open){
      const dialogs=[...document.querySelectorAll(dialogSelector)];
      const exact=document.getElementById(open[2]);
      const dialog=exact?.matches(dialogSelector)?exact:(dialogs.length===1?dialogs[0]:null);
      if(dialog)return {type:'OVERLAY',dialog,key:open[2],row:code.startsWith('showDetail')?el.closest('tr'):null};
    }
    const href=el.getAttribute('href');
    if(href && /^#[\w:-]+$/.test(href)){const page=resolve(href.slice(1));if(page)return {type:'NAVIGATE',page};}
    if(el.matches(controlSelector))return {type:'UNSUPPORTED',reason:el.getAttribute('data-pa-unsupported')||(['INPUT','SELECT','TEXTAREA'].includes(el.tagName)?'表单是设计图层，播放模式不支持网页输入与筛选':'网页业务脚本未转换，或源页面未定义有效操作')};
    return null;
  }
  const visible=el=>{
    for(let n=el;n && n.nodeType===1;n=n.parentElement){const s=getComputedStyle(n);if(s.display==='none'||s.visibility==='hidden'||n.hidden)return false;}
    return true;
  };
  async function capturePrototype(capture) {
    const controls=[...document.querySelectorAll(controlSelector)];
    const descriptors=new Map(controls.map(el=>[el,describe(el)]));
    const candidates=[...document.querySelectorAll(panelSelector),...[...descriptors.values()].filter(a=>a?.type==='NAVIGATE').map(a=>a.page)];
    // Page attributes on navigation controls describe their destination, not a new screen.
    const panels=[...new Set(candidates.map(el=>descriptors.get(el)?.type==='NAVIGATE'?descriptors.get(el).page:el).filter(el=>!el.matches(controlSelector)))];
    if(panels.length>20)throw new Error('可识别页面超过 20 个，请拆分原型后导出。');
    const dialogs=[...new Set([...document.querySelectorAll(dialogSelector),...[...descriptors.values()].filter(a=>a?.type==='OVERLAY').map(a=>a.dialog)])];
    const originalPanel=panels.find(visible)||panels[0];
    const title=document.getElementById('page-title');
    const ancestors=dialogs.flatMap(dialog=>{const nodes=[];for(let n=dialog.parentElement;n&&n!==document.body;n=n.parentElement)nodes.push(n);return nodes;});
    const changed=[...new Set([...panels,...dialogs,...ancestors,...controls])];
    const attributes=changed.map(el=>({el,style:el.getAttribute('style'),classes:el.getAttribute('class'),hidden:el.getAttribute('hidden')}));
    const titleNodes=title?[...title.childNodes]:[];
    const restore=()=>{
      for(const saved of attributes){for(const [name,value] of [['style',saved.style],['class',saved.classes],['hidden',saved.hidden]]){if(value===null)saved.el.removeAttribute(name);else saved.el.setAttribute(name,value);}}
      if(title)title.replaceChildren(...titleNodes);
    };
    const screens=panels.length?panels:[null],frames=[],unsupported=new Map(),warnings=new Map(),overlays=new Map();
    let totalElements=0;
    const screenIds=new Map(),usedIds=new Set();
    panels.forEach((page,index)=>{
      const base='screen:'+(page.id||page.getAttribute('data-pa-page')||'page-'+(index+1));
      let id=base,suffix=2;while(usedIds.has(id))id=base+':'+suffix++;
      usedIds.add(id);screenIds.set(page,id);
    });
    const screenId=page=>page?screenIds.get(page):'screen:current';
    const addWarning=(code,detail)=>{const w=warnings.get(code)||{code,count:0,examples:[]};w.count++;if(w.examples.length<5&&!w.examples.includes(detail))w.examples.push(detail);warnings.set(code,w);};
    const actionFor=el=>{
      const a=descriptors.get(el)||describe(el);
      if(!a)return null;
      if(a.type==='NAVIGATE')return {type:'NAVIGATE',target:screenId(a.page)};
      if(a.type==='CLOSE')return {type:'CLOSE'};
      if(a.type==='OVERLAY'){
        const key='overlay:'+a.dialog.id+':'+a.key;
        if(!overlays.has(key))overlays.set(key,{...a,id:key,label:label(el)});
        return {type:'OVERLAY',target:key};
      }
      const text=label(el),key=text+' — '+a.reason;
      unsupported.set(key,{label:text,reason:a.reason});
      return {type:'OVERLAY',target:'overlay:unsupported',unsupported:true};
    };
    const collect=async(root,id,name,kind)=>{
      const scene=await capture({root:root||document.body,actionFor,interactive:true});
      totalElements+=scene.elementCount;
      if(totalElements>24000)throw new Error('全部画面超过 24000 个元素，请拆分原型后导出。');
      for(const warning of scene.warnings||[])for(const example of warning.examples)addWarning(warning.code,example);
      frames.push({id,name,kind,width:scene.width,height:scene.height,background:scene.background,nodes:scene.nodes});
      if(frames.length>40)throw new Error('页面与弹窗超过 40 个，请拆分后导出。');
    };
    try {
      for(const page of screens){
        restore();
        for(const dialog of dialogs)dialog.style.setProperty('display','none','important');
        for(const panel of panels){panel.classList.toggle('active',panel===page);panel.hidden=false;panel.style.removeProperty('display');if(panel!==page)panel.style.setProperty('display','none','important');else if(getComputedStyle(panel).display==='none')panel.style.setProperty('display','block','important');}
        let pageName=page?.getAttribute('data-pa-name')||page?.id||'当前画面';
        for(const [el,a] of descriptors){if(a?.type==='NAVIGATE'){el.classList.toggle('active',a.page===page);if(a.page===page && !a.role)pageName=label(el);}}
        if(title)title.textContent=pageName;
        await collect(null,screenId(page),pageName,'screen');
      }
      for(const entry of overlays.values()){
        restore();
        const dialog=entry.dialog;
        for(let n=dialog;n&&n!==document.body;n=n.parentElement){n.hidden=false;if(getComputedStyle(n).display==='none')n.style.setProperty('display',n===dialog?'flex':'block','important');}
        const content=dialog.querySelector('[data-pa-dialog-content]')||dialog.querySelector('#modal-content');
        const oldChildren=content?[...content.childNodes]:[];
        try {
          if(content && entry.row){
            const headers=[...entry.row.closest('table').querySelectorAll('th')];
            const cells=[...entry.row.querySelectorAll('td')];
            content.replaceChildren();
            cells.forEach((cell,index)=>{if(cell.querySelector('button')||!headers[index])return;const line=document.createElement('p');line.textContent=label(headers[index])+'：'+label(cell);content.appendChild(line);});
            addWarning('dialog-data','详情弹窗以对应表格行生成静态演示数据，不包含后台查询。');
          } else if(content && !content.textContent.trim())addWarning('dialog-data',entry.label+'：源弹窗没有静态内容，需自行补充。');
          // Keep close controls, but do not recursively discover additional dialogs.
          await collect(dialog,entry.id,entry.label+' · 弹窗','overlay');
        } finally {if(content)content.replaceChildren(...oldChildren);restore();}
      }
      if(unsupported.size){
        const box=document.createElement('div');
        box.style.cssText='position:fixed;left:0;top:0;width:560px;min-height:260px;padding:32px;background:white;color:#1f2937;border:1px solid #cbd5e1;border-radius:12px;font:16px/1.6 Arial,sans-serif';
        const heading=document.createElement('h2');heading.textContent='此操作尚未转换为 Figma 交互';
        const body=document.createElement('p');body.textContent='该按钮的业务逻辑或表单输入未转换。这是限制提示，并不代表操作已成功。可回到 HTML 原型使用，或在 Figma 中手动补充演示流程。';
        const close=document.createElement('button');close.setAttribute('data-pa-close','');close.textContent='关闭提示';close.style.cssText='padding:10px 20px;background:#2563eb;color:white;border:0;border-radius:6px';
        box.append(heading,body,close);document.body.appendChild(box);
        try{await collect(box,'overlay:unsupported','未转换操作说明','overlay');}finally{box.remove();}
        for(const item of unsupported.values())addWarning('unsupported-action',item.label+'：'+item.reason);
      }
      addWarning('prototype-scope','已连接可识别的页面跳转、弹窗与关闭；其他操作显示限制提示，不模拟业务成功。');
      if(!panels.length)addWarning('missing-pages','未找到可识别的独立页面，只导出当前画面；不会虚构其他页面。');
      const first=frames.find(f=>f.id===screenId(originalPanel))||frames[0];
      return {schema:'product-agent/figma-scene',version:2,exporterVersion:'2026-10-30-navigation-2',createdAt:new Date().toISOString(),viewport:{width:innerWidth,height:innerHeight},width:first.width,height:first.height,nodes:first.nodes,background:first.background,
        startFrameId:first.id,frames,unsupportedActions:[...unsupported.values()],warnings:[...warnings.values()],elementCount:totalElements};
    } finally {restore();}
  }
  window.productAgentInteractions={describe,capturePrototype};
})();
