(() => {
  'use strict';
  document.querySelectorAll('.project').forEach(row => {
    const title=row.querySelector('.project-name'),edit=row.querySelector('.rename-project'),form=row.querySelector('.rename-form');
    const input=row.querySelector('.rename-input'),cancel=row.querySelector('.cancel-rename'),save=form.querySelector('[type="submit"]');
    const status=row.querySelector('.rename-status');let saving=false;
    const close=()=>{if(saving)return;form.hidden=true;title.hidden=false;edit.hidden=false;edit.focus();};
    edit.addEventListener('click',()=>{status.textContent='';input.value=title.textContent;title.hidden=true;edit.hidden=true;form.hidden=false;input.focus();input.select();});
    cancel.addEventListener('click',close);
    input.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();close();}});
    form.addEventListener('submit',async event=>{
      event.preventDefault();if(saving)return;
      const name=input.value.trim();if(!name){status.textContent='请填写项目名称。';input.focus();return;}
      saving=true;save.disabled=true;cancel.disabled=true;input.disabled=true;status.textContent='正在保存…';
      let success=false;
      try{
        const response=await fetch(`/projects/${encodeURIComponent(row.dataset.projectId)}/rename`,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrfToken},body:JSON.stringify({name})});
        const data=await response.json();if(!response.ok)throw new Error(data.error||'保存失败，请重试。');
        const actual=data.project.name;title.textContent=actual;edit.setAttribute('aria-label','重命名 '+actual);
        row.querySelector('.delete-project').dataset.name=actual;row.querySelector('.actions').setAttribute('aria-label',actual+'的操作');
        // Storage can be unavailable in some browsers; server persistence still succeeded.
        try{localStorage.setItem('product-agent-history-change',String(Date.now()));}catch(_){}
        status.textContent='';success=true;
      }catch(error){status.textContent=error.message||'保存失败，请重试。';}
      finally{saving=false;save.disabled=false;cancel.disabled=false;input.disabled=false;}
      if(success)close();else input.focus();
    });
  });
})();
