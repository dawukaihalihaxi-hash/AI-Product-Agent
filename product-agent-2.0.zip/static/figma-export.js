(() => {
  'use strict';
  const script=document.currentScript, frame=document.getElementById('prototype');
  const button=document.getElementById('capture'),download=document.getElementById('download');
  const resize=document.getElementById('resize'),interactive=document.getElementById('interactive');
  let scene=null,pending=null,timer,probeTimer,probeExpiry,ready=false,downloadAfterCapture=false,queued=false;
  const status=text=>{document.getElementById('status').textContent=text;document.getElementById('download-status').textContent=text;};
  const busy=value=>{button.disabled=value||!ready;download.disabled=value;resize.disabled=value;interactive.disabled=value;download.textContent=value?'正在生成，请稍候…':'生成并下载 Figma 文件';};
  const reset=()=>{scene=null;document.getElementById('warnings').textContent='生成后在此显示。';};
  const save=()=>{
    const url=URL.createObjectURL(new Blob([JSON.stringify(scene,null,2)],{type:'application/json'}));
    const a=document.createElement('a');a.href=url;a.download=`figma-scene-${script.dataset.projectId}.json`;document.body.appendChild(a);a.click();setTimeout(()=>{a.remove();URL.revokeObjectURL(url);},10000);
  };
  function capture(andDownload){
    if(pending)return;
    if(!ready){queued=andDownload;status('正在等待原型加载，加载完成后将自动生成并下载…');probe();return;}
    queued=false;reset();downloadAfterCapture=andDownload;pending=crypto.randomUUID();busy(true);status('正在生成 Figma 文件，完成后'+(andDownload?'会自动下载。':'可以直接下载。'));
    frame.contentWindow.postMessage({type:'product-agent:capture',nonce:pending,interactive:interactive.checked},'*');
    clearTimeout(timer);timer=setTimeout(()=>{pending=null;downloadAfterCapture=false;busy(false);status('生成超时，请点击“生成并下载 Figma 文件”重试。');},60000);
  }
  function probe(){
    clearInterval(probeTimer);clearTimeout(probeExpiry);
    const ping=()=>frame.contentWindow.postMessage({type:'product-agent:probe'},'*');
    probeTimer=setInterval(ping,300);ping();
    probeExpiry=setTimeout(()=>{clearInterval(probeTimer);if(!ready){queued=false;busy(false);status('原型加载失败或尚未就绪，请刷新页面后重试。');}},15000);
  }
  frame.addEventListener('load',()=>{ready=false;pending=null;clearTimeout(timer);reset();busy(false);probe();});
  resize.onclick=()=>{
    const w=Number(document.getElementById('width').value),h=Number(document.getElementById('height').value);
    if(!Number.isInteger(w)||w<320||w>3840||!Number.isInteger(h)||h<480||h>2160){status('宽度需为 320–3840，高度需为 480–2160 的整数。');return;}
    reset();frame.width=w;frame.height=h;status('尺寸已调整，点击“生成并下载 Figma 文件”即可。');
  };
  interactive.onchange=reset;
  button.onclick=()=>capture(false);
  download.onclick=()=>capture(true);
  window.addEventListener('message',event=>{
    if(event.source!==frame.contentWindow)return;
    if(event.data?.type==='product-agent:ready'){
      const first=!ready;ready=true;clearInterval(probeTimer);clearTimeout(probeExpiry);busy(Boolean(pending));
      if(queued)capture(true);else if(first&&!pending)status('原型已就绪，可直接点击“生成并下载 Figma 文件”。');
      return;
    }
    if(!pending||event.data?.nonce!==pending||!['product-agent:scene','product-agent:error'].includes(event.data.type))return;
    clearTimeout(timer);pending=null;busy(false);
    if(event.data.type==='product-agent:error'){downloadAfterCapture=false;status('生成失败：'+event.data.error+'。可以点击下载按钮重试。');return;}
    scene=event.data.scene;
    if(scene?.schema!=='product-agent/figma-scene'||![1,2].includes(scene.version)||!Array.isArray(scene.nodes)||(scene.version===2&&!Array.isArray(scene.frames))){scene=null;downloadAfterCapture=false;status('生成的数据格式无效，请刷新后重试。');return;}
    if(scene.version===2&&new Set(scene.frames.map(item=>item.id)).size!==scene.frames.length){
      scene=null;downloadAfterCapture=false;status('导出数据含重复页面编号，已停止下载。请按 Command + Shift + R 强制刷新此页，再重新生成；不要继续使用旧 JSON。');return;
    }
    scene.project={id:script.dataset.projectId,name:script.dataset.projectName};
    const summary=scene.version===2?`${scene.frames.filter(f=>f.kind==='screen').length} 个页面、${scene.frames.filter(f=>f.kind==='overlay').length} 个弹窗`:'单画面静态设计（没有播放交互）';
    document.getElementById('warnings').textContent=(scene.warnings||[]).map(w=>`• ${w.code}（${w.count}）：${w.examples.join('；')}`).join('\n')+(scene.unsupportedActions?.length?'\n\n未转换操作清单：\n'+scene.unsupportedActions.map(a=>`• ${a.label}：${a.reason}`).join('\n'):'');
    if(downloadAfterCapture){downloadAfterCapture=false;save();status(`已生成 ${summary}，已发起 JSON 下载。请在浏览器下载列表中查找，再用交互版插件导入。`);}
    else status(`已生成 ${summary}。点击“生成并下载 Figma 文件”即可下载最新画面。`);
  });
  busy(false);probe();
})();
