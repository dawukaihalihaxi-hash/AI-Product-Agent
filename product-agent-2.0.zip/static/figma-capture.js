/* Product Agent scene format v1. Runs inside the sandboxed prototype only. */
(() => {
  'use strict';
  const round = v => Math.round(v * 100) / 100;
  const size = v => Math.max(0.01, Math.min(100000, round(v)));
  function color(value) {
    const match = value.match(/^rgba?\(([^)]+)\)$/);
    if (!match) return null;
    const parts = match[1].split(/[,\s/]+/).map(Number);
    return {r: parts[0] / 255, g: parts[1] / 255, b: parts[2] / 255, a: parts[3] ?? 1};
  }
  async function capture(options = {}) {
    await Promise.race([document.fonts.ready, new Promise(resolve => setTimeout(resolve, 3000))]);
    // Resolve finite entrance animations so a fast export does not capture faded text.
    for (const animation of document.getAnimations()) {
      try { if (Number.isFinite(animation.effect.getComputedTiming().endTime)) animation.finish(); else animation.pause(); } catch (_) {}
    }
    await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    const warnings = new Map();
    const warn = (code, detail) => {
      const entry = warnings.get(code) || {code, count: 0, examples: []};
      entry.count++;
      if (entry.examples.length < 3 && !entry.examples.includes(detail)) entry.examples.push(detail);
      warnings.set(code, entry);
    };
    let count = 0;
    const name = el => `${el.tagName.toLowerCase()}${el.id ? '#' + el.id : ''}${typeof el.className === 'string' && el.className ? '.' + el.className.trim().split(/\s+/).slice(0,2).join('.') : ''}`.slice(0,120);
    const box = rect => ({x: round(rect.x), y: round(rect.y), width: size(rect.width), height: size(rect.height)});
    function textNode(text, rect, style, parentRect, label) {
      if (!text || !text.trim() || rect.width <= 0 || rect.height <= 0) return null;
      const fontSize = parseFloat(style.fontSize) || 14;
      return {type: 'TEXT', name: label || text.slice(0,60), ...box(rect),
        x: round(rect.x-parentRect.x), y: round(rect.y-parentRect.y), text,
        fontFamily: style.fontFamily, fontSize, fontWeight: parseInt(style.fontWeight) || 400,
        italic: style.fontStyle === 'italic', color: color(style.color),
        lineHeight: parseFloat(style.lineHeight) || fontSize * 1.2,
        letterSpacing: parseFloat(style.letterSpacing) || 0,
        textAlign: ['center','right','justify'].includes(style.textAlign) ? style.textAlign : 'left',
        decoration: style.textDecorationLine};
    }
    function walk(el, parentRect, depth=0) {
      if (depth > 100 || ++count > 12000) throw new Error('页面超过导出上限（12000 元素或 100 层），请简化后重试');
      if (['SCRIPT','STYLE','LINK','META','HEAD','NOSCRIPT','TEMPLATE','OPTION'].includes(el.tagName)) return [];
      const style = getComputedStyle(el), rect = el.getBoundingClientRect();
      if (style.display === 'none' || style.visibility === 'hidden' || style.visibility === 'collapse' || Number(style.opacity) === 0) return [];
      if (style.display === 'contents' || (rect.width === 0 && rect.height === 0)) {
        return [...el.children].flatMap(child => walk(child,parentRect,depth+1));
      }
      const label = name(el);
      if (style.transform !== 'none') warn('transform', label + ': 仅保留变换后的包围框');
      if (style.filter !== 'none' || style.backdropFilter && style.backdropFilter !== 'none') warn('filter', label);
      if (style.backgroundImage !== 'none') warn('background-image', label + ': 渐变或背景图片未转换');
      if (style.boxShadow !== 'none') warn('shadow', label + ': 阴影暂未转换');
      if (style.mixBlendMode !== 'normal') warn('blend-mode', label);
      if (style.animationName !== 'none') warn('animation', label + ': 仅导出当前状态');
      for (const pseudo of ['::before','::after']) {
        const content=getComputedStyle(el,pseudo).content;
        if (content && !['none','normal','""'].includes(content)) warn('pseudo-element', label+pseudo);
      }
      const scrollX=['auto','scroll'].includes(style.overflowX) && el.scrollWidth>el.clientWidth+2;
      const scrollY=['auto','scroll'].includes(style.overflowY) && el.scrollHeight>el.clientHeight+2;
      const scrollDirection=scrollX?(scrollY?'BOTH':'HORIZONTAL'):(scrollY?'VERTICAL':'NONE');
      if(scrollDirection!=='NONE')warn('scroll-container',label + ': 将转换为 Figma 原生滚动，需新版插件；浏览器滚动条样式不转换');
      const node = {action:options.actionFor ? options.actionFor(el) : undefined, type:'FRAME', name:label, ...box(rect), x:round(rect.x-parentRect.x), y:round(rect.y-parentRect.y),
        background:color(style.backgroundColor), opacity:Number(style.opacity),
        radii:[style.borderTopLeftRadius,style.borderTopRightRadius,style.borderBottomRightRadius,style.borderBottomLeftRadius].map(v => v.endsWith('%') ? Math.min(rect.width,rect.height)*parseFloat(v)/100 : parseFloat(v)||0),
        scrollDirection,
        clip: ['hidden','clip','auto','scroll'].includes(style.overflowX) || ['hidden','clip','auto','scroll'].includes(style.overflowY),
        borders:['Top','Right','Bottom','Left'].map(side => ({width:parseFloat(style['border'+side+'Width'])||0, color:color(style['border'+side+'Color']), style:style['border'+side+'Style']})), children:[]};
      if (el.tagName.toLowerCase() === 'svg') {
        warn('svg',label + ': 本版本未转换 SVG，保留位置占位');
        return [node];
      }
      if (['IMG','CANVAS','VIDEO','IFRAME'].includes(el.tagName)) {
        warn('media', label + ': 未转换媒体，仅保留占位框');
        return [node];
      }
      if (['INPUT','TEXTAREA','SELECT'].includes(el.tagName)) {
        const type=el.type;
        if (el.tagName === 'INPUT' && ['checkbox','radio','range','color','file','date','time','password'].includes(type)) {
          warn('native-control',label + ': 原生控件仅近似外观，不导出密码值');
          if (['checkbox','radio'].includes(type)) {
            node.background = color(el.checked ? 'rgb(37,99,235)' : 'rgb(255,255,255)');
            node.borders = node.borders.map(b => ({width:1,color:color('rgb(100,116,139)'),style:'solid'}));
            if (type==='radio') node.radii=[rect.width/2,rect.width/2,rect.width/2,rect.width/2];
          }
          return [node];
        }
        let text = el.tagName === 'SELECT' ? el.selectedOptions[0]?.text || '' : el.value || el.placeholder || '';
        const left=parseFloat(style.paddingLeft)||0, right=parseFloat(style.paddingRight)||0;
        const textRect={x:rect.x+left+node.borders[3].width,y:rect.y+(rect.height-(parseFloat(style.lineHeight)||parseFloat(style.fontSize)*1.2))/2,width:Math.max(1,rect.width-left-right-4),height:parseFloat(style.lineHeight)||parseFloat(style.fontSize)*1.2};
        if (el.tagName==='TEXTAREA') textRect.y=rect.y+(parseFloat(style.paddingTop)||0)+node.borders[0].width;
        const t=textNode(text,textRect,style,rect,'表单内容');
        if(t) { if(!el.value && el.placeholder) {t.color=color(getComputedStyle(el,'::placeholder').color)||t.color;} node.children.push(t); }
        warn('form-control',label + ': 表单转换为可编辑图形与文字，无网页输入行为');
        return [node];
      }
      if (style.textTransform !== 'none') warn('text-transform',label + ': 文本保留原文');
      for (const child of el.childNodes) {
        if(child.nodeType===Node.TEXT_NODE) {
          const range=document.createRange();range.selectNodeContents(child);
          let text=child.textContent;
          if(!['pre','pre-wrap','break-spaces'].includes(style.whiteSpace)) text=text.replace(/\s+/g,' ').trim();
          const t=textNode(text,range.getBoundingClientRect(),style,rect);
          if(t) node.children.push(t);
        } else if(child.nodeType===Node.ELEMENT_NODE) node.children.push(...walk(child,rect,depth+1));
      }
      // Children are measured at the current DOM scroll position; export from origin.
      for(const child of node.children){child.x=round(child.x+(el.scrollLeft||0));child.y=round(child.y+(el.scrollTop||0));}
      return [node];
    }
    warn('layout','按固定宽度导出绝对位置，不自动生成 Auto Layout 或响应式规则。');
    if(!options.interactive && document.querySelector('script, [onclick], [onchange]')) warn('interaction','JavaScript、悬停和业务交互不转换；隐藏页面需切换后分别导出');
    if(document.querySelector('[style*="z-index"]') || [...document.querySelectorAll('*')].some(el => getComputedStyle(el).zIndex !== 'auto')) warn('stacking','复杂层叠顺序按 DOM 层级近似，可能需要手动调整');
    const root=options.root||document.body;
    const rect=root.getBoundingClientRect();
    const isBody=root===document.body;
    const rootRect=isBody?{x:0,y:0}:rect;
    const nodes=walk(root,rootRect);
    return {schema:'product-agent/figma-scene',version:1,createdAt:new Date().toISOString(),
      viewport:{width:innerWidth,height:innerHeight}, width:size(isBody?Math.max(innerWidth,document.documentElement.scrollWidth):rect.width),height:size(isBody?Math.max(innerHeight,document.documentElement.scrollHeight):rect.height),
      background:color(getComputedStyle(document.documentElement).backgroundColor),nodes,warnings:[...warnings.values()],elementCount:count};
  }
  window.addEventListener('message', async event => {
    if(event.source!==parent)return;
    if(event.data?.type==='product-agent:probe'){parent.postMessage({type:'product-agent:ready'},'*');return;}
    if(event.data?.type!=='product-agent:capture' || typeof event.data.nonce!=='string')return;
    try {parent.postMessage({type:'product-agent:scene',nonce:event.data.nonce,scene:await (event.data.interactive ? window.productAgentInteractions.capturePrototype(capture) : capture())},'*');}
    catch(error) {parent.postMessage({type:'product-agent:error',nonce:event.data.nonce,error:error.message},'*');}
  });
  // Public for browser-based regression tests, not used to access the parent document.
  window.productAgentCapture=capture;
})();
