# 备用模型与自动切换

已实现 OpenAI Chat Completions 兼容接口的主备切换。备用默认关闭，原有模型配置、本地 5001、历史项目和断点续生成继续可用。仅本地更新；线上要另行部署代码并配置备用环境变量。

## 本地可视化配置（无需修改代码）

打开 http://127.0.0.1:5001/settings/backup-model ，填写硅基流动 API Key，点击“验证并启用备用模型”。页面固定使用 `XingChenAGI/Xing4.0-29B`；只有短请求返回完整文本，才会将配置保存到本机 `.model-fallback.json` 并立即生效。该文件权限为仅当前用户可读写，已加入 Git 忽略规则；发布、分享或备份源码时也必须排除它。

密钥不会回显或加入项目导出，验证失败保留原配置。页面仅允许本机回环访问，Render 云端禁用。若启动环境中显式设置了 `MODEL_FALLBACK_ENABLED`，以环境变量为准，页面会提示移除冲突配置。

启用代表允许切换时将本阶段所需需求、PRD、原型内容发送到硅基流动。若只配置本地服务，线上版本不会自动获得这些设置。

## 环境变量方案：OpenRouter 免费备用

官方说明：
- https://openrouter.ai/docs/guides/routing/routers/free-router
- https://openrouter.ai/collections/free-models

`openrouter/free` 只路由到免费模型，不会替你自动升级成付费模型。免费服务仍会限流，模型选择及输出质量可能变化，不能保证完整原型转换成功。官方目前公布免费变体通常限制 20 次/分钟、未充值账户 50 次/天，失败请求也可能占用额度；以账户控制台实时规则为准。

需要用户自己注册并创建 OpenRouter API Key；不要把密钥发到聊天、放在网页前端或提交到 GitHub。

通过启动程序的环境变量设置以下项目，参考 `.env.fallback.example`：

| 变量 | 值 |
| --- | --- |
| MODEL_FALLBACK_ENABLED | 1（启用），0（关闭） |
| MODEL_FALLBACK_API_KEY | 用户自己的备用服务 API Key |
| MODEL_FALLBACK_BASE_URL | https://openrouter.ai/api/v1/chat/completions |
| MODEL_FALLBACK_NAME | openrouter/free |
| MODEL_FALLBACK_MAX_TOKENS | 30000，可按具体模型输出上限调整 |
| MODEL_FALLBACK_ALLOW_PAID | 0（保持免费） |

`.env.fallback.example` 是配置参考，程序不会自动加载该文件。在本地启动终端配置环境变量后重新启动服务；Render 上则在 Environment 中配置。备用只使用自己的密钥，绝不把智谱密钥发给另一个服务。

## 切换规则

1. 优先调用现有主模型。
2. 若主模型返回 429、500、502、503、504，或连接/读取超时，且备用已启用，则自动向备用服务提交本阶段的同一提示词。需求、PRD 和已有 HTML 可能包含在提示词中；启用备用意味着允许这些内容发送到所配置的服务，请先了解其数据政策。
3. 只切换当前失败的步骤，已通过检查点的阶段不重做；PRD、原型、Workflow 仍一起校验并保存正式版本。
4. 400、401、403、404 这类参数、认证或权限错误不自动切换，防止掩盖配置问题。内容为空、结构异常、长度截断也不会被标成成功；可修正后从失败步骤继续。
5. 两个接口都失败时保留任务与阶段成果。调用记录会显示使用的主/备用模型、切换和 HTTP 错误；不保存密钥和完整 API 错误正文。
6. 停止或删除任务后，不再进入备用调用或保存后续结果。已发出的请求无法保证从服务商侧立即取消。
7. 启用备用时，主模型读取等待为 60 秒，备用为最多 130 秒，总预算保持在任务看门狗之内。未启用备用时保留原来的 180 秒读取等待。

## 其他兼容接口

可配置硅基流动等兼容接口，例如 `https://api.siliconflow.cn/v1/chat/completions`。模型名称、密钥和输出上限必须使用该服务自己的配置。费用取决于你选择的模型，本程序不能把它自动变成免费；应先在官方定价页和账户中确认。

- 硅基流动价格：https://www.siliconflow.cn/pricing
- Gemini 也有部分免费额度，但接口差异、地区可用性和数据使用条款需要另行确认；本次未接原生 Gemini API。

免费服务不保证容量。演示前请用实际账户完成一次真实 PRD/HTML/Workflow 生成，保存并下载可离线展示的结果。

## 测试和发布

`python3 -m unittest discover -s tests -q`

已覆盖主模型成功、429 后备用成功、两个都失败、超时与连接失败、认证错误不切换、空/截断输出、密钥隔离、线程隔离、停止任务和原型阶段切换保存等情况。尚未使用用户的新备用密钥完成真实服务验证。

下次发布必须包含 `llm.py`、`model_routing.py`、`local_model_settings.py`、`refinement_jobs.py` 和对应模板、测试与文档；本地密钥和环境文件不上传。
