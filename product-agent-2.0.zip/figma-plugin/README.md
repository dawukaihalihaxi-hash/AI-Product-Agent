# Product Agent Importer · 交互版

将 Product Agent 导出的设计数据转换为 Figma 原生 Frame、Text、Rectangle，并为可识别操作创建 ON_CLICK 原型连线。无需构建、API Key 或付费转换服务；插件无网络访问。

## 更新与使用

1. 刷新 Product Agent，点击项目的“导出至 Figma”。
2. 保持勾选“包含全部可识别页面和基础交互”，直接点击“生成并下载 Figma 文件”。系统会等待原型就绪，生成并下载 JSON，同时列出页面数和未转换操作。
3. 下载**新生成的 JSON**。旧版 JSON 不含多页面和交互，更新插件不会改变旧 JSON 或已导入的图层。
4. 如果 Figma 插件加载自 `product_agent/2.0/figma-plugin/manifest.json`，关闭插件再重开即可读取更新后的代码。如果加载的是下载目录里的旧副本，请下载新插件 ZIP，解压并重新通过桌面端 Plugins → Development → Import plugin from manifest… 导入。
5. 插件标题应显示“Product Agent 原型导入 · 交互版”。选择新版 JSON，点击“导入为可编辑图层”。
6. 完成后会显示页面数、图层数和点击交互数。插件会选择本次导入的起始画面并添加播放起点。选中这个新画面，再点击 Figma 右上角播放；不要继续播放旧导入的静态画面。
7. 试用菜单跳转、详情弹窗和关闭按钮。导入后的文件正常同步后，可用网页版继续编辑或播放。

不要将 HTML、JSON 或 ZIP 拖到 Figma 普通文件导入入口。本功能不直接生成 .fig。

## 可转换的交互

- 多页面容器：带唯一 id 的 `.view-section`、`.page` 或 `[data-pa-page]`。
- 当前菜单指向当前页面时不创建无效连线；其他菜单跳转到同页的其他顶层画面。
- 页面跳转：`data-pa-navigate="目标id"`、指向有效页面的 `href="#目标id"`，或简单的 `switchView/switchPage/showPage/showSection('目标', ...)`。
- 已有餐饮原型的 `switchRole('admin'/'customer')` 映射到对应演示页面，不包含真实权限逻辑。
- 弹窗打开：`data-pa-open="弹窗id"`，或可明确对应到弹窗的 `openModal/showModal/showDetail('目标')`。
- 弹窗关闭：`data-pa-close`、`closeModal()`、`hideModal()`、`closeDialog()`。
- 表格行“详情”可用对应行数据生成静态详情展示，导出报告会注明不是后台查询。
- 未转换的按钮和表单会连接到明确的限制说明弹窗；该提示不代表操作已执行成功。对应图层名称标记 `[未转换操作]`。

导出不会自动点击业务按钮，也不执行待转换的 onclick 脚本；只读取语义并临时切换展示状态，结束或失败后恢复原预览状态。原始 HTML 文件不修改。

## 设计与业务限制

文字、颜色、边框、圆角、卡片、按钮、表格与表单外观仍为可编辑图层。固定宽度布局不会自动转成 Auto Layout 或响应式规则。

以下不会自动转换为可执行的 Figma 业务逻辑：真实文本输入、查询/筛选、提交表单、导出文件、状态更新、数据持久化、后台请求。点击时显示限制说明，必要时在 Figma 中自行补充演示流程，或使用原始 HTML。

源文件没有实现的页面无法自动补出。无效的 `href="#"` 只显示限制说明，不虚构目标页面。

渐变、阴影、滤镜、伪元素、SVG/媒体等设计限制沿用前版；字体匹配、复杂层叠及换行需人工核对。详情弹窗未包含静态内容或表格行数据时会提示需要补充。

## 格式与上限

- v1：单画面静态设计，兼容旧导出，导入时明确提示没有播放交互。
- v2：多个 `frames`、`startFrameId`、节点 `action`；动作仅支持 NAVIGATE、OVERLAY、CLOSE。
- 最多 20 个页面、40 个总画面、24000 个累计元素。导入最多 24000 个节点、110 层、20 MB JSON。
- 目标不存在、交互类型无效、连接写入失败均中止导入并撤回本次创建的全部画面，保留已有流程。

## 代码测试

- 后端回归：`python3 -m unittest discover -s tests -v`
- 多页面/交互回归：`node tests/test_interactions.cjs`。可设置 PRODUCT_AGENT_HISTORY 指向历史项目目录。使用 DOM 模型与 Figma API 替身，不启动浏览器或 Figma。
- `tests/test_figma.cjs` 为可选浏览器集成测试，需要 Playwright；本次按用户要求不执行效果验证。

本次实际播放效果由用户验证，不将模型测试表述为真实 Figma 播放验收。
