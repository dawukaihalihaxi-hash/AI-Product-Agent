/* No build step or network calls. Import only the explicit v1/v2 scene formats. */
'use strict';
figma.showUI(__html__, {width: 460, height: 560});
let importing = false;
const finite = (v, min, max) => typeof v === 'number' && Number.isFinite(v) && v >= min && v <= max;
function validateScene(scene) {
  if (!scene || scene.schema !== 'product-agent/figma-scene' || ![1,2].includes(scene.version)) throw new Error('请选择 Product Agent 导出的 v1/v2 JSON 文件，不能选择 HTML、ZIP 或其他 JSON。');
  if (!finite(scene.width, 0.01, 100000) || !finite(scene.height, 0.01, 100000) || !Array.isArray(scene.nodes)) throw new Error('画布尺寸或节点格式无效');
  let total=0;
  function visit(node, depth) {
    if (++total > 24000 || depth > 110) throw new Error('节点数量或层级超限');
    if (!node || !['FRAME','TEXT'].includes(node.type) || !finite(node.x,-1000000,1000000) || !finite(node.y,-1000000,1000000) || !finite(node.width,0.01,100000) || !finite(node.height,0.01,100000)) throw new Error('节点类型、坐标或尺寸无效');
    const colors=[node.background,node.color,...(node.borders||[]).map(b=>b.color)].filter(Boolean);
    if(colors.some(c=>!['r','g','b','a'].every(k=>finite(c[k],0,1)))) throw new Error('颜色数据无效');
    if(node.type==='TEXT') {
      if(typeof node.text!=='string' || node.text.length>200000 || !finite(node.fontSize,1,1000) || !finite(node.lineHeight,1,5000) || !finite(node.letterSpacing,-1000,1000)) throw new Error('文字数据无效');
    } else {
      if(node.scrollDirection!==undefined && !['NONE','HORIZONTAL','VERTICAL','BOTH'].includes(node.scrollDirection))throw new Error('滚动方向无效');
      if(!Array.isArray(node.children) || !Array.isArray(node.radii) || node.radii.length!==4 || node.radii.some(r=>!finite(r,0,100000)) || !finite(node.opacity,0,1)) throw new Error('容器数据无效');
      if(!Array.isArray(node.borders) || node.borders.length!==4 || node.borders.some(b=>!finite(b.width,0,10000))) throw new Error('边框数据无效');
      node.children.forEach(child=>visit(child,depth+1));
    }
  }
  if(scene.version===1)scene.nodes.forEach(node=>visit(node,0));
  else {
    if(!Array.isArray(scene.frames)||!scene.frames.length||scene.frames.length>40)throw new Error('多页面数据无效或超过 40 个画面');
    const ids=new Map();
    for(const frame of scene.frames){
      if(!frame || typeof frame.id!=='string' || !frame.id || frame.id.length>256 || ids.has(frame.id) || !['screen','overlay'].includes(frame.kind) || !finite(frame.width,.01,100000) || !finite(frame.height,.01,100000) || !Array.isArray(frame.nodes))throw new Error('画面编号、类型或尺寸无效');
      ids.set(frame.id,frame);
    }
    if(ids.get(scene.startFrameId)?.kind!=='screen')throw new Error('播放起始页无效');
    function actions(nodes,frame){
      for(const node of nodes){
        if(node.action){
          const a=node.action;
          if(!['NAVIGATE','OVERLAY','CLOSE'].includes(a.type))throw new Error('不支持的交互类型');
          if(a.type==='CLOSE' && frame.kind!=='overlay')throw new Error('关闭交互只能用于弹窗');
          if(a.type!=='CLOSE' && ids.get(a.target)?.kind!==(a.type==='NAVIGATE'?'screen':'overlay'))throw new Error('交互目标缺失或类型不符');
        }
        actions(node.children||[],frame);
      }
    }
    for(const frame of scene.frames){frame.nodes.forEach(node=>visit(node,0));actions(frame.nodes,frame);}
  }
  return total;
}
const paint = c => c && c.a>0 ? [{type:'SOLID',color:{r:c.r,g:c.g,b:c.b},opacity:c.a}] : [];
function styleWeight(style) {
  const s=style.toLowerCase();
  if(s.includes('black')||s.includes('heavy'))return 900;
  if(s.includes('extra bold')||s.includes('extrabold'))return 800;
  if(s.includes('semi')||s.includes('demi'))return 600;
  if(s.includes('bold'))return 700;
  if(s.includes('medium'))return 500;
  if(s.includes('light'))return 300;
  return 400;
}
async function importScene(scene) {
  validateScene(scene);
  const notes=new Map();
  function warn(code, detail) {notes.set(code+': '+detail, true);}
  const available=await figma.listAvailableFontsAsync();
  const loaded=new Map();
  async function fontFor(node) {
    const requested=(node.fontFamily||'').split(',').map(s=>s.trim().replace(/^['"]|['"]$/g,''));
    const families=[...requested,'Noto Sans SC','Microsoft YaHei','PingFang SC','Inter'];
    for(const family of families) {
      const matches=available.filter(f=>f.fontName.family.toLowerCase()===family.toLowerCase()).sort((a,b)=>{
        const score=f=>Math.abs(styleWeight(f.fontName.style)-(node.fontWeight||400))+(Boolean(/italic|oblique/i.test(f.fontName.style))!==Boolean(node.italic)?1000:0);
        return score(a)-score(b);
      });
      for(const entry of matches) {
        const font=entry.fontName,key=font.family+'/'+font.style;
        if(!loaded.has(key)) {
          figma.ui.postMessage({type:'progress',count:created,detail:'正在检查字体 '+font.family+' '+font.style});
          loaded.set(key,Promise.race([figma.loadFontAsync(font).then(()=>true,()=>false),new Promise(resolve=>setTimeout(()=>resolve(false),3000))]));
        }
        if(await loaded.get(key)) {
          if(!requested.some(f=>f.toLowerCase()===font.family.toLowerCase())) warn('字体替换', `${node.fontFamily} → ${font.family}`);
          if(styleWeight(font.style)!==(node.fontWeight||400) || Boolean(/italic|oblique/i.test(font.style))!==Boolean(node.italic)) warn('字重或斜体近似',`${node.fontFamily} → ${font.style}`);
          return font;
        }
      }
    }
    throw new Error('没有可加载的字体，请在 Figma 中检查字体环境。');
  }
  let root;
  const roots=[], pendingReactions=[];
  const originalFlows=[...(figma.currentPage.flowStartingPoints||[])];
  let created=0;
  async function build(data, parent) {
    let node;
    if(data.type==='TEXT') {
      const font=await fontFor(data);
      node=figma.createText();parent.appendChild(node);
      node.fontName=font;node.fontSize=data.fontSize;node.characters=data.text;
      node.textAutoResize='NONE';node.resize(data.width+1,data.height+2);
      node.lineHeight={unit:'PIXELS',value:data.lineHeight};node.letterSpacing={unit:'PIXELS',value:data.letterSpacing};
      node.textAlignHorizontal=({left:'LEFT',right:'RIGHT',center:'CENTER',justify:'JUSTIFIED'})[data.textAlign]||'LEFT';
      node.fills=paint(data.color);
      if(data.decoration && data.decoration.includes('underline'))node.textDecoration='UNDERLINE';
      else if(data.decoration && data.decoration.includes('line-through'))node.textDecoration='STRIKETHROUGH';
    } else {
      node=figma.createFrame();parent.appendChild(node);node.resize(data.width,data.height);
      node.fills=paint(data.background);node.strokes=[];node.clipsContent=Boolean(data.clip);node.opacity=data.opacity;
      const radii=data.radii.map(r=>Math.min(r,data.width/2,data.height/2));
      [node.topLeftRadius,node.topRightRadius,node.bottomRightRadius,node.bottomLeftRadius]=radii;
      // Uniform borders use an editable native stroke, including rounded corners.
      const borders=data.borders, first=borders[0];
      const uniform=borders.every(b=>b.width===first.width && JSON.stringify(b.color)===JSON.stringify(first.color) && b.style===first.style);
      if(uniform && first.width>0 && first.style!=='none' && first.style!=='hidden') {
        node.strokes=paint(first.color);node.strokeWeight=first.width;node.strokeAlign='INSIDE';
        if(first.style!=='solid')warn('边框近似', `${data.name}: ${first.style} → 实线`);
      } else {
        borders.forEach((b,index)=>{
          if(!b.width || b.style==='none' || b.style==='hidden')return;
          const edge=figma.createRectangle();node.appendChild(edge);edge.name=['上边框','右边框','下边框','左边框'][index];edge.fills=paint(b.color);
          edge.resize(index%2 ? Math.max(.01,b.width) : data.width,index%2 ? data.height : Math.max(.01,b.width));
          edge.x=index===1 ? data.width-b.width : 0;edge.y=index===2 ? data.height-b.width : 0;
          if(b.style!=='solid')warn('边框近似', `${data.name}: ${b.style} → 实线`);
        });
      }
      for(const child of data.children) await build(child,node);
      if(data.scrollDirection && data.scrollDirection!=='NONE'){node.clipsContent=true;node.overflowDirection=data.scrollDirection;warn('原生滚动',data.name+': 已设置滚动方向，网页滚动条外观不转换，请在播放模式测试。');}
    }
    node.x=data.x;node.y=data.y;node.name=String(data.name||data.type).slice(0,160);
    if(scene.version===2 && data.action)pendingReactions.push({node,action:data.action});
    created++;
    if(created%150===0) figma.ui.postMessage({type:'progress',count:created});
    return node;
  }
  try {
    const frames=scene.version===2 ? scene.frames : [{id:'legacy',name:scene.project?.name||'Product Agent 原型',kind:'screen',width:scene.width,height:scene.height,background:scene.background,nodes:scene.nodes}];
    const frameMap=new Map();
    for(const [index,frame] of frames.entries()){
      const container=figma.createFrame();figma.currentPage.appendChild(container);roots.push(container);frameMap.set(frame.id,container);
      container.name=String(frame.name||'原型画面').slice(0,120);
      container.resize(frame.width,frame.height);container.fills=paint(frame.background);container.clipsContent=true;
      container.x=figma.viewport.center.x-scene.width/2+(index%4)*(scene.width+100);
      container.y=figma.viewport.center.y-scene.height/2+Math.floor(index/4)*(scene.height+120);
      if(frame.height>(scene.viewport?.height||frame.height) && frame.kind==='screen'){
        container.resize(frame.width,scene.viewport.height);container.overflowDirection='VERTICAL';
      }
      for(const node of frame.nodes)await build(node,container);
    }
    let connections=0, unsupportedConnections=0;
    for(const {node,action} of pendingReactions){
      // Figma forbids NAVIGATE from a frame back into that same top-level frame.
      // Active menu entries are a no-op; other menu entries still navigate normally.
      if(action.type==='NAVIGATE'){
        let sourceRoot=node;
        while(sourceRoot.parent && !roots.some(root=>root.id===sourceRoot.id))sourceRoot=sourceRoot.parent;
        if(sourceRoot.id===frameMap.get(action.target).id)continue;
      }
      const nativeAction=action.type==='CLOSE' ? {type:'CLOSE'} : {
        type:'NODE', destinationId:frameMap.get(action.target).id,
        navigation:action.type, transition:null, preserveScrollPosition:false,
      };
      await node.setReactionsAsync([{trigger:{type:'ON_CLICK'},actions:[nativeAction]}]);
      connections++;
      if(action.unsupported)unsupportedConnections++;
      if(action.unsupported)node.name='[未转换操作] '+node.name;
    }
    root=frameMap.get(scene.startFrameId)||roots[0];
    if(scene.version===2){
      // Keep existing flows in the document; select this import as its own start.
      // setReactionsAsync can automatically create flow starts in Figma.
      // Remove only automatic starts for this import, preserve other document flows,
      // and register the intended start exactly once.
      const importedIds=new Set(roots.map(frame=>frame.id));
      const flows=new Map(figma.currentPage.flowStartingPoints
        .filter(flow=>!importedIds.has(flow.nodeId)).map(flow=>[flow.nodeId,flow]));
      flows.set(root.id,{nodeId:root.id,name:String(scene.project?.name||'Product Agent 原型').slice(0,100)});
      figma.currentPage.flowStartingPoints=[...flows.values()];
    }else warn('旧版静态文件','此 JSON 仅有一个画面，没有播放交互。请回 Product Agent 重新导出含交互的新版 JSON。');
    figma.currentPage.selection=[root];figma.viewport.scrollAndZoomIntoView([root]);
    return {count:created,connections,unsupportedConnections,screens:frames.filter(f=>f.kind==='screen').length,
      warnings:[...(scene.warnings||[]).map(w=>`${w.code}（${w.count}）：${(w.examples||[]).join('；')}`),...notes.keys()]};
  } catch(error) {
    if(scene.version===2)figma.currentPage.flowStartingPoints=originalFlows;
    for(const node of roots)node.remove();
    throw error;
  }
}
figma.ui.onmessage=async message=>{
  if(message?.type!=='import' || importing)return;
  importing=true;
  try {
    const result=await importScene(message.scene);
    figma.ui.postMessage({type:'complete',...result});
    figma.notify(`已创建 ${result.count} 个可编辑图层，请检查导入报告`);
  } catch(error) {figma.ui.postMessage({type:'error',error:String(error.message||error)});}
  finally {importing=false;}
};
