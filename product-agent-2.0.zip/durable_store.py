"""Private server-side snapshots. Local filesystem remains the execution cache."""
import base64,hashlib,json,os,re,threading,time
from pathlib import Path,PurePosixPath
import requests

class DurabilityError(OSError):pass
BASE_TASK={'task.json','context.json','requirement.md','prototype.html','scope.json','workflow.json','workflow.svg','workflow.drawio','bundle_manifest.json'}
BASE_PROJECT={'info.json','raw_requirement.txt','requirement.md','prototype.html','scope.json','workflow.json','workflow.svg','workflow.drawio','bundle_manifest.json'}

def allowed_file(kind,name):
    p=PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts or '\\' in name:return False
    if kind=='chat':return len(p.parts)==1 and bool(re.fullmatch(r'[a-f0-9]{32}\.json',name))
    base=BASE_TASK if kind=='task' else BASE_PROJECT
    if name in base:return True
    if kind=='task' and p.parts[0] in ('.prototype-modules','.prototype-diagnostics','.workflow-diagnostics'):
        return len(p.parts)<=4 and name.endswith(('.json','.html','.txt')) and all(re.fullmatch(r'[a-zA-Z0-9_.-]+',part) for part in p.parts)
    return False

class DurableStore:
    def __init__(self,url='',key='',request=None):
        self.url=url.rstrip('/');self.key=key;self.enabled=bool(url and key);self.request=request or requests.request;self.lock=threading.RLock();self.last={}
    @classmethod
    def from_env(cls):
        url=os.environ.get('PRODUCT_AGENT_SUPABASE_URL','').strip();key=os.environ.get('PRODUCT_AGENT_SUPABASE_SERVICE_KEY','').strip()
        if bool(url)!=bool(key):raise DurabilityError('持久化配置不完整，需要数据库地址和服务端密钥。')
        if url and not re.fullmatch(r'https://[a-z0-9]+\.supabase\.co',url.rstrip('/')):raise DurabilityError('持久化地址必须为 Supabase HTTPS 项目地址。')
        if os.environ.get('PRODUCT_AGENT_REQUIRE_DURABLE')=='1' and not url:raise DurabilityError('线上持久化尚未配置，未启动生成服务。')
        return cls(url,key)
    def api(self,method,*,params=None,body=None):
        if not self.enabled:return []
        headers={'apikey':self.key,'Content-Type':'application/json','Prefer':'resolution=merge-duplicates,return=minimal'}
        if not self.key.startswith('sb_secret_'):headers['Authorization']='Bearer '+self.key
        for attempt in range(3):
            try:
                response=self.request(method,self.url+'/rest/v1/product_agent_records',headers=headers,params=params,json=body,timeout=(10,25))
                if response.status_code in (429,500,502,503,504) and attempt<2:time.sleep(attempt+1);continue
                if not 200<=response.status_code<300:raise DurabilityError('阶段成果同步数据库失败（HTTP '+str(response.status_code)+'），已保留本机文件，请重试。')
                return response.json() if method=='GET' else []
            except (requests.Timeout,requests.ConnectionError):
                if attempt==2:raise DurabilityError('无法同步数据库，已保留本机文件，请稍后继续。') from None
                time.sleep(attempt+1)
        raise DurabilityError('阶段成果尚未同步数据库。')
    def snapshot(self,kind,record_id,folder,owner=None,deleted=False):
        files={};folder=Path(folder)
        if not deleted:
            for path in sorted(folder.rglob('*')):
                if not path.is_file() or path.is_symlink():continue
                name=str(path.relative_to(folder)).replace(os.sep,'/')
                if not allowed_file(kind,name):continue
                content=path.read_bytes()
                if len(content)>1500000:raise DurabilityError('阶段文件过大，未同步数据库。')
                files[name]={'data':base64.b64encode(content).decode(),'sha256':hashlib.sha256(content).hexdigest()}
        payload={'schema':'product-agent/snapshot','version':1,'deleted':deleted,'files':files}
        if len(json.dumps(payload))>11000000:raise DurabilityError('任务备份过大，未同步数据库。')
        return dict(kind=kind,record_id=record_id,owner_hash=hashlib.sha256(owner.encode()).hexdigest() if owner else None,payload=payload,revision=time.time_ns(),updated_at=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat())
    def save(self,kind,record_id,folder,owner=None,*,force=True,deleted=False):
        if not self.enabled:return
        with self.lock:
            key=(kind,record_id);last=self.last.get(key,0)
            if not force and time.monotonic()-last<20:return
            row=self.snapshot(kind,record_id,folder,owner,deleted)
            self.api('POST',params={'on_conflict':'kind,record_id'},body=[row]);self.last[key]=time.monotonic()
    def save_many(self,records):
        if not self.enabled:return
        with self.lock:
            rows=[self.snapshot(*record) for record in records]
            self.api('POST',params={'on_conflict':'kind,record_id'},body=rows)
    def restore(self,projects_root):
        """Restore the private cache before serving; never merge an unverified snapshot."""
        if not self.enabled:return
        root=Path(projects_root);offset=0
        with self.lock:
            while True:
                rows=self.api('GET',params={'select':'kind,record_id,payload','order':'kind.asc,record_id.asc','offset':offset,'limit':100})
                if not isinstance(rows,list):raise DurabilityError('数据库备份格式无效。')
                for row in rows:self.restore_record(root,row)
                if len(rows)<100:break
                offset+=100
    def restore_record(self,root,row):
        kind=row.get('kind');rid=row.get('record_id');payload=row.get('payload',{})
        if kind in ('task','chat'):
            if not isinstance(rid,str) or not re.fullmatch('[a-f0-9]{32}',rid):raise DurabilityError('数据库任务编号无效。')
            target=root/'.refinement-drafts'/rid if kind=='task' else root/'.requirement-chats'
        elif kind in ('project','archive'):
            pattern=r'[0-9]{8}_[0-9]{6}_[0-9]{6}' if kind=='project' else r'\.backup-[0-9_]+-[a-f0-9]{32}'
            if not isinstance(rid,str) or not re.fullmatch(pattern,rid):raise DurabilityError('数据库项目编号无效。')
            target=root/rid
        else:raise DurabilityError('数据库记录类型无效。')
        if payload.get('schema')!='product-agent/snapshot' or payload.get('version')!=1:raise DurabilityError('数据库快照格式无效。')
        if payload.get('deleted'):
            # No restoration of deleted data, even if a stale local cache is present.
            if kind=='chat':(target/(rid+'.json')).unlink(missing_ok=True)
            elif target.exists():__import__('shutil').rmtree(target)
            return
        files=payload.get('files')
        if not isinstance(files,dict):raise DurabilityError('数据库快照文件列表无效。')
        verified={}
        for name,item in files.items():
            if not allowed_file(kind,name) or (kind=='chat' and name!=rid+'.json'):raise DurabilityError('数据库快照包含非法文件路径。')
            try:data=base64.b64decode(item['data'],validate=True)
            except (ValueError,KeyError,TypeError):raise DurabilityError('数据库快照文件编码无效。') from None
            if len(data)>1500000 or hashlib.sha256(data).hexdigest()!=item.get('sha256'):raise DurabilityError('数据库快照校验不通过。')
            verified[name]=data
        target.mkdir(parents=True,exist_ok=True)
        for name,data in verified.items():
            p=target/name
            if p.is_symlink() or any(parent.is_symlink() for parent in p.parents if parent==root or root in parent.parents):raise DurabilityError('缓存路径存在非法链接。')
            p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.restore-tmp');tmp.write_bytes(data);os.replace(tmp,p)
    def migrate_local(self,projects_root):
        """Initial migration only after the existing process's data has been exported."""
        root=Path(projects_root)
        for folder in root.iterdir():
            if folder.is_dir() and re.fullmatch(r'[0-9]{8}_[0-9]{6}_[0-9]{6}',folder.name):
                info=json.loads((folder/'info.json').read_text());self.save('project',folder.name,folder,info.get('owner'))
        for folder in (root/'.refinement-drafts').glob('*'):
            if folder.is_dir() and (folder/'task.json').is_file():
                job=json.loads((folder/'task.json').read_text());self.save('task',folder.name,folder,job.get('owner'))
        for path in (root/'.requirement-chats').glob('*.json'):
            chat=json.loads(path.read_text());self.save_chat(path,chat)
    def save_chat(self,path,chat):
        if not self.enabled:return
        # Isolate each conversation; never back up every other owner's chat with it.
        content=Path(path).read_bytes();payload={'schema':'product-agent/snapshot','version':1,'deleted':False,'files':{Path(path).name:{'data':base64.b64encode(content).decode(),'sha256':hashlib.sha256(content).hexdigest()}}}
        row=dict(kind='chat',record_id=chat['id'],owner_hash=hashlib.sha256(chat['owner'].encode()).hexdigest(),payload=payload,revision=time.time_ns(),updated_at=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat())
        self.api('POST',params={'on_conflict':'kind,record_id'},body=[row])
